# Declaración académica de IA y responsabilidad

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

Se utilizó IA para asistir preparación y revisión de código de pruebas, fixtures, CFG, matrices, análisis de logs y redacción. La evidencia procede de herramientas ejecutadas, XML/TAP, AndroidJUnitRunner, SDK/emuladores y capturas auténticas. Las correcciones de producto se validaron en copias separadas. No se inventan firmas, participación, revisión docente ni evaluaciones por pares.

La revisión y la entrega se presentan como responsabilidad del grupo. La aceptación docente y los aportes/reproducciones de cada persona continúan sin acreditar. Hay una sola lista operativa de dependencias externas: [Pendientes_Externos.md](Pendientes_Externos.md), también disponible en [JSON](Pendientes_Externos.json). Los defectos internos están en [Defectos.md](Defectos.md).
