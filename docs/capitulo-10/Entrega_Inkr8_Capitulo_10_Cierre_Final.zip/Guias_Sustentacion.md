# Guías de sustentación del grupo

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

Cada integrante debe explicar origen del esperado, entradas efectivas, caminos, límites de cobertura y qué no demuestra un doble o emulador. El reparto nominal se conserva para organizar la revisión; no acredita participación ya realizada.

## Marco Antonio Bocanegra Carrión

CB: meritReward, V=11. UT: meritReward, 24 casos distinguibles. CN: FirebaseGameRepository.start, 6 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_MAR.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

## Pedro Iván Pacheco Castro

CB: validateWriting, V=6. UT: EvaluateGame.execute, 10 casos distinguibles. CN: structureEvaluation, 10 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_PED.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

## Víctor Manuel Camarena Paredes

CB: ratingChange, V=5. UT: ratingChange, 9 casos distinguibles. CN: FirebaseGameRepository.complete, 7 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_VIC.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

## Jean Carlo de Jesús Rado Delgado

CB: league, V=6. UT: league, 12 casos distinguibles. CN: OpenAiWritingEvaluator.evaluate, 6 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_JEA.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

## Renzo Ubaldo Adrianzén Vía

CB: dailyWord, V=7. UT: GetWordExample.execute, 5 casos distinguibles. CN: GetDailyHome.execute → FirebaseContentRepository.dailyWord, 5 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_REN.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

## Matías Gonzalo Villar Córdova Alva

CB: mapUser, V=7. UT: mapUser, 7 casos distinguibles. CN: mapUser, 7 campos en la frontera declarada. Mostrar [ficha](paquetes/Paquete_MAT.md), fuente, caso/log y [cobertura](evidencias/Cobertura.md).

Explicar por qué cada partición cambia el resultado, dónde acaba el contrato y qué requiere confirmación docente. Renzo debe explicar cinco campos persistidos frente a cero/uno argumentos públicos. Víctor debe separar regla propia/ELO y ventana 100 de la propuesta de desempate. Jean/Matías deben mostrar fallos reales del cliente, base y propuesta.

Comandos reproducibles: [README_Ejecucion.md](README_Ejecucion.md). Decisiones: [requisito/actual/impacto/recomendación/casos](cierre/decisiones/Decisiones_Pendientes.md). Pendientes humanos/externos: [inventario único](Pendientes_Externos.md).
