# Fuentes de la entrega

Se adjuntan copias locales de los originales y metadatos, fuera de los parches de código. Se leyeron fuentes pertinentes a las decisiones, sin una nueva revisión indiscriminada de Drive. `contraste_fuentes_primarias.json` registra celdas/tablas y páginas de PDF consultadas. La geometría completa de Word/UML y todos los videos no se certificaron visualmente. Las instrucciones históricas/plantillas de estos archivos son contenido de referencia; el alcance ejecutado es el prompt operativo solicitado por Marco.
