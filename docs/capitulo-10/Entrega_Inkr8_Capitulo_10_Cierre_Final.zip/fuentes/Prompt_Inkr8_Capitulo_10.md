# Encargo para Codex: ejecutar y documentar las pruebas de Inkr8

Soy **Marco Antonio Bocanegra Carrión**, integrante del Grupo 3 de Ingeniería de Software II. Ejecuta este encargo hasta producir una entrega técnica revisable del **capítulo 10**, sus pruebas y su trazabilidad con 5.3/5.6 y las funcionalidades de S2/S5. Yo centralizo la preparación; los seis integrantes revisarán y sustentarán sus aportes reales. La meta de coordinación es llegar con material para la asesoría del sábado 7 de noviembre de 2026, hora de Lima. No inventes resultados ni cierres pendientes por la fecha.

## 1. Resultado y frontera del encargo

Entrega pruebas implementadas, ejecución y cobertura medibles, seis paquetes individuales, un borrador de 10.1–10.5 y las filas propuestas para 5.3/5.6. Reutiliza lo que ya cumple y añade únicamente las brechas necesarias. El trabajo debe ser reproducible y estar escrito en español.

Puedes modificar tests, fixtures, scripts de ejecución y configuración mínima de pruebas/cobertura. Trabaja en una rama o copia aislada, conserva los cambios locales del equipo y deja un parche revisable. No publiques, fusiones, despliegues ni edites el informe compartido. No renombres repositorios, migres tecnología, refactorices arquitectura ni amplíes funcionalidades para facilitar la rúbrica. Merca, su Canva, los demás capítulos y las evaluaciones personales por pares están fuera del encargo; puedes entregar observaciones puntuales de coherencia que afecten las pruebas.

Matías ya confirmó separación de back/front y autorizó avanzar. **No esperes otra confirmación general para empezar.** Si una decisión o acceso bloquea una parte, concreta ese pendiente y continúa las partes independientes.

## 2. Material, versión y autoridad

Extrae este paquete y lee, en este orden:

1. `00_LEEME_MARCO.md` y este prompt.
2. `Preparacion_Pruebas_Inkr8_S2_S5.md`, para selección y criterios.
3. `Protocolo_Evidencias_Inkr8.md`, para diseño, ejecución y aceptación de evidencias.
4. `Auditoria_Documental_Inkr8.md`, especialmente contradicciones y límites; `Referencia_Henry_Wong_Inkr8.md`, para adaptar los ejemplos del profesor.
5. Las fuentes primarias pertinentes en `referencias_locales/originales/`, con ayuda de `fuentes.json`, `catalogo_hu.json` y los textos extraídos. Consulta las partes necesarias para cada decisión; no conviertas el encargo en una nueva revisión indiscriminada de todo Drive.

Fuentes principales:

| Fuente | Copia local / enlace | Función |
|---|---|---|
| Rúbrica | `referencias_locales/originales/Rubrica_Final_Proyecto_2026_2.xlsx`; hoja `Rubrica`, celda D18 | Define requisitos por integrante |
| Informe vigente | `referencias_locales/originales/Informe_Grupo_3_2026-11-05.docx`; [original](https://docs.google.com/document/d/1szkfADu3mH3yxLkgX2QIB7BGjMtAwBm4/edit) | IDs 5.1, criterios 5.3, evidencias 5.6 y calidad 6.3 |
| ASR | `referencias_locales/originales/ASR_Inkr8.xlsx` | Criterios complementarios, con errores señalados abajo |
| Plantilla | `referencias_locales/textos/template.txt`; URL en `fuentes.json` | Estructura del capítulo 10 |
| Enunciado y guía IA | PDFs en `referencias_locales/originales/` | Entregables y registro honesto de uso de IA |
| Semana 12 | `referencias_locales/originales/Semana_12_Pruebas_Rendimiento_v2.pdf` | Método de rendimiento y concurrencia |
| Wong | [GitHub del profesor](https://github.com/hwongu), referencias fijadas en el documento docente | Aserciones, contratos, errores, aislamiento y trazabilidad |

La copia del informe fue recuperada con modificación `2026-11-05T23:55:29.015Z`. Si recibes una versión posterior, compara las secciones relevantes y registra el cambio; no mezcles versiones sin indicarlo. Las copias locales evitan depender de una sesión de Google. Mantén fuentes privadas y evidencias voluminosas fuera del commit de código; no subas documentos del curso al repositorio como parte de los tests.

Backend: `https://github.com/Rnz5/Inkr8-ISW2`, rama **`Inkr8BackEnd`**, commit observado **`993c6b0641a4a60603d87e251c90f51783460007`**. Frontend comunicado: `https://github.com/Matonga-Matonag/Inkr8Android`; identifica rama y commit con el acceso del entorno. El conector de la auditoría devolvió 404 para ese frontend; no significa que no exista ni que Marco carezca de acceso. Si sigue inaccesible, completa backend y documenta exactamente qué pruebas del cliente faltan. `turron` es referencia histórica, no base activa por defecto.

Al iniciar registra rama, commit, estado de trabajo, versiones de herramientas y requisitos de entorno de cada repositorio accesible. Si HEAD cambió, revisa el diff pertinente, fija la versión que probarás y documenta la elección. No sigas actualizando la base durante la ejecución sin necesidad de una corrección concreta.

## 3. Reglas de verdad que evitan errores conocidos

- Usa los IDs canónicos de tabla 5.1. `HU 3.12` significa **Validación de restricciones avanzadas**. No crees IDs paralelos. La tabla 5.2 contiene historias eliminadas; los títulos de HU 3.4–3.9 en tabla 4.15 están copiados de S2.
- La tabla 5.3 y la 5.6 contienen nueve HU: 1.10, 2.1, 2.3, 2.4, 3.2, 3.3, 3.5, 3.7 y 3.12. Solo seis ya apuntan al 10: 2.3, 2.4, 3.2, 3.3, 3.7 y 3.12. La evidencia de 3.5 debe incluir espera/vencimiento y su referencia al 10 cuando esté demostrada.
- La prioridad es la unión de esas nueve con S2 —1.1–1.6— y S5 —3.4–3.9—: **19 HU distintas**. El catálogo tiene 30 para identificar correctamente, no para ordenar probarlas todas. Una evidencia puede apoyar varias HU si demuestra cada criterio; no dupliques conteos.
- En ASR, `Historias de Usuario!E2:E3` tiene criterios de oración de ejemplo bajo registro con Google: recházalos para HU 1.1. Prepara reconciliación desde S2 y `ACCEPTANCE_REPORT.md`, con fuente y estado pendiente de validación. El JSON conserva el error explícitamente.
- No reconstruyas IDs desde floats o fechas Excel. En ASR, `B20=1.1` con formato `0.00` representa 1.10 y `B50=3.1` representa 3.10. Usa ID canónico, título y celda.
- Ignora como alcance actual las exclusiones antiguas de Ranked, la etiqueta R3, empleados/pedidos de plantilla, torneos retirados y nombres ficticios de contribución del capítulo 12. Los roles de 2.2 son orientativos y tienen comentario de posible actualización.
- `ACCEPTANCE_REPORT.md` declara 60 escenarios y archivos Android: localiza los tests y revisa sus aserciones antes de contarlos. Mostrar un mensaje con «Demostrar Mensaje» acredita presentación, no detección del fallo, recuperación o persistencia.
- AC-06/RNF-024 promete fórmula oficial ELO, pero `ratingChange` en `gamePolicy.ts` implementa una regla propia. Registra la discrepancia; no implementes ELO ni declares conformidad por decisión unilateral. Puedes caracterizar el comportamiento actual, identificado como tal.
- La auditoría anterior fue estática: 17 declaraciones de tests de dominio y 17 de integración TS no son 34 aprobados. Las 47 pruebas mencionadas en reportes históricos no son un resultado vigente.

## 4. Construye y valida seis paquetes antes de fijar los casos

Cada integrante necesita **CB + CN + unitaria**: seis paquetes, 18 aportes principales. Cada prueba principal contiene los casos necesarios; debe haber al menos cuatro casos unitarios distinguibles por método seleccionado, mínimo 24 entre los seis paquetes. Usa una matriz de viabilidad con método/frontera, HU, fuente del oráculo, criterio de rúbrica, test existente y brecha.

| Integrante | Orientación de selección, ajustable |
|---|---|
| Marco | Merit y cobro, HU 3.2/3.3 y enlace con 3.4. Prioriza `meritReward` como candidato CB comprobable. `validateWriting` es útil para unitarias; si lo eliges, añade la trazabilidad pertinente de HU 2.2 |
| Pedro | Evaluación, feedback y restricciones: 2.3/2.4/3.12; `structureEvaluation`, `EvaluateGame`, adaptador R8 |
| Víctor | Matchmaking, espera y rating: 3.5/3.7; transacciones y recuperación |
| Jean Carlo | Estados/presentación: 2.1 y 3.4/3.6/3.8/3.9; ViewModels y mappers actuales |
| Renzo | Home y contenido: 1.5/1.6; operaciones y fallos de contenido |
| Matías | Usuario, sesión y progreso: 1.1–1.4/1.10; políticas, persistencia y cliente |

Es una propuesta, no el reparto confirmado de exposición ni atribución histórica. Rota candidatos si una especialidad no ofrece un método/frontera apto. No añadas temporadas fuera de las 19 HU solo para rellenar la fila de Renzo. Una HU adicional se permite cuando la prueba elegida la requiere: justifica y prepara ambas filas de trazabilidad, sin extender a todo el backlog.

### 4.1. Caja blanca

1. Elige método o módulo real con **V(G)≥5** en el commit probado. Declara alcance exacto y convención de decisiones. No sumes complejidades de callbacks desconectados para aparentar una función compleja, ni cuentes predicados ocultos de librerías como propios.
2. Entrega código fuente con nodos numerados, CFG en Mermaid o figura clara, N/E/P, cálculo de V(G), caminos básicos y tabla de casos ejecutados. Para CFG conectado y salidas normalizadas, contrasta `E−N+2` con `1+Σ(grado_salida−1)` de nodos de decisión; con decisiones binarias se reduce a `P+1`. Usa regiones solo sobre una representación planar consistente, contando la exterior. No inventes regiones para forzar una tercera igualdad. La rúbrica exige el umbral; este contraste hace el cálculo revisable.
3. Declara cómo modelas ternarios, cortocircuitos, `switch`, excepciones, retornos y salidas. Usa la misma convención en grafo, fórmula y caminos. No elijas conteo más conveniente ocultando ramas.
4. Enumera una base de caminos y demuestra independencia; el número objetivo corresponde a V(G), **no siempre cinco**. Asocia cada camino factible a entradas y aserciones. Si hay caminos inviables, explica la restricción y no los marques ejecutados. Prefiere un candidato cuya demostración sea defendible si la inviabilidad impide cumplir la entrega.
5. Mide cobertura y separa líneas, ramas y funciones de cobertura de caminos. Un porcentaje de líneas no demuestra por sí solo independencia de caminos.

En el backend revisado, `meritReward` ya supera cuatro: el recuento orientativo es 9 si el `if` compuesto se modela como decisión única y 11 con sus cortocircuitos descompuestos. Reconstruye el CFG para fijar el valor. `league` también es candidato con cinco ternarios. No intercambies automáticamente `meritReward` por `validateWriting`: la versión Kotlin histórica no acredita V(G)≥5 y el frontend actual falta inspeccionarlo. Nunca alteres producto para subir complejidad.

### 4.2. Caja negra

1. Define una operación y una frontera de prueba. Demuestra **cinco o más campos reales recibidos e influyentes** mediante firma/esquema y uso observable. Pueden ser propiedades de objetos recibidos, pero distingue entrada, precondición, dependencia y salida. No sumes endpoints ni valores/elementos de un mismo campo para inflar el número.
2. El payload público de `startGame` tiene tres campos y `submitGame` dos. `EvaluateGame.execute(id)` y `ResetLeagues.execute()` tampoco reúnen cinco argumentos. El estado persistido o un reloj inyectado no amplía automáticamente esos contratos públicos.
3. Antes de declarar falta de candidatos, inspecciona `structureEvaluation(game,result)`, contratos de `FirebaseGameRepository.start/complete`, `mapUser`, adaptador de evaluación y mappers actuales de Android. Verifica qué campos realmente recibe/utiliza la unidad; un parámetro sobrescrito internamente no cuenta por mera presencia. Son candidatos, no seis funcionalidades ya aprobadas.
4. Obtén expectativas del contrato/criterio independiente del cuerpo del método. Presenta particiones válidas e inválidas, límites aplicables, casos, resultado esperado y observado. Para enums o booleanos sin frontera numérica explica «no aplica»; no inventes valores límite. No exijas a un mapper validar tipos que su contrato no promete sin identificar la nueva expectativa como pendiente.
5. El GitHub de Wong respalda ejemplos de pruebas de API y dependencias simuladas, pero no aclara expresamente la aceptación de estos contratos internos para la condición de cinco entradas. Rotula esa interpretación y prepara una consulta concreta. La rúbrica no dice explícitamente «seis funcionalidades distintas»: prioriza seis aportes defendibles, sin asumir permiso para repetir una única prueba con seis nombres. Si propones compartir funcionalidad, describe escenarios y aportes individuales y la validación pendiente.

No declares seis paquetes conformes si una CN no cumple el mínimo o su interpretación sigue pendiente. Completa su diseño técnico y todo lo independiente; informa la brecha precisa.

### 4.3. Pruebas unitarias

Selecciona un método por paquete, con al menos cuatro casos distinguibles y aserciones propias. Reutiliza y amplía casos existentes cuando corresponda. Cada caso debe tener datos, operación, expectativa independiente y resultado. Un bucle parametrizado puede contener varios casos, pero cada fila debe quedar identificada y observable en el reporte.

Si usas `validateWriting`, cubre 49/50/150/151 palabras en STANDARD y 200/201 en ON_TOPIC; controla también que los datos no violen accidentalmente el límite de caracteres y distingue ese límite en sus propios casos. Si seleccionas `meritReward` para unitarias, usa tramos, límites, Ranked y entradas inválidas con resultados calculados independientemente. `RANKED_COST` es una constante, no un método unitario.

Adapta de Wong preparación–acción–aserción, excepciones y comprobación de efectos prohibidos. No copies `assertTrue(true)` de proyectos de ejemplo ni cambies de stack a JUnit/Mockito en TypeScript. Una prueba con mocks no demuestra transacciones reales. Registra duración por caso solo si el runner la proporciona; no inventes precisión ni porcentajes de cobertura.

## 5. Ejecución ordenada y herramientas reales

### Fase A: baseline

Inspecciona `package.json`, lockfile, configuración Firebase y tareas Gradle antes de usar comandos. Instala dependencias con el mecanismo reproducible del repo. Ejecuta la suite existente antes de modificarla y conserva comando, salida, código de retorno y entorno. Distingue error de herramienta, test fallido y test omitido.

Backend observado:

```bash
npm --prefix functions ci
npm --prefix functions test
```

`npm test` solo incluye `test/domain.test.cjs`. La integración se ejecuta aparte. Con Firebase CLI y Java apropiados disponibles, desde la raíz del backend:

```bash
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration"
```

Verifica la configuración efectiva del emulador, el proyecto de prueba y la variable host. No ejecutes limpieza de fixtures ni cargas contra producción. La suite actual limpia datos del proyecto de emulación; preserva ese aislamiento. Si falta una herramienta, realiza la preparación mínima posible o registra dependencia y comando pendiente exactos.

En Android, desde la raíz de Inkr8Android y tras comprobar las tareas existentes:

```bash
sh ./gradlew :domain:test :app:testDebugUnitTest --offline --no-daemon --max-workers=2
```

En Windows usa `gradlew.bat` con las mismas tareas/flags. Los flags proceden de la retrospectiva del equipo. Si falta una dependencia en caché, `--offline` no puede descargarla: registra el diagnóstico, prepara la caché cuando el entorno lo permita y repite el comando acordado. No informes falsamente que esos flags garantizan resolver cualquier fallo de Gradle.

### Fase B: brechas de prueba

Implementa solo casos que completan rúbrica, criterios seleccionados o evidencia de calidad relacionada. Revisa especialmente la expectativa `/insuficiente/` en integración frente al mensaje inglés de `FirebaseGameRepository.start`: es una sospecha estática que debes ejecutar y conciliar con el contrato de la capa.

Mantén la cobertura de los tests nuevos en los scripts: un archivo creado que el runner no descubre no cuenta como ejecutado. Evita modificar tests válidos para ocultar defectos. Si hallas defecto de producto, conserva reproducción y diagnóstico; separa cualquier propuesta de corrección de comportamiento. Los cambios de negocio/arquitectura no están autorizados por este encargo.

Para IA usa por defecto un evaluador determinista que permita éxito, timeout, respuesta mal formada y error de servicio. Identifica los tests del adaptador, del caso de uso y de la API externa por separado. No uses tokens o cuentas de producción ni hagas llamadas facturables para completar una tabla. La integración real y AC-01 cloud quedarán pendientes si no existe un entorno de prueba ya autorizado y disponible.

### Fase C: cobertura

En Node 20, confirma la opción disponible en el runner del entorno. El patrón para la suite actual, desde `functions`, es:

```bash
npm run build
node --test --experimental-test-coverage test/domain.test.cjs
```

Incluye explícitamente los archivos nuevos y registra el comando final. Usa `c8` únicamente si está instalado/configurado o si una incorporación mínima está justificada por la medición. No inventes Vitest. Si el reporte mide JS compilado en `lib`, indícalo; no atribuyas automáticamente ese porcentaje a las líneas TypeScript sin mapeo verificado. Guarda métricas por archivo/método o el alcance disponible, con exclusiones y ramas no cubiertas.

En Gradle inspecciona tareas de reporte existentes, por ejemplo `jacocoTestReport`, `koverXmlReport` o `koverHtmlReport`. Ejecútalas solo si están declaradas; no son comandos universales. Si no hay instrumentación, añade la configuración mínima compatible cuando sea viable o deja la medición pendiente con causa y acción concreta. No migres la herramienta de build para obtener un porcentaje. La ausencia de reporte no equivale a cobertura 0 % ni 100 %.

## 6. Calidad, concurrencia y rendimiento dentro del alcance

Relaciona las pruebas con AC-01 a AC-06 del informe; usa las diapositivas de Semana 12 para método, no para copiar umbrales de TVendo. No construyas siete suites de rendimiento por aparecer siete modalidades en clase.

- **AC-01:** ≥90 % de evaluaciones completas en ≤5 s en entorno descrito. Medir desde envío aceptado/capturado hasta resultado persistido/notificado según el requisito; separar tiempos del cliente si se miden. Declarar denominador, número de muestras, errores, timeouts, calentamiento y entorno. Un acuse HTTP rápido o mock no prueba la evaluación completa con OpenAI.
- **AC-02:** probar timeout de 90 s mediante reloj/excepción controlados y verificar persistencia, reintento y estado informativo. Probar cuota/disponibilidad aparte: el código actual usa una rama distinta. No esperar 90 s reales en una unitaria ni afirmar recuperación de todos los errores por cubrir uno.
- **AC-03:** 50 solicitudes con solapamiento observado sobre datos que compitan por recursos compartidos; delta máximo 30 y cero dobles/inconsistentes. Registrar inicio/fin, preparación y resultados finales. Cincuenta casos secuenciales, cincuenta usuarios configurados o `Promise.all` sin comprobar el solapamiento no bastan. Si el entorno no alcanza el perfil, entregar resultado parcial y pendiente.
- **AC-04:** repetir cierre/recompensa para el mismo ID lógico, también concurrentemente; comprobar una sola acreditación y estados consistentes.
- **AC-05:** insuficiencia, límites de 100 Merit y competencia por saldo; comprobar rechazo y ausencia de saldo negativo/débito duplicado.
- **AC-06:** mantener visible la discrepancia de ELO. Probar la regla actual como caracterización si es útil, sin etiquetarla como conformidad a fórmula oficial.

Usa emulador para transacciones y reglas; un doble en memoria no demuestra atomicidad Firestore. No alteres esquema de producción para facilitar una evidencia: si necesitas observar pares, diseña fixtures únicos y observación de tests compatible con los campos reales. Documenta qué invariantes puedes verificar y cuáles no.

## 7. Entregables finales, sin ampliar el trabajo

1. **`Capitulo_10_Borrador.md`** con 10.1 estrategia, 10.2 CB, 10.3 CN, 10.4 unitarias y 10.5 defectos. Cada resultado debe enlazar un caso y evidencia. Distingue resultados obtenidos, observaciones estáticas y pendientes.
2. **`Matriz_Pruebas_y_Trazabilidad`** en formato legible y procesable, con HU/criterio/fuente, diseño, símbolo/commit, paquete, técnica, casos, entorno, resultado, evidencia y límite. Incluye seis fichas con preparado por, responsable propuesto/confirmado, revisión humana y reproducción individual. No rellenas confirmaciones inexistentes.
3. **`Filas_5_3_y_5_6.md`**, listas para revisión/inserción. Conserva las nueve filas existentes y referencias a capítulo 9. Añade las diez ausentes de S2/S5 y las adicionales justificadas, con criterios de fuente o propuesta identificada. HU–caso es relación muchos a muchos.
4. **Código y evidencia reproducibles:** diff/patch por repositorio, tests/configuración mínima, README de ejecución, logs, reportes de cobertura y capturas auténticas cuando estén disponibles. Registra base y cambios; no digas que un parche local ya tiene un commit publicado.
5. **`Guias_Sustentacion.md`** con seis fichas de estudio: funcionalidad, criterio, diseño, código, tres técnicas, comando, resultado y limitación. No inventes tiempo de exposición, autoría, reproducciones ni frases sobre acciones que el compañero no realizó. La guía prepara el estudio previo; no asume asistencia de IA durante la defensa.
6. **Registro factual de IA y pendientes**, breve: herramienta, finalidad, material generado, intervención/validación realizada y restante. No fabriques prompts, porcentajes ni evaluaciones por pares.

En el registro de defectos incluye ID, requisito, evidencia, reproducción, esperado/obtenido, severidad e impacto, causa confirmada o hipótesis, estado y acción propuesta. Un hallazgo estático no se etiqueta como fallo reproducido. Un cambio de test por expectativa obsoleta se distingue de un defecto de negocio.

## 8. Criterio de cierre y comunicación

Antes de entregar verifica que todos los casos declarados ejecutados aparecen en logs; que la cobertura corresponde a archivos y versión reales; que ningún test omitido se contó como aprobado; y que las referencias a HU, método, diagrama y evidencia son coherentes. Revisa el parche y ejecuta las suites pertinentes después de los cambios. Repite solo lo necesario si aparece un nuevo cambio o fallo.

Entrega un cierre breve con: paquetes técnicamente completos de seis y conformidad docente pendiente; criterios comprobados de las 19 HU y subtotal de las seis que ya apuntaban al 10; suites/resultados/entorno; defectos abiertos y siguientes acciones. Separa **entregables preparados** de **producto conforme**. No marques «todo completo» si faltan entradas válidas de CN, cobertura requerida, cliente, integración real o participación individual.

Persiste hasta completar todo lo ejecutable con el acceso disponible. No te detengas en un plan, candidatos o preguntas si puedes implementar y medir otras partes. Si una fuente, acceso o decisión impide cerrar un criterio, deja el caso y la evidencia disponible concretos, explica exactamente qué falta y continúa el resto. El resultado debe poder revisarse y reproducirse sin depender de esta conversación.
