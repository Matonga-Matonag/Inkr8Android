# Protocolo de diseño, ejecución y evidencia

Este documento define cómo convertir el plan en resultados revisables. No contiene resultados de pruebas ejecutadas. Complementa el prompt; no amplía su alcance.

## 1. Identificación y estados

Usar IDs de prueba propios, por ejemplo `CB-MAR-01`, `CN-MAR-01`, `UT-MAR-01`; sufijos de caso como `UT-MAR-01-C01`. Son identificadores de pruebas, **no nuevos IDs de HU**. Cada prueba conserva HU oficiales y criterios de fuente. Si dos técnicas comparten ejecución, enlazarla sin duplicar el total de ejecuciones ni atribuirle objetivos no demostrados.

| Estado | Significado | Evidencia mínima |
|---|---|---|
| Diseñado | Caso definido, aún no ejecutado | Fuente, datos y expectativa |
| Ejecutado aprobado | Aserciones satisfechas en una ejecución identificable | Comando, commit/base+patch, entorno, log y resultado |
| Ejecutado fallido | Una expectativa no se cumplió | Log, reproducción, esperado/obtenido y diagnóstico |
| Bloqueado | No pudo ejecutarse por condición concreta | Error de entorno/acceso y acción necesaria |
| Omitido | El runner omitió el caso | Motivo y reporte; no cuenta como aprobado |
| Pendiente de validación docente | Técnica implementada, interpretación de rúbrica sin confirmar | Pregunta concreta y criterio afectado |
| Observación estática | Se detectó por lectura, sin reproducción | Fuente y líneas; no presentarla como test fallido |

Mantener dos ejes cuando corresponda: un caso puede estar ejecutado aprobado y seguir pendiente de aceptación docente como CN de cinco entradas. Tampoco «todos los tests pasan» significa que todos los criterios tengan un test.

## 2. Ficha mínima de caso

```yaml
id: UT-MAR-01-C01
paquete: Marco
tecnica: unitaria
hu: ["HU 2.2"]
criterio_fuente: "Fuente y ubicación exacta; si es propuesta, indicarlo"
objetivo: "Comportamiento que se quiere distinguir"
repositorio: "URL"
rama: "Rama probada"
commit_base: "SHA real"
patch: "Ruta y hash si hay cambios sin commit"
simbolo: "Ruta, símbolo y líneas de esa versión"
precondiciones: "Estado y dependencias controladas"
entradas: "Datos concretos o fixture identificable"
accion: "Operación real invocada"
esperado: "Resultado calculado desde requisito/oráculo independiente"
aserciones: "Resultado y efectos permitidos/prohibidos"
entorno: "Unidad / emulador / cliente / servicio externo real"
comando: "Comando exacto y directorio desde el que se ejecuta"
observado: "PENDIENTE hasta ejecución"
estado: "Diseñado"
duracion: "PENDIENTE; indicar unidad y fuente cuando exista"
evidencia: "Log/reporte/captura y localizador"
limitacion: "Qué no demuestra este caso"
```

Estos valores son estructura de ejemplo, no datos para presentar como una ejecución. Para un caso con varios resultados parciales, conservar la salida relevante y las aserciones; no resumir toda una suite con una sola etiqueta si oculta fallos.

## 3. Caja blanca: evidencia verificable

La ficha de CB debe identificar código original y numeración de nodos sin reescribir el algoritmo. El CFG tiene que reflejar las decisiones reales del alcance elegido. Declarar si condiciones de cortocircuito son nodos separados y cómo se normalizan salidas/retornos.

Entregar una tabla de nodos y aristas o el artefacto del grafo además de la figura. Calcular V(G) sobre ese grafo. Para un CFG conectado con salida común se usa `E−N+2`; el conteo general por decisiones es `1+Σ(grado_salida−1)`. `P+1` requiere decisiones binarias o una descomposición equivalente. La igualdad con regiones requiere una representación planar, con región exterior incluida. No aplicar tres fórmulas sobre tres grafos diferentes.

| Camino | Secuencia de nodos/aristas | Aporte de independencia | Datos que lo provocan | Aserción | Caso/log | Estado |
|---|---|---|---|---|---|---|
| Por completar | Por completar | Explicar arista/combinación independiente respecto de la base | Valores reales | Resultado independiente | ID y evidencia | Diseñado |

Si V(G)=9, enumerar solo cinco caminos no demuestra la base completa. Identificar caminos inviables por restricciones de datos y no fabricar casos para ellos. Si se usa un cálculo automatizado, conservar herramienta, versión, configuración y alcance; contrastar su convención con el CFG. La cobertura de ramas medida ayuda, pero no sustituye el análisis de independencia de caminos.

No aceptar una función sencilla aumentada artificialmente con `if` de prueba, suma de varios métodos sin un flujo conectado ni un CFG dibujado a partir de la expectativa en lugar del código.

## 4. Caja negra: campos, particiones y límites

Definir primero la frontera; después contar entradas. Se debe poder demostrar para cada campo dónde se recibe, quién lo controla, cómo afecta la operación y cuál es la salida observable. Una propiedad compuesta puede tener varios campos de negocio, pero no se debe contar simultáneamente el objeto y sus mismas propiedades como entradas adicionales.

| Campo real y ubicación | Tipo/dominio | Clase válida | Clase inválida | Límites aplicables | Regla y fuente | Observación |
|---|---|---|---|---|---|---|
| Por completar desde firma/esquema | Tipo real | Partición | Partición o «fuera del contrato» | L−1/L/L+1, U−1/U/U+1 cuando proceda | Criterio/contrato | Diferenciar entrada y estado |

Para cinco valores de `mode` sigue existiendo un solo campo. Un timestamp interno o saldo leído de Firestore no se vuelve entrada del callable por incluirlo en una tabla. Si se prueba directamente un componente que recibe un objeto, explicar ese nivel y mantener pendiente la aceptación docente si no está confirmada.

Casos de equivalencia: partir de un caso válido, variar un campo o clase por vez para identificar causa y añadir combinaciones de reglas donde exista interacción relevante. No usar un producto cartesiano desproporcionado de todos los campos. En booleanos/enums no inventar fronteras numéricas; en colecciones distinguir cardinalidad y validez de elemento; en texto distinguir longitud, palabras, normalización y contenido.

Los esperados deben venir del requisito/contrato, no de ejecutar la implementación para copiar su resultado como oráculo. Cuando el requisito no fija una regla, registrar una prueba de caracterización con ese alcance o proponer la decisión, sin atribuirla al profesor.

## 5. Unitarias y cobertura

Cuatro casos por método significa cuatro situaciones distinguibles con expectativas concretas. Una única aserción que siempre es verdadera, cuatro nombres que ejecutan lo mismo o cuatro métodos diferentes con un caso cada uno no cumplen esa estructura.

| Caso | Entrada | Regla esperada y aserción | Resultado obtenido | Duración del runner | Log |
|---|---|---|---|---|---|
| UT-…-C01 | Datos concretos | Valor/error/efecto | Pendiente | Pendiente | Pendiente |

La cobertura se presenta en una tabla aparte para evitar afirmar que el porcentaje de toda la suite pertenece a cada caso:

| Reporte | Herramienta/versión | Comando | Archivos/commit | Líneas | Ramas | Funciones | Exclusiones y límite |
|---|---|---|---|---|---|---|---|
| Ruta | Runner real | Comando reproducible | Alcance exacto | Medido o no disponible | Medido o no disponible | Medido o no disponible | JS compilado, TS mapeado o módulo Kotlin |

No calcular cobertura dividiendo tests aprobados entre tests totales. No sumar porcentajes de archivos ni mezclar backend y Android como si compartieran denominador. Si se desea agregar, usar numeradores/denominadores compatibles; en caso contrario reportar por módulo.

El tiempo de una unitaria no es una medición de latencia productiva. La duración puede incluir preparación y overhead del runner; declararlo cuando influya en la interpretación.

## 6. Evidencia por capa

| Capa | Evidencia adecuada | No acredita por sí sola |
|---|---|---|
| Política pura | Entradas, aserciones, cobertura de regla | Transacción Firestore, UI o llamada OpenAI |
| Caso de uso con dobles | Interacciones, resultado y efectos ante errores controlados | Disponibilidad/latencia de servicio externo |
| Adaptador con SDK simulado | Request formado, parseo, traducción de errores | Calidad semántica real del modelo |
| Firestore emulado | Lecturas/escrituras reales del emulador, transacciones y reglas cuando corresponda | Latencia y escalabilidad cloud de producción |
| Mapper/ViewModel | Transformaciones/estados observables de la unidad | Pantalla realmente renderizada, navegación o reinicio de app |
| Cliente ejecutado | Captura/procedimiento con datos y estado vinculados al caso | Que el backend haya sido real si fue sustituido por fixture |
| IA real en entorno de prueba | Request/respuesta saneados, modelo, versión/configuración y condiciones | Generalización a todo texto o a todas las condiciones de carga |

Una captura generada por diseño o una salida inventada no es evidencia. Las capturas auténticas deben incluir contexto suficiente para entender la operación, sin tokens, cuentas innecesarias o datos de compañeros.

## 7. Concurrencia, rendimiento y reproducibilidad

Para AC-03, definir si cada solicitud corresponde a un envío o a una operación de emparejamiento y cómo se vincula con el escenario del informe. Preparar los datos fuera de la ventana medida, fijar IDs únicos y usar una barrera de inicio cuando corresponda. Registrar timestamps de inicio y fin de operaciones para evaluar solapamiento efectivo. Distinguir 50 solicitudes intentadas de 50 simultáneamente activas: declarar el perfil realmente logrado.

Comprobar invariantes sobre el estado final: cada partida solo se resuelve una vez, rivales elegibles, actualizaciones coherentes, ausencia de consumo duplicado y rating/saldo esperados. El modelo actual almacena datos del oponente sin un ID explícito en el objeto `match`; usar fixtures identificables y una estrategia de observación de tests que permita el contraste, sin cambiar el esquema del producto. Si no puede demostrarse reciprocidad inequívoca, dejar ese límite visible.

Para AC-04, distinguir reintentos de una misma partida y partidas distintas. Para AC-05, producir competencia real por el mismo saldo y verificar débito exacto/rechazo; cincuenta usuarios con saldos independientes no ejercitan esa condición de carrera.

Para tiempos, guardar muestras y no solo una media. Definir inicio/fin, unidad, reloj, calentamiento, entorno, cantidad de intentos, completados, fallos y timeouts. Informar la fracción de intentos que completó a tiempo y, si se calcula también un percentil de completados, rotular ese denominador por separado. No excluir fallos sin mencionarlos para mejorar el resultado.

Si falta un entorno con IA real, el reporte local puede mostrar coste del flujo simulado, pero AC-01 debe seguir pendiente de validación en su entorno exigido. Una medición local favorable no autoriza escribir «cumple ≤5 s en Cloud Functions».

## 8. Defectos y discrepancias

| ID | Naturaleza | Ejemplo inicial | Estado inicial |
|---|---|---|---|
| DOC-01 | Criterio copiado | ASR HU 1.1 usa oración de ejemplo | Confirmado documentalmente; reconciliación propuesta |
| DOC-CODE-01 | Requisito vs implementación | AC-06 ELO vs `ratingChange` propio | Confirmado por lectura; decisión de negocio pendiente |
| TEST-OBS-01 | Expectativa posiblemente obsoleta | `/insuficiente/` frente a mensaje en inglés | Observación estática; ejecutar antes de registrar fallo |
| CODE-OBS-01 | Recuperación potencialmente incompleta | Timeout se difiere; errores genéricos fallan | Observación estática; probar cuota/disponibilidad y reconciliar AC-02 |
| ACCESS-01 | Acceso a fuente | Frontend no recuperado por conector | No prueba un defecto del producto |

Para un defecto ejecutado, incluir caso mínimo reproducible, resultado esperado y obtenido, impacto, severidad justificada, causa confirmada o hipótesis, acción propuesta y estado. No asignar causa raíz por intuición. No corregir una regla de negocio en silencio ni convertir un defecto de producto en «test incorrecto» solo porque el esperado falla.

## 9. Evidencia individual y guía de defensa

Campos independientes: preparado por, herramienta de apoyo, responsable asignado, revisión realizada por, ejecución automatizada, reproducción individual confirmada, cambios/aportes del integrante y fecha. Una fila propuesta no es una confirmación.

Cada guía debe permitir explicar: qué necesita el usuario; qué criterio se prueba; qué diagrama representa el flujo y en qué nivel; dónde está el código; por qué CB cumple complejidad; cuáles son los campos de CN; qué distinguen los cuatro casos unitarios; qué pasó al ejecutar; qué no cubre esa evidencia. Adjuntar comando y datos para practicar.

Reproducir no obliga a reescribir todos los tests. Sí exige comprobar el resultado y entenderlo. Para demostrar participación individual deben registrarse revisiones/aportes reales, sin prometer que únicamente correr un comando basta para la rúbrica. Las guías no deben atribuir trabajo ficticio ni preparar asistencia de IA durante una defensa restringida.

## 10. Comprobación antes de entregar

- Cada afirmación «ejecutado» tiene log y versión; cada captura tiene caso y procedencia.
- Cada paquete tiene tres técnicas y sus requisitos explícitos; los pendientes docentes no desaparecen detrás de un PASS técnico.
- Los tests nuevos son descubiertos por el comando entregado y las suites pertinentes se repitieron tras el último cambio.
- Las nueve HU actuales de 5.6 conservan referencias visuales cuando las requieren; las diez ausentes de S2/S5 tienen filas propuestas, no ediciones silenciosas.
- El informe distingue cobertura de código, cobertura de criterios y completitud de paquetes.
- No hay resultados de turron, cifras históricas, ejemplos de Wong o plantillas presentados como ejecución del commit actual.
- El parche se limita al encargo; las fuentes del curso, credenciales y logs privados no se incluyen inadvertidamente en Git.
- El resumen final indica qué quedó listo para revisión y qué falta para conformidad total, con una acción concreta por pendiente.
