# Paquete de trabajo para Codex — Inkr8, capítulo 10

**Preparado para Marco Antonio Bocanegra Carrión. Corte: 5 de noviembre de 2026, Lima.**

Este paquete reúne el análisis documental, las decisiones y las fuentes disponibles para que un agente ejecute las pruebas sin volver a reconstruir el contexto del chat. **Todavía no contiene pruebas implementadas ni resultados de ejecución nuevos.** El siguiente paso es ejecutar el prompt en un entorno con acceso a los repositorios.

## Qué pasarle al agente

Entrega el ZIP completo y este mensaje:

> Extrae el paquete y lee `00_LEEME_MARCO.md`. Ejecuta `Prompt_Inkr8_Capitulo_10.md` usando los documentos y las fuentes adjuntas. Avanza con todo lo verificable del backend y del frontend al que tengas acceso. Entrega pruebas, evidencias reales y los borradores indicados. No amplíes el alcance ni declares cumplido un requisito que no puedas demostrar.

El prompt es la instrucción operativa. La auditoría explica de dónde procede cada decisión; el protocolo define cómo acreditar resultados. Las copias históricas se incluyen como referencias señaladas, no como órdenes nuevas. No combines este prompt con versiones anteriores que propongan intercambios automáticos de métodos o den por válidos seis contratos sin inspeccionarlos.

## Archivos principales

| Archivo | Para qué sirve |
|---|---|
| [Prompt_Inkr8_Capitulo_10.md](Prompt_Inkr8_Capitulo_10.md) | Encargo autónomo, alcance, fases, requisitos, comandos y entregables |
| [Auditoria_Documental_Inkr8.md](Auditoria_Documental_Inkr8.md) | Revisión documento por documento, contradicciones, fuentes y límites |
| [Preparacion_Pruebas_Inkr8_S2_S5.md](Preparacion_Pruebas_Inkr8_S2_S5.md) | Las 19 HU prioritarias, criterios, evidencias y reparto propuesto |
| [Referencia_Henry_Wong_Inkr8.md](Referencia_Henry_Wong_Inkr8.md) | Archivos y commits del profesor, patrones útiles y ejemplos que no bastan |
| [Protocolo_Evidencias_Inkr8.md](Protocolo_Evidencias_Inkr8.md) | Fichas, estados, oráculos, cobertura, concurrencia, defectos y defensa |
| `catalogo_hu.json` | 30 IDs canónicos, celdas ASR y las nueve filas actuales de 5.3/5.6; marca cuáles integran las 19 prioritarias |
| `fuentes.json` | Procedencia, versiones, alcance de lectura y rutas de fuentes |
| `inventario_tratamiento.csv` | Tratamiento de cada archivo inventariado de Drive: leído, contextual, solo inventariado o fuera del alcance |
| `manifest_sha256.json` | Tamaño y hash de los archivos del paquete, excepto el propio manifiesto |

`referencias_locales/originales/` contiene el informe actual, la rúbrica, ASR, backlog histórico, enunciado, guía de IA, Semana 12 y ejemplos UML del profesor. `textos/` contiene las extracciones y tablas; `uml/`, los editables del proyecto; `wong/`, los archivos docentes leídos y el inventario de repositorios. Los extractos no certificados visualmente están identificados en la auditoría.

## Situación para comenzar

| Elemento | Estado |
|---|---|
| Autorización para avanzar | Matías confirmó separación y pidió a Marco empezar las pruebas |
| Backend | Rama `Inkr8BackEnd` de `Rnz5/Inkr8-ISW2`, commit observado `993c6b0641a4a60603d87e251c90f51783460007` |
| Frontend | `Matonga-Matonag/Inkr8Android`; el acceso conectado de esta auditoría devolvió 404. Comprobar acceso local de Marco, rama y commit |
| Informe | DOCX recuperado con modificación del 5 de noviembre a las 23:55:29 UTC; no usar la copia antigua del 3 de noviembre como versión principal |
| Pruebas del backend | Suites leídas, no ejecutadas por esta auditoría. Se encontraron 17 declaraciones de dominio y 17 de integración |
| Rúbrica | Tres aportes por persona: CB V(G)≥5, CN ≥5 campos reales, unitaria ≥4 casos por método |
| Prioridad de evidencia | 19 HU de la unión de 5.6, S2 y S5; no son 19 casos ni toda la cobertura de 30 HU |
| Fuentes de Wong | Revisadas y aplicadas al diseño del encargo; no resuelven automáticamente la interpretación de CN interna |

No hace falta esperar a Matías para todo. Se puede comenzar con backend, baseline, unitarias, complejidad, casos de integración y documentación. Lo que requiere cliente, entorno real o decisión de regla se deja delimitado mientras se avanza lo demás.

## Cuatro cuestiones para coordinación, sin paralizar el trabajo

1. **Rating:** el informe dice ELO oficial y el backend usa otra regla. Confirmar cuál debe regir la entrega; el agente no debe cambiarla unilateralmente.
2. **Caja negra:** llevar a Wong una ficha concreta con frontera, cinco campos recibidos y casos. Confirmar si acepta ese contrato aunque no haya cinco controles visuales, y la posibilidad de compartir funcionalidad con aportes distintos.
3. **Exposición:** confirmar qué funcionalidad S2/S5 sustentará cada persona y duración. El reparto incluido es propuesta.
4. **Cliente y fuentes:** facilitar acceso de ejecución a Inkr8Android y, si está disponible, el PPT específico de unitarias. No es necesario proporcionar contraseña de Blackboard para iniciar lo ya documentado.

## Hallazgos que el agente no debe perder

- ASR copió criterios de oración de ejemplo en HU 1.1 de Google. Los IDs numéricos de Excel también pueden confundir 1.1/1.10 y 3.1/3.10; el catálogo preserva identidad y celdas.
- `meritReward` sí es candidato de caja blanca en el commit leído. Verificar su CFG, no cambiarlo automáticamente por `validateWriting`.
- Una carpeta `test`, 60 escenarios declarados, una captura de mensaje o un test de plantilla de Wong no demuestran ejecución ni cumplimiento funcional.
- Los diagramas de clases mezclan páginas antiguas y ajenas; la trazabilidad debe hacerse por página y símbolo real.
- La cobertura de código, los casos ejecutados, los criterios de aceptación y la participación de los integrantes son medidas distintas.

## Cómo revisar lo que entregue Codex

Debe incluir código/patch por repositorio, comandos, logs, cobertura real, borrador 10.1–10.5, seis fichas, filas propuestas de 5.3/5.6 y guías de estudio. Los logs deben respaldar los resultados y los pendientes deben tener una acción concreta. El agente no debe editar el informe compartido ni publicar cambios.

Marco puede centralizar la preparación con IA. El registro debe reflejar esa preparación y las revisiones/aportes reales de cada persona. Reproducir significa ejecutar y contrastar el resultado; no reescribir toda la suite. Una asignación equitativa de nombres no acredita por sí sola el trabajo individual exigido por la rúbrica.

Este paquete se comprobó en consistencia de IDs, referencias internas, conteos, alcance y fuentes. No promete nota máxima ni certifica todavía que el producto pase las pruebas. Ofrece una base concreta para ejecutarlas y defender lo que realmente se demuestre.
