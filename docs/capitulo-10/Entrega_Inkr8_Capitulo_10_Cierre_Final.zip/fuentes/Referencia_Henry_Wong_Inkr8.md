# Referencia docente: qué adaptar del GitHub de Henry Wong

Perfil indicado por Marco: [github.com/hwongu](https://github.com/hwongu). Consulta realizada al corte del paquete. Esta referencia complementa la rúbrica oficial; no sustituye sus umbrales ni certifica que cualquier ejemplo satisfaga la entrega individual de ISW2.

## 1. Cobertura de la consulta

Se recuperaron 12 repositorios del perfil y los árboles completos disponibles de 11 proyectos. Se leyeron los archivos relevantes detallados abajo; el resto tiene revisión de estructura, no auditoría de cada línea. Los commits fijan la versión de referencia y evitan mezclar cambios posteriores con este análisis.

| Repositorio | Commit observado | Revisión y pertinencia |
|---|---|---|
| NexusMonolitico | `d1276aedb50e75f7a1653a2e292d50863658e1bb` | README, guía Postman, colección, POM y pruebas de Ingreso/Producto. Referencia principal para unitarias y contratos |
| NexusMicroservicios | `a4b5a2d8178b65ac288538804dcc7d2db659b71d` | Árbol y `ProductoControllerTest`. Referencia principal para entradas inválidas y respuestas observables |
| NexusMicroserviciosAvanzado | `3a51a05a51fef433a523fe3a05b52ec664c45342` | Inventario estructural; no incorporar arquitectura avanzada por el encargo de pruebas |
| NexusMicroFrontend | `a04a676a3b3d6187529fc45b6d550f2c1192eb0d` | Inventario estructural; stack de frontend distinto de Android |
| TVendoMonolitico | `f73365b9f18dd1d08000cf96d3def799c56d4b53` | Árbol y README breve; no se identificó aquí un plan JMeter reutilizable que pruebe Inkr8 |
| isw2-sistema-ventas | `bb39e0e661bf52b33a9feaaf4f241a296aeeac5b` | Árbol mínimo y README; contexto Java/Angular/PostgreSQL, no una suite sustantiva recuperada |
| PideYaSuite | `552f604ea0941487a3d26ffc280e86cf4b3c8c54` | Árbol y README; simulación de pagos y otra interfaz. No sustituye las reglas de Inkr8 |
| HexagonalCdcPoc | `4522abc57e6286a15b2eab31f4819d605f417260` | Árbol y `AppTest`; el test leído es un esqueleto con `assertTrue(true)` |
| HexagonalOutboxPoc | `ea1a9cc7917202700f34e9db142d6949238207e4` | Árbol y `AppTest`; mismo tipo de esqueleto |
| HexagonalDualWriterPoc | `bb0c241ee6f0263d40ab7ed8fcf9c6b167115229` | Inventario estructural; no selección de casos para esta entrega |
| HexagonalDbCoexistencePoc | `5826f5e0ee3eb770f333a2d460908a3ab8989be7` | Inventario estructural; no selección de casos para esta entrega |
| hwongu | No se fija commit en este paquete | Repositorio de perfil, no evidencia de pruebas |

El inventario completo de rutas está en `referencias_locales/wong/inventario_repositorios.json`. No se afirma que el profesor carezca de otros materiales o pruebas en ramas, repositorios privados o Blackboard.

## 2. NexusMonolitico: pruebas de servicios

Fuente principal: [IngresoServiceTest.java](https://github.com/hwongu/NexusMonolitico/blob/d1276aedb50e75f7a1653a2e292d50863658e1bb/2_BackEnd/NexusBackEnd/src/test/java/net/hwongu/nexus/be/service/IngresoServiceTest.java). Copia legible: `wong_nexus_tests.txt`.

El ejemplo usa JUnit 5 y Mockito: preparación común, repositorio controlado, servicio bajo prueba, ejecución y aserciones de resultado e interacción. Comprueba listas y datos específicos, que una operación sea delegada una vez y que una excepción de persistencia se traduzca en la excepción esperada del servicio.

La lección para Inkr8 es aislar la dependencia externa cuando se prueba una decisión de un caso de uso. Para un timeout de evaluación, un evaluador controlado debe lanzar la excepción correspondiente y las aserciones deben verificar el estado de recuperación y las operaciones permitidas/prohibidas. No basta con afirmar que se creó un mock o que el método «no lanzó error».

El archivo contiene seis métodos de test repartidos entre cinco métodos del servicio. Eso **no demuestra por sí solo cuatro casos para un mismo método**, condición de la rúbrica de Marco. Debe adaptarse el patrón y diseñar los casos exigidos sobre un método concreto de Inkr8.

Fuente complementaria: [ProductoServiceTest.java](https://github.com/hwongu/NexusMonolitico/blob/d1276aedb50e75f7a1653a2e292d50863658e1bb/2_BackEnd/NexusBackEnd/src/test/java/net/hwongu/nexus/be/service/ProductoServiceTest.java), copia `wong_nexus_producttests.txt`. Sus siete tests combinan operaciones y errores. De nuevo, el tamaño de una clase de pruebas no equivale al número de casos de un método seleccionado.

El [POM revisado](https://github.com/hwongu/NexusMonolitico/blob/d1276aedb50e75f7a1653a2e292d50863658e1bb/2_BackEnd/NexusBackEnd/pom.xml) no declara un reporte JaCoCo. No se debe atribuir a estos ejemplos una cobertura medida que no muestran. Para Inkr8, medir con el runner/configuración real y reportar alcance.

## 3. NexusMonolitico: guía y colección Postman

Fuentes: [GUIA_DE_PRUEBAS_POSTMAN.md](https://github.com/hwongu/NexusMonolitico/blob/d1276aedb50e75f7a1653a2e292d50863658e1bb/2_BackEnd/NexusBackEnd/GUIA_DE_PRUEBAS_POSTMAN.md) y [colección Postman](https://github.com/hwongu/NexusMonolitico/blob/d1276aedb50e75f7a1653a2e292d50863658e1bb/5_Test/Postman/NexusMonolitico.postman_collection.json).

La guía organiza operaciones por endpoint, método, headers, cuerpo, respuesta y estado esperado. Permite documentar una prueba funcional de API sin depender de que exista un formulario web. Para Inkr8 conviene adoptar una ficha equivalente: frontera callable/repositorio, identidad controlada, datos, operación, salida y cambio persistido.

La colección recuperada tiene **20 solicitudes y ningún bloque `event`** de scripts de la colección. Es un conjunto de requests útil, pero no demuestra aserciones automatizadas de Postman ni resultados ejecutados. Importarla no sería evidencia de que el sistema aprueba.

El ejemplo de creación de producto usa cuatro campos principales (`idCategoria`, `nombre`, `precio`, `stock`). Su existencia en el GitHub del profesor no hace que cuatro campos satisfagan la condición «más de cuatro» de esta rúbrica. Tampoco autoriza a contar respuestas o datos ocultos del servidor como entradas.

## 4. NexusMicroservicios: probar la frontera y los efectos prohibidos

Fuente: [ProductoControllerTest.java](https://github.com/hwongu/NexusMicroservicios/blob/a4b5a2d8178b65ac288538804dcc7d2db659b71d/2_BackEnd/NexusCatalogoMs/src/test/java/net/hwongu/nexus/catalogo/be/controller/ProductoControllerTest.java), copia `wong_micro_controller.txt`.

Construye `MockMvc` en modo standalone con controlador, validación y manejador de excepciones. El servicio está simulado. Los tests verifican códigos HTTP, tipo de contenido, propiedades concretas del JSON y errores 400, 404 y 409. En el caso de entrada inválida comprueba que no se llama al servicio.

Esto orienta pruebas de Inkr8 con tres comprobaciones: respuesta correcta, estado correcto y ausencia del efecto indebido. Un intento Ranked sin saldo debe ser rechazado, no crear una partida válida ni descontar saldo. Una solicitud duplicada debe dejar una sola acreditación, no únicamente devolver un mensaje conocido.

El ejemplo prueba la capa de controlador aislada; no demuestra base de datos real ni un recorrido de extremo a extremo. Aplicar el mismo cuidado de denominación: mock del repositorio para una unitaria, emulador real para transacciones, cliente para UI y entorno con OpenAI real para integración externa. Un test no adquiere todos esos alcances por llamarse «integración».

## 5. Ejemplos que no deben copiarse como evidencia sustantiva

Los archivos [AppTest de CDC](https://github.com/hwongu/HexagonalCdcPoc/blob/4522abc57e6286a15b2eab31f4819d605f417260/1_BackEnd/PocHexagonalCdc/src/test/java/net/hwongu/poc/AppTest.java) y [AppTest de Outbox](https://github.com/hwongu/HexagonalOutboxPoc/blob/ea1a9cc7917202700f34e9db142d6949238207e4/1_BackEnd/PocOutbox/src/test/java/net/hwongu/poc/AppTest.java) conservan una prueba de plantilla que afirma `true`. No invocan una regla de negocio ni demuestran requisitos. Sirven para reconocer que un repositorio puede contener una carpeta de tests sin una prueba útil para la rúbrica.

El README de PideYaSuite describe una simulación de pagos con respuestas aleatorias. En pruebas reproducibles de Inkr8 conviene controlar el resultado del doble de prueba y registrar el caso, no introducir una falla aleatoria para llenar una tabla de éxito/error.

Los ejemplos de Java, Angular, PostgreSQL, microservicios, CDC y Outbox no justifican migrar tecnología, agregar servicios o alterar la arquitectura de Inkr8. El README de NexusMonolitico presenta un uso educativo; si se cita o adapta una idea, conservar atribución a Henry Wong y usar solo lo pertinente a la actividad académica.

## 6. Qué cambia en el prompt de ejecución

| Patrón comprobado en Wong | Instrucción concreta para Codex |
|---|---|
| Preparación, acción, aserción | Cada caso debe exponer datos, operación y expectativa propia |
| Dobles controlados | Simular OpenAI cuando se pruebe la lógica; identificar claramente ese alcance |
| Excepciones y errores de contrato | Probar rechazo y código/estado correcto, no solo ruta feliz |
| `verify(..., never())` | Verificar que entradas rechazadas no causan cobros, recompensas o escrituras indebidas |
| API con entradas y respuesta documentadas | Diseñar CN desde una frontera explícita; enumerar campos reales y particiones |
| Separación de niveles | No afirmar que una unitaria prueba Firestore, Android o servicio externo real |
| Ejemplos de trazabilidad UML en Drive | La guía de defensa debe localizar métodos reales detrás de los mensajes del diagrama |

No se encontró en los archivos seleccionados una aclaración expresa que acepte cinco campos internos como equivalente a cinco entradas de funcionalidad para esta evaluación. Tampoco una regla que obligue a seis funcionalidades distintas. La consulta preparada es: **«Para caja negra, ¿acepta una operación de dominio/API con cinco campos reales recibidos en su contrato, con particiones y límites, aunque no correspondan a cinco controles visibles? ¿Puede compartirse funcionalidad entre integrantes si cada uno sustenta escenarios y aporte propios?»**

La consulta no paraliza las unitarias, caja blanca, trazabilidad o pruebas funcionales válidas del backend. Hasta recibir respuesta, las candidatas internas deben mostrarse como interpretaciones pendientes, con su evidencia técnica completa.
