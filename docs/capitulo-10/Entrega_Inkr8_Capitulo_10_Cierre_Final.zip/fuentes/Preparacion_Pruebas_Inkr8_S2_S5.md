# Preparación de pruebas: 5.6, Sprint 2 y Sprint 5

**Versión:** corte documental 5 de noviembre de 2026, Lima. Reemplaza la matriz anterior basada en copias del 3 de noviembre. Esta matriz es de diseño y trazabilidad; no declara ejecuciones aprobadas.

## 1. Alcance sin duplicados

Las 9 HU de 5.6 y las 12 de S2/S5 tienen 2 coincidencias: HU 3.5 y HU 3.7. La unión contiene **19 HU**, cada una con sus criterios. Hay 30 HU en el catálogo canónico, pero no se amplía automáticamente el encargo a todas.

«Eliminar duplicados» significa una fila por HU y reutilizar evidencia que realmente demuestre varios criterios. No significa borrar tests, eliminar historias ni reducir los tres tipos de aportes por integrante. Un caso puede referenciar varias HU; una HU puede requerir varios casos. No existe una exigencia de trazabilidad 1:1 entre HU y test.

S2 comprende HU 1.1–1.6. S5 comprende HU 3.4–3.9. Las seis HU que ya apuntan al capítulo 10 son 2.3, 2.4, 3.2, 3.3, 3.7 y 3.12. La prioridad de exposición S2/S5 no elimina las demás evidencias prometidas en 5.6.

## 2. Matriz maestra de selección

| HU y título canónico | Origen de prioridad | Fila actual en 5.3/5.6 | Celdas ASR de criterios | Capa principal |
|---|---|---|---|---|
| HU 1.1 · Registro con Google | S2 | No / No: preparar filas | `Historias de Usuario!E2:E3` — COPIA ERRÓNEA | Cliente + autenticación + inicialización backend |
| HU 1.2 · Selección de username único | S2 | No / No: preparar filas | `Historias de Usuario!E4:E5` | Usuario / persistencia / UI |
| HU 1.3 · Inicio de sesión persistente | S2 | No / No: preparar filas | `Historias de Usuario!E6:E7` | Cliente / sesión |
| HU 1.4 · Cierre de sesión | S2 | No / No: preparar filas | `Historias de Usuario!E8:E9` | Cliente / sesión |
| HU 1.5 · Visualización de pantalla Home | S2 | No / No: preparar filas | `Historias de Usuario!E10:E11` | Contenido / Home |
| HU 1.6 · Aparición de oración de ejemplo (“Word of the moment”) | S2 | No / No: preparar filas | `Historias de Usuario!E12:E13` | Contenido / ejemplo / Home |
| HU 1.10 · Persistencia del historial entre sesiones | 5.6 | Sí / Sí | `Historias de Usuario!E20:E21` | Progreso / persistencia / cliente |
| HU 2.1 · Visualización de pantalla de escritura y restricciones | 5.6 | Sí / Sí | `Historias de Usuario!E22:E23` | Desafío / pantalla de escritura |
| HU 2.3 · Evaluación automática del párrafo | 5.6 | Sí / Sí | `Historias de Usuario!E26:E27` | Evaluación / adaptador / cliente |
| HU 2.4 · Visualización de retroalimentación detallada | 5.6 | Sí / Sí | `Historias de Usuario!E28:E29` | Estructuración / resultados / cliente |
| HU 3.2 · Obtención de Merit por partida | 5.6 | Sí / Sí | `Historias de Usuario!E34:E35` | Merit / cierre de partida |
| HU 3.3 · Pago de entrada a partidas Ranked | 5.6 | Sí / Sí | `Historias de Usuario!E36:E37` | Cobro Ranked |
| HU 3.4 · Acceso al modo Ranked | S5 | No / No: preparar filas | `Historias de Usuario!E38:E39` | Acceso Ranked / cliente |
| HU 3.5 · Emparejamiento con otro jugador | 5.6 + S5 | Sí / Sí | `Historias de Usuario!E40:E41` | Matchmaking / espera / vencimiento |
| HU 3.6 · Consulta de rating actual | S5 | No / No: preparar filas | `Historias de Usuario!E42:E43` | Perfil / rating / cliente |
| HU 3.7 · Actualización de rating tras una partida | 5.6 + S5 | Sí / Sí | `Historias de Usuario!E44:E45` | Resultado / rating / persistencia |
| HU 3.8 · Visualización del resultado de la partida | S5 | No / No: preparar filas | `Historias de Usuario!E46:E47` | Resultado / cliente |
| HU 3.9 · Consulta de variación del rating | S5 | No / No: preparar filas | `Historias de Usuario!E48:E49` | Variación / cliente |
| HU 3.12 · Validación de restricciones avanzadas | 5.6 | Sí / Sí | `Historias de Usuario!E54:E55` | Restricciones On-Topic / evaluación / cliente |

## 3. Criterios por historia y evidencia que debe obtenerse

Para las nueve HU de 5.3 se transcribe el criterio del informe. Para las otras se transcribe ASR como fuente complementaria pendiente de conciliación con la versión probada. El catálogo JSON conserva ambos textos y las celdas, incluso cuando uno es erróneo; el estado de HU 1.1 impide usar su copia incorrecta. Estas transcripciones no son resultados observados.

### HU 1.1 — Registro con Google

**Fuente utilizable:** informe, S2, y `ACCEPTANCE_REPORT.md` en el commit del backend. **Fuente rechazada:** ASR `E2:E3`, que trata la oración de ejemplo.

**Reconciliación propuesta, no aprobación nueva:** al continuar con Google y autenticar correctamente, inicializar/recuperar el perfil y mostrar la pantalla principal; si falla la autenticación, impedir acceso y mostrar el mensaje de fallo. El reporte del backend menciona 1000 Merit iniciales y `Google sign-in failed. Please try again`; comprobar con código/criterio del cliente y evitar crear de nuevo un perfil existente. No atribuir estos textos a las celdas erróneas de ASR.

**Evidencia a diseñar/ejecutar:** Éxito y rechazo de autenticación reales/controlados; perfil inicial sin duplicaciones; navegación. ASR E2:E3 inválido.

### HU 1.2 — Selección de username único

**Fuente complementaria:** ASR, `Historias de Usuario!E4:E5`.

Dado que soy un usuario e ingreso un username que no existe en la base de datos,
cuando confirmo mi elección,
entonces el sistema debe guardar el username y asociarlo permanentemente a mi cuenta.

Dado que soy un usuario e ingreso un username ya registrado,
cuando intento guardarlo,
entonces el sistema debe impedir el registro y mostrar el mensaje “Username <USERNAME> is already in use”.

**Evidencia a diseñar/ejecutar:** Nombre único, colisión normalizada y rechazo sin sobreescritura; mensaje en UI si se acredita criterio completo.

### HU 1.3 — Inicio de sesión persistente

**Fuente complementaria:** ASR, `Historias de Usuario!E6:E7`.

Dado que soy un usuario que inició sesión previamente,
cuando vuelvo a abrir la aplicación,
entonces el sistema debe restaurar automáticamente su sesión y dirigirlo a la pantalla principal.

Dado que soy un usuario que cerró sesión previamente,
cuando abro la aplicación,
entonces el sistema debe mostrar la pantalla de inicio de sesión.

**Evidencia a diseñar/ejecutar:** Recrear proceso/sesión en condiciones controladas; verificar sesión existente y sesión cerrada. Backend solo no prueba navegación.

### HU 1.4 — Cierre de sesión

**Fuente complementaria:** ASR, `Historias de Usuario!E8:E9`.

Dado que soy un usuario y estoy autenticado,
cuando selecciono la opción “Log out”,
entonces el sistema debe finalizar la sesión y redirigirme a la pantalla de inicio de sesión.

Dado que soy un usuario y estoy autenticado
cuando ocurre un problema al cerrar sesión e intento salir de la aplicación,
entonces el sistema debe mostrar el mensaje “Error when logging out. Please try again”.

**Evidencia a diseñar/ejecutar:** Logout efectivo y fallo inducido; comprobar credenciales/estado y pantalla correspondiente.

### HU 1.5 — Visualización de pantalla Home

**Fuente complementaria:** ASR, `Historias de Usuario!E10:E11`.

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando la sección "Word of the Moment" se carga en la interfaz,
entonces el sistema debe mostrar la palabra destacada con su pronunciación fonética, su tipo de palabra, su rareza, su definición, un botón para reproducir el audio y un botón para usar la palabra en un ejemplo de oración.

Dado que soy un usuario autenticado pero pierdo la conexión a internet al ingresar al "Home",
cuando el sistema intenta recuperar los datos de la palabra del momento desde el servidor,
entonces el sistema debe mostrar el mensaje "The Word of the Moment could not be loaded. Please check your connection" junto con un botón para reintentar.

**Evidencia a diseñar/ejecutar:** Datos de palabra del momento y representación; fallo de carga, mensaje y reintento. No confundir obtener DTO con renderizar Home.

### HU 1.6 — Aparición de oración de ejemplo (“Word of the moment”)

**Fuente complementaria:** ASR, `Historias de Usuario!E12:E13`.

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando hago clic en el botón "Show example sentence",
entonces debe mostrarse una oración de ejemplo que incluya la palabra del momento.

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando hago clic en el botón "Show example sentence" pero el servidor de contenido no responde o falla,
entonces el sistema debe mostrar el mensaje "The example could not be loaded. Please try again".

**Evidencia a diseñar/ejecutar:** Oración vinculada a la palabra y fallo real de proveedor controlado; mensaje observable.

### HU 1.10 — Persistencia del historial entre sesiones

**Fuente:** informe, tabla 5.3.

Dado que el usuario tiene partidas registradas en su cuenta
cuando cierra la sesión activa y vuelve a ingresar posteriormente
entonces el sistema debe de recuperar el historial junto con las estadísticas previamente guardadas.

Dado que soy un usuario registrado y me encuentro en la pantalla de inicio de sesión 
cuando ingreso mis credenciales pero ocurre un fallo en el sistema al intentar recuperar los datos almacenados
entonces el sistema debe mostrar el mensaje “We were unable to retrieve your progress information. Please try again”.

**Evidencia a diseñar/ejecutar:** Historial y estadísticas antes de cerrar sesión y después de reingresar; fallo de recuperación. Mantener Cap. 9.

**5.6 actual:** R1, S3; ubicación `Cap. 9`. Evidencia comprometida: Prueba de persistencia + captura del historial recuperado.

### HU 2.1 — Visualización de pantalla de escritura y restricciones

**Fuente:** informe, tabla 5.3.

Dado que me encuentro en la pantalla de escritura y tengo conexión a internet,
cuando solicito iniciar una nueva práctica,
entonces el sistema me muestra cuatro restricciones activas (por ejemplo, límite de palabras y uso de cuatro palabras de la base de datos).

Dado que me encuentro en la pantalla de escritura pero mi dispositivo no tiene conexión,
cuando intento cargar una nueva partida,
entonces el sistema muestra el mensaje “The action cannot be performed. Please check your Internet connection” y un botón para reintentar.

**Evidencia a diseñar/ejecutar:** Restricciones visibles y fallo sin conexión con reintento. Mantener Cap. 9; distinguir STANDARD/ON_TOPIC.

**5.6 actual:** R1, S1; ubicación `Cap. 9`. Evidencia comprometida: Captura de la pantalla de escritura donde se observen el desafío y las restricciones activas.

### HU 2.3 — Evaluación automática del párrafo

**Fuente:** informe, tabla 5.3.

Dado que envié mi texto correctamente,
cuando R8 termina de procesarlo,
entonces se me asigna automáticamente una puntuación de 0 a 100 basada en coherencia, vocabulario, creatividad y cumplimiento de restricciones.

Dado que el texto ha sido enviado pero el servicio de evaluación supera el tiempo límite de espera,
cuando se cumple el timeout definido,
entonces el sistema muestra el mensaje “The evaluation is taking longer than expected. We'll let you know when your results are ready” y registra el envío para reintento posterior.

**Evidencia a diseñar/ejecutar:** Envío y recepción, puntaje 0–100, timeout, persistencia y reintento. AC-01/02; mock no acredita IA real ni latencia cloud.

**5.6 actual:** R1, S1; ubicación `Cap. 9 / Cap. 10`. Evidencia comprometida: Fragmento de código del adaptador + prueba funcional que evidencie el envío y la recepción de la evaluación.

### HU 2.4 — Visualización de retroalimentación detallada

**Fuente:** informe, tabla 5.3.

Dado que la evaluación de mi texto ha concluido,
cuando el sistema procesa y estructura correctamente los resultados recibidos,
entonces soy redirigido a una pantalla que muestra mi puntaje final, qué restricciones cumplí y comentarios específicos sobre ortografía, vocabulario y coherencia.

Dado que ocurre un error al procesar la estructura del feedback recibido,
cuando soy redirigido a la pantalla de resultados,
entonces el sistema muestra mi puntaje base junto con el mensaje “The detailed feedback could not be loaded at this time”.

**Evidencia a diseñar/ejecutar:** Puntaje, restricciones y feedback; ante estructura parcial conservar base y comunicar fallo. Captura real pendiente de cliente.

**5.6 actual:** R1, S1; ubicación `Cap. 9 / Cap. 10`. Evidencia comprometida: Captura de la pantalla de resultados con la puntuación y retroalimentación de R8 + prueba funcional con un texto evaluado.

### HU 3.2 — Obtención de Merit por partida

**Fuente:** informe, tabla 5.3.

Dado que he completado una partida válida y ha sido evaluado por R8, 
cuando se procesa el resultado de la partida, 
entonces el sistema acredita automáticamente la cantidad correspondiente de Merit en mi cuenta y muestra el monto obtenido.

Dado que he completado una partida válida pero ocurre un fallo en la conexión al servidor,
cuando el sistema intenta acreditar la recompensa,
entonces el sistema debe mostrar el mensaje “Unable to connect to the server”.

**Evidencia a diseñar/ejecutar:** Saldo antes/después, cálculo esperado, recompensa una vez por ID lógico y fallo de servidor. AC-04.

**5.6 actual:** R2, S4; ubicación `Cap. 9 / Cap. 10`. Evidencia comprometida: Prueba funcional que demuestre la acreditación de Merit al finalizar una partida válida + captura del saldo antes y después de la operación.

### HU 3.3 — Pago de entrada a partidas Ranked

**Fuente:** informe, tabla 5.3.

Dado que poseo suficiente saldo Merit en mi cuenta,
cuando selecciono a ingresar a un modo de juego ranked,
entonces el sistema descuenta el monto de entrada correspondiente de mi saldo, actualiza el saldo total y permite el acceso a la partida.

Dado que no poseo suficiente saldo Merit en mi cuenta,
cuando selecciono a ingresar a un modo de juego con tarifa,
entonces el sistema bloquea el acceso y debe mostrar el mensaje “You don't have enough Merit to enter”.

**Evidencia a diseñar/ejecutar:** 99/100/101 Merit, rechazo sin efectos y transacción concurrente; conservar captura de saldo y aviso. AC-05.

**5.6 actual:** R2, S4; ubicación `Cap. 9 / Cap. 10`. Evidencia comprometida: Pruebas funcionales con saldo suficiente e insuficiente + capturas.

### HU 3.4 — Acceso al modo Ranked

**Fuente complementaria:** ASR, `Historias de Usuario!E38:E39`.

Dado que soy usuario autenticado y el saldo Merit para usar el modo Ranked,
cuando selecciono la opción “Play Ranked”,
entonces el sistema descuenta el costo de entrada y inicia una sesión competitiva Ranked, permitiendo ingresar al flujo competitivo.

Dado que soy usuario autenticado pero no tengo el saldo Merit para usar el modo Ranked,
cuando selecciono la opción “Play Ranked”,
entonces el sistema detiene el proceso y muestra el mensaje "The ranked match cannot be started. Insufficient Merit"

**Evidencia a diseñar/ejecutar:** Inicio correcto con débito, saldo insuficiente y acceso bloqueado. Compartir evidencia con 3.3 solo si cubre ambos criterios.

### HU 3.5 — Emparejamiento con otro jugador

**Fuente:** informe, tabla 5.3.

Dado que me encuentro habilitado para jugar Ranked,
cuando termine de escribir mi párrafo,
entonces el sistema me registra en la cola de emparejamiento asincrónico y asigna mi párrafo al de un rival cuyo párrafo también se encontraba en espera de un emparejamiento.

Dado que me encuentro habilitado para jugar Ranked pero no hay párrafos esperando a ser emparejados en la cola asincrónica
cuando pasan 48 horas sin que mi párrafo sea emparejado,
entonces el sistema detiene el proceso, y evalúa mi párrafo con mi puntuación promedio.

**Evidencia a diseñar/ejecutar:** Elegibilidad ±30, no doble emparejamiento, 50 solicitudes concurrentes y resolución tras 48 h con reloj controlado. AC-03.

**5.6 actual:** R2, S5; ubicación `Cap. 9`. Evidencia comprometida: Evidencia del manejo de espera o vencimiento.

### HU 3.6 — Consulta de rating actual

**Fuente complementaria:** ASR, `Historias de Usuario!E42:E43`.

Dado que poseo una cuenta con actividad competitiva,
cuando accedo a mi perfil,
entonces el sistema muestra mi rating actual.

Dado que poseo una cuenta con actividad competitiva pero ocurre un fallo al querer recuperar el rating,
cuando accedo a mi perfil,
entonces el sistema muestra el mensaje "Server failure”.

**Evidencia a diseñar/ejecutar:** Rating vigente visible y fallo de recuperación. Una transformación DTO no acredita por sí sola la pantalla.

### HU 3.7 — Actualización de rating tras una partida

**Fuente:** informe, tabla 5.3.

Dado que he terminado una partida Ranked y cuenta con una evaluación válida,
cuando el sistema procesa los resultados de la partida,
entonces el sistema actualiza el rating según las reglas establecidas.

Dado que una partida Ranked ha finalizado pero hubo un problema al calcular el rating,
cuando el sistema procesa los resultados de la partida,
entonces el sistema muestra el mensaje “The game ranking could not be updated”.

**Evidencia a diseñar/ejecutar:** Rating de ambos jugadores antes/después y fallo; caracterizar regla actual, AC-06 pendiente por discrepancia ELO.

**5.6 actual:** R2, S5; ubicación `Cap. 10`. Evidencia comprometida: Prueba funcional que compare el rating de los jugadores antes y después de una partida.

### HU 3.8 — Visualización del resultado de la partida

**Fuente complementaria:** ASR, `Historias de Usuario!E46:E47`.

Dado que he terminado una partida Ranked, se ha asignado con la de otro usuario y cuenta con una evaluación válida,
cuando se acceda a la pantalla de resultados,
entonces el sistema muestra si fue victoria, derrota o empate.

Dado que una partida Ranked ha finalizado pero hubo un problema al obtener los resultados,
cuando se acceda a la pantalla de resultados,
entonces el sistema muestra el mensaje "The game result could not be updated”.

**Evidencia a diseñar/ejecutar:** Victoria, derrota y empate derivados de datos de partida; fallo observable al recuperar resultado.

### HU 3.9 — Consulta de variación del rating

**Fuente complementaria:** ASR, `Historias de Usuario!E48:E49`.

Dado que he terminado una partida Ranked y se calculó la variación de puntos,
cuando se accede a la pantalla de resultados,
entonces el sistema indica la cantidad de rating perdido o ganado basado en la diferencias de ratings entre los usuarios que fueron emparejados

Dado que una partida Ranked ha finalizado pero no se pudo calcular la variación del rating,
cuando se accede a la pantalla de resultados,
entonces el sistema muestra el mensaje "Server failure”.

**Evidencia a diseñar/ejecutar:** Delta mostrado y coherencia con rating antes/después; fallo de obtención/cálculo. No inventar regla ELO.

### HU 3.12 — Validación de restricciones avanzadas

**Fuente:** informe, tabla 5.3.

Dado que he enviado una respuesta en una partida On-Topic,
cuando R8 procesa mi texto,
entonces el sistema determina cuáles restricciones avanzadas fueron cumplidas y cuáles no.

Dado que he enviado una respuesta en una partida On-Topic,
cuando ocurre un fallo durante la validación de restricciones,
entonces el sistema muestra el mensaje “Compliance with restrictions could not be verified”.

**Evidencia a diseñar/ejecutar:** Textos que cumplen/no cumplen y datos de evaluación incompletos; distinguir regla mecánica y relevancia semántica con IA real.

**5.6 actual:** R2, S6; ubicación `Cap. 9 / Cap. 10`. Evidencia comprometida: Pruebas con textos que cumplen y no cumplen las restricciones + capturas.


## 4. Propuesta de distribución para coordinar

Esta tabla asigna áreas de preparación y defensa futura; no adjudica autoría pasada. Se basa en las especialidades mencionadas y se ajusta a las HU prioritarias. Los roles del informe tienen una advertencia expresa de que proceden de ISW1 y pueden cambiar. Cada paquete debe pasar la verificación de viabilidad de CB, CN y unitarias antes de fijar métodos.

| Integrante | Núcleo propuesto | Búsqueda de métodos/casos | Restricción |
|---|---|---|---|
| Marco Antonio Bocanegra Carrión | Merit y cobro: 3.2/3.3; enlace con 3.4 | `meritReward`, `FirebaseGameRepository.start/complete`; `validateWriting` para fronteras si se incorpora 2.2 | `meritReward` sí es candidato CB en el commit leído. No usar constante `RANKED_COST` como método |
| Pedro Iván Pacheco Castro | Evaluación y feedback: 2.3/2.4/3.12 | `structureEvaluation`, `EvaluateGame`, adaptador R8 | Separar lógica simulada de integración real con OpenAI |
| Víctor Manuel Camarena Paredes | Emparejamiento y actualización: 3.5/3.7 | `Matchmaker`, `matchBaseline`, persistencia | Demostrar transacciones y 50 solicitudes si se acredita AC-03 |
| Jean Carlo de Jesús Rado Delgado | Estados y presentación: 2.1, 3.4/3.6/3.8/3.9 | ViewModels/mappers y operación enlazada de backend | Inspeccionar Inkr8Android actual; no heredar complejidad ni resultados de turron |
| Renzo Ubaldo Adrianzén Vía | Home y contenido: 1.5/1.6 | Casos de uso de contenido, fallos y representación | Si no hay método CB adecuado en esta área, rotar la selección con justificación; no forzar temporadas fuera del alcance |
| Matías Gonzalo Villar Córdova Alva | Usuario, sesión y recuperación: 1.1–1.4/1.10 | Políticas/operaciones de usuario, progreso y cliente | Sesión y navegación necesitan evidencia del cliente, además del backend |

La asignación de una misma HU a varias fichas no duplica resultados. La matriz final debe mostrar preparado por, revisión humana, responsable asignado, ejecutado por el agente y reproducción individual confirmada por separado. La centralización no acredita automáticamente el requisito de participación de los seis.

Si un método necesario justifica incorporar una HU fuera de estas 19 —por ejemplo HU 2.2 para validación y envío— añadir esa HU con su fuente y filas propuestas de 5.3/5.6. No convertir el catálogo de 30 en una orden de probar todo ni asignar 3.14/3.15 únicamente para rellenar un reparto.

## 5. Cambio exacto esperado para 5.3 y 5.6

1. Conservar las nueve filas actuales y sus IDs. Añadir IDs de pruebas y rutas de evidencia únicamente tras ejecutar o declarar el estado pendiente.
2. Para HU 3.5 agregar capítulo 10 cuando se documente la prueba de espera/vencimiento. Mantener capítulo 9 si aporta UI.
3. Para las diez HU de S2/S5 ausentes —1.1–1.6, 3.4, 3.6, 3.8 y 3.9— preparar filas completas, con el criterio rastreable a ASR o la reconciliación explícita de 1.1. El agente entrega las filas; no edita el informe compartido.
4. Si aparece una HU adicional necesaria, documentar la razón y ambas filas. La relación HU–caso es muchos a muchos.
5. Para una HU parcialmente comprobada, especificar qué criterio y qué capa tienen evidencia y qué sigue pendiente. No poner «Completada por pruebas» por tener solo un test unitario del mapper.

Columnas recomendadas para la matriz final: HU, criterio exacto y fuente, release/sprint, diseño, símbolo y commit, tipo e ID de prueba, IDs de casos, entorno, resultado observado, evidencia, límite de la evidencia y pendiente. Las filas para insertar en 5.6 deben conservar también los encabezados de la tabla original.

## 6. Sustentación

Preparar seis guías después de ejecutar. Cada guía debe mostrar una funcionalidad, sus criterios, los diagramas pertinentes, los métodos reales, las tres técnicas y un resultado reproducible. Para una funcionalidad que dependa de varias HU, explicar la cadena y no afirmar que tres tests cubren toda la aplicación.

Reproducir significa ejecutar el comando o procedimiento con los datos previstos y comprobar que se obtiene el resultado registrado. No significa escribir toda la suite de nuevo. La revisión y las aportaciones reales del integrante deben quedar registradas; no presumir que solo ejecutar un comando satisface por completo la participación individual exigida por Wong.

No se confirmó duración de exposición. Entregar una ruta breve y una ampliada sin inventar minutos obligatorios. Usar frases de hechos comprobados, con autoría real y pendientes visibles.
