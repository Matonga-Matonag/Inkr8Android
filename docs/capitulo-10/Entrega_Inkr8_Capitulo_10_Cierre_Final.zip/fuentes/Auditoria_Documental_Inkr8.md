# Auditoría documental y técnica para cerrar las pruebas de Inkr8

**Destinatario:** Marco Antonio Bocanegra Carrión y el agente Codex que ejecutará las pruebas.  
**Corte:** 5 de noviembre de 2026 en Lima / 6 de noviembre UTC.  
**Objeto:** preparar una ejecución acotada del capítulo 10, sus evidencias y su trazabilidad con 5.3, 5.6 y la sustentación de S2/S5. Esta auditoría leyó fuentes y código; **no ejecutó las suites de Inkr8 ni acredita pruebas aprobadas**.

## 1. Resultado y límites de la revisión

El encargo puede empezar por el backend separado. Matías ya comunicó la separación y autorizó a Marco a avanzar. No queda una espera general por esa decisión. Sí quedan decisiones puntuales sobre la interpretación de caja negra, el rating declarado como ELO, el reparto de exposición y las evidencias del cliente Android.

La revisión no consiste en aceptar todo lo que aparece en una carpeta universitaria. Se contrastaron rúbrica, enunciado, plantilla, informe actual, ASR, backlog histórico, material docente, diagramas editables, documentación del equipo y código del backend. La procedencia académica respalda el método y los requisitos, pero una copia de ejemplo, un guion o una tabla antigua no acredita el estado del producto.

| Nivel de revisión | Qué se comprobó | Qué no permite afirmar |
|---|---|---|
| Documental | Texto completo de las fuentes centrales; tablas del DOCX; celdas y formatos de los XLSX; comentarios del informe | Que una funcionalidad marcada «Completada» esté probada hoy |
| Código | Backend en commit fijo, firmas, reglas, suites y comandos declarados | Que compile o que las pruebas pasen en un entorno determinado |
| Diagramas | XML y etiquetas de siete archivos UML del proyecto y un archivo de ejemplos del profesor | Que la geometría, flechas y disposición visual sean correctas; no se renderizaron todos |
| GitHub de Wong | Inventario de 12 repositorios, árboles de 11 proyectos y lectura de archivos de pruebas seleccionados | Que se haya revisado cada archivo de los 12 repositorios |
| Material audiovisual | Inventario de videos de sprints y referencias de coordinación | Que se hayan visto los videos completos o verificado cada contribución individual |
| Frontend actual | URL comunicada por Matías; lectura intentada mediante el acceso conectado, que devolvió 404 | Que el repositorio no exista, que Marco carezca de permiso o que el cliente actual haya sido auditado |

Se incluyen fuentes originales donde se recuperaron y extracciones legibles con procedencia. `fuentes.json`, `catalogo_hu.json` y el manifiesto SHA-256 permiten identificar exactamente qué material se entregó. Los textos extraídos conservan contenido, pero no sustituyen la disposición visual del original cuando esa disposición importa.

## 2. Orden de autoridad y resolución de contradicciones

| Pregunta | Fuente que debe resolverla | Uso de las otras fuentes |
|---|---|---|
| ¿Qué exige la evaluación? | Rúbrica y enunciado vigentes; aclaración explícita del profesor si existe | Las recomendaciones de otras IA no agregan obligaciones docentes |
| ¿Cómo se organiza el capítulo? | Plantilla oficial, secciones 10.1–10.5 | Los ejemplos empleados/pedidos ilustran formato, no Inkr8 |
| ¿Cómo diseñar y demostrar las pruebas? | Material del curso y ejemplos relevantes de Wong | Adaptar conceptos al stack real; no copiar una aplicación Java dentro de TypeScript |
| ¿Cuál es una HU vigente? | Informe, tabla 5.1; contraste con 5.3 y 5.6 | No convertir IDs históricos de 5.2 en historias activas |
| ¿Qué resultado es correcto? | Criterio vigente y regla de negocio aceptada, con referencia | ASR complementa, pero sus errores deben detectarse; el código actual no es automáticamente el oráculo |
| ¿Qué hace hoy el sistema? | Código y ejecución de la versión fijada | Diagramas, guiones y reportes de implementación son declaraciones contrastables |
| ¿Quién hizo qué? | Trabajo y validación realmente realizados, registros y confirmaciones | Ni una asignación futura ni un test generado acreditan participación pasada |

Cuando dos fuentes discrepan, registrar ambas, el impacto y la decisión pendiente. Continuar con las pruebas independientes. No «resolver» una discrepancia cambiando silenciosamente el requisito para que coincida con el código.

## 3. Fuentes universitarias, documento por documento

### 3.1. Rúbrica final del proyecto 2026-2

Fuente: [Rubrica_Final_Proyecto_2026_2.xlsx](https://docs.google.com/spreadsheets/d/1is7IjKY_hLlQKQKVbwEZRHJmNvjo7ORQ/edit). Se revisó texto y archivo original. La celda `Rubrica!D18` contiene el requisito central.

Exige por integrante una prueba de caja blanca sobre módulo o método con complejidad ciclomática mayor a cuatro, una de caja negra sobre funcionalidad que involucre más de cuatro campos de entrada y una unitaria de un método con al menos cuatro casos. Para seis integrantes, el objetivo operativo es **seis paquetes, 18 aportes principales y al menos 24 casos unitarios**. Los casos de caja blanca y negra se cuentan además; 18 no es el total de ejecuciones.

El criterio de pruebas vale dos puntos y condiciona su evaluación a la participación de todos. La preparación centralizada facilita el trabajo, pero no acredita por sí sola la participación individual que la rúbrica pide. Cada integrante debe revisar, comprender y validar su parte de forma real y documentada.

La exposición distribuye cinco puntos en funcionalidad/HU, criterios, clases, secuencia y coherencia del código; tres en pruebas; dos en dominio; diez en talleres individuales. Por ello una guía de sustentación necesita enlazar HU → criterio → diseño → implementación → pruebas, no limitarse a ejecutar un comando.

La rúbrica consultada **no dice explícitamente** que las seis funcionalidades deban ser distintas, que caja negra pueda contar automáticamente estado de base de datos como campos de entrada, que se deban usar tres fórmulas de McCabe, que la cobertura de código deba ser 100 %, ni que haya que ejecutar siete modalidades de rendimiento. «100 %» en ese criterio describe completitud del trabajo, no un umbral técnico universal de cobertura. La independencia de paquetes y el CFG completo son medidas de calidad del plan, no citas textuales de una obligación adicional.

La copia `Rubrica_Final_Proyecto_2026_2_d4a4429f.xlsx`, ID `1b2p53-ks5a3rpw2M2NO9c-dwSbHnlE7T`, produjo el mismo texto. Es duplicado documental; no una segunda exigencia que se deba sumar.

### 3.2. Enunciado del proyecto final

Fuente: [IS2_Enunciado Proyecto Final.pdf](https://drive.google.com/file/d/1mtzc25RgdckC54Tnaym46EFXz0VXqD6P/view), cuatro páginas. Incluido en originales y como texto por página.

Define la entrega completa del equipo: informe R1/R2, código y README, acceso ejecutable, UML editable, anexos, repositorio, configuración pertinente y documentos individuales, incluida la declaración de IA. Sirve para evitar entregar solo capturas o un PDF sin reproducción. Sin embargo, el encargo de este agente sigue siendo pruebas y evidencia: no debe asumir la redacción de todos los capítulos, el despliegue ni la confección de evaluaciones personales de los compañeros.

El sábado 7 de noviembre procede de la coordinación para asesoría utilizada en este chat, no se presenta aquí como fecha oficial extraída del enunciado.

### 3.3. Plantilla de documentación final

Fuente: [Plantilla_Documentacion del Proyecto Final_2026_2.docx](https://drive.google.com/file/d/1xk-NkyYixibJW_MBJuFhYk5fPmwxz1EX/view). Texto recuperado; revisión focalizada en requisitos, arquitectura, pruebas y anexos.

El capítulo 10 pide estrategia; caja blanca con rutas, condiciones, cobertura y resultados; caja negra con datos y resultados observables; unitarias con código, casos, resultados y cobertura; defectos con severidad, impacto, causa y acciones. Esta estructura sí debe mantenerse en el borrador.

Los ejemplos sobre empleados y pedidos son didácticos. Su presencia en el informe del equipo no convierte esas entidades en módulos de Inkr8. El agente no debe escribir pruebas de `Empleado`, `GestorEmpleado` ni pedidos para llenar espacios.

### 3.4. Guía de uso de IA de ISW2

Fuente: [GUIA DE USO DE IA ISW2.pdf](https://drive.google.com/file/d/1HL5O4dvM_CQPv12LX34yrs_fnGjGHgoA/view), 24 páginas. Texto completo y original incluidos.

Los apartados 2.5 y 2.7 permiten apoyo para generación de casos, pruebas y documentación, con ejecución, validación e intervención del estudiante. Los apartados 3 y 5 requieren declarar uso y análisis crítico. La guía distingue estas actividades del uso durante evaluaciones y defensas, donde establece restricciones.

Consecuencia directa: Marco puede centralizar la preparación y utilizar IA como apoyo, pero el expediente debe decir quién preparó, quién revisó, quién ejecutó y quién sustentará. Repartir nombres equitativamente no demuestra autoría ni validación individual. Los guiones deben servir para estudiar resultados reales, no para simular experiencias. No generar porcentajes de intervención humana sin una base revisada por cada estudiante.

### 3.5. Formato de declaración de IA

Fuente: [Declaración y evidencias sobre uso de IA (MODIFICABLE).xlsx](https://drive.google.com/file/d/1BE-fnT0lMZWcQklQBXw-MkQ40gID2aYD/view).

El texto recuperado corresponde a un formato prácticamente vacío: sección, herramienta, finalidad, prompts, respuestas, validación crítica, influencia y estudiante. No constituye una declaración ya cumplida. Codex puede producir un registro factual de sus propias acciones y un borrador para Marco; cada integrante debe confirmar lo que realmente utilizó. No debe marcar validaciones humanas pendientes como realizadas.

### 3.6. Semana 12: pruebas de rendimiento, versión 2

Fuente: PDF adjunto de la Universidad de Lima, 62 páginas; copia `referencias_locales/originales/Semana_12_Pruebas_Rendimiento_v2.pdf`. Se revisó el texto completo y páginas visuales seleccionadas.

| Páginas del PDF | Contenido | Aplicación concreta a Inkr8 |
|---|---|---|
| 1–8 | Motivación y fundamentos | Entender rendimiento como comportamiento medido bajo condiciones definidas |
| 9–11 | Selección de transacciones y requisitos | Elegir evaluación y transacciones críticas; usar objetivos de 6.3 del informe |
| 12–30 | Pruebas estáticas/dinámicas y modalidades de rendimiento | Seleccionar concurrencia para AC-03/04/05; no abrir siete proyectos de prueba |
| 31–36 | Ejercicio, usuarios virtuales, concurrencia y tiempos de espera | Cincuenta promesas o usuarios configurados no prueban por sí solos cincuenta solicitudes solapadas |
| 37–47 | Latencia, tiempos, tasas y percentiles | Separar acuse HTTP, evaluación asíncrona completa y representación en Android |
| 48–54 | Cálculos y perfiles de carga | Definir volumen, duración, rampa y datos con justificación |
| 55–58 | Parametrización, aserciones y análisis | Validar primero una operación y luego aumentar carga; verificar efectos de negocio |
| 59–62 | Referencias y cierre | Material de apoyo; no nuevos criterios particulares de Inkr8 |

Los ejemplos de TVendoApi —20 usuarios, p95 de dos segundos o error de uno por ciento— no son umbrales de Inkr8. El informe tiene objetivos propios. Medir un evaluador simulado localmente es útil para probar el flujo, pero no demuestra el tiempo de GPT-4o mini en Cloud Functions con 4G/WiFi.

### 3.7. Sílabo, semanas 7 y 8 y práctica adicional

Se recuperó el sílabo `1327_8772bd8d.pdf` y se revisaron sus partes de pruebas; confirma que el curso aborda caja blanca, caja negra, unitarias, integración y rendimiento. No reemplaza las diapositivas específicas de cada técnica.

Las presentaciones de Semana 7 —arquitectura— y Semana 8 —documentación de arquitectura— se revisaron de forma focalizada. Refuerzan trazabilidad y niveles de diseño. No autorizan a este agente a rediseñar la arquitectura para hacer las pruebas más cómodas.

El archivo `d2cda404-8d38-40a7-a516-2729dc24d91f.pdf` corresponde a un ejercicio de creación de pagos/Factory. No es el PPT de unitarias y no debe presentarse como tal.

No se localizó el PPT específico de pruebas unitarias en el material accesible revisado. Blackboard no se consultó. Esta ausencia queda registrada; la rúbrica, plantilla y pruebas reales de Wong permiten iniciar sin pedir contraseñas ni detener todo el encargo.

### 3.8. Ejemplos UML del profesor en Drive

Fuente: [ISW2_Ejemplos_del_profe.drawio](https://drive.google.com/file/d/1sqd9HPSloUdyWRXzukczum_YI1NMhgrX/view), modificado el 18 de octubre. Se leyeron las seis páginas: Vista Funcional, Vista Lógica, Vista Implementación, Vista Despliegue, C4 y Diseño Software Detallado.

El ejemplo de gestión de productos conecta HU, componentes, mensajes REST y elementos de implementación. En C4 explica que abrir un contenedor muestra componentes de otro nivel; mezclar niveles produce una falsa correspondencia. Para la defensa de Inkr8 esto exige indicar qué nivel representa cada diagrama y enlazar mensajes a símbolos reales. No implica que Inkr8 deba usar Java 25, PostgreSQL, Angular o las entidades del ejemplo.

El archivo se examinó semánticamente desde XML. Algunas etiquetas C4 son dinámicas; no se usa esta extracción para certificar la apariencia visual del diagrama.

## 4. Informe de Inkr8, sección por sección

Fuente actual: [ISW2 Proyecto - Informe - Grupo 3.docx](https://docs.google.com/document/d/1szkfADu3mH3yxLkgX2QIB7BGjMtAwBm4/edit), última modificación recuperada `2026-11-05T23:55:29.015Z`. Se descargó el DOCX actual, se extrajo su texto y se inspeccionaron sus 84 tablas. La fecha antigua de portada no prevalece sobre la versión efectivamente recuperada.

| Sección | Hallazgo comprobado | Decisión para Codex |
|---|---|---|
| 1.2.2 frente a 1.3 y 5.1 | Un párrafo antiguo excluye Ranked/matchmaking aunque el alcance vigente los incluye | Mantener Ranked y matchmaking; registrar corrección documental propuesta |
| 2.2, roles | Roles contienen funciones antiguas; comentario de Matías dice que vienen de ISW1 y están sujetos a cambios | Usarlos como orientación, nunca como reparto definitivo ni prueba de contribución |
| Capítulo 3 | Hay métricas declaradas que no son logs de esta auditoría | No reutilizar cifras como evidencia de pruebas actuales |
| 4.2, S2 | HU 1.1–1.6: autenticación, username, sesión, Home y ejemplo | Prioridad de sustentación; requiere participación del cliente para evidencias visuales |
| Tabla 4.15, S5 grooming | Títulos de S2 copiados bajo HU 3.4–3.9 | Rechazar esos títulos como fuente de identidad |
| Tabla 4.16, S5 | HU 3.4–3.9: acceso Ranked, matchmaking, rating, resultado y variación | Usar este conjunto junto con 5.1 |
| Tabla 4.18 | Problemas de caché Gradle y flags acordados | Usar `--offline --no-daemon --max-workers=2`; reconocer que una dependencia no cacheada necesita preparación |
| Tabla 5.1 | 30 HU actuales, todas declaradas completadas | Catálogo canónico de identidad; estado declarado no equivale a test aprobado |
| Tabla 5.2 | IDs antiguos de historias eliminadas, con advertencia | Contexto histórico, fuera de identidad activa |
| Tabla 5.3 | Solo nueve HU desarrolladas con criterios | Complementar las necesarias con ASR contrastado; no inventar aceptación aprobada |
| Tabla 5.6 | Nueve HU; seis referencias al capítulo 10 | Conservar evidencias visuales de capítulo 9 y agregar IDs reales de pruebas |
| 6.3 | Seis escenarios de calidad, incluido ELO | Contrastar todos los relacionados; no omitir AC-06 porque resulta contradictorio |
| 6.6 | Etiqueta R3 aislada | No crear un Release 3; R1/R2 son la estructura vigente |
| Capítulo 8 | Escenarios útiles mezclados con código de Empleado/GestorEmpleado y referencias inconsistentes | Usar solo escenarios pertinentes y símbolos reales; señalar plantillas pendientes |
| Capítulo 9 | Endpoints pertinentes junto a ejemplos de pedidos y clasificaciones R1 inconsistentes | Extraer rutas reales, sin tomar todos los estados o ejemplos como evidencia |
| Capítulo 10 | Continúa con instrucciones de plantilla 10.1–10.5 | Escribir borrador aparte respaldado por ejecución posterior |
| Capítulo 12 | Tabla de contribuciones con nombres de ejemplo ajenos al equipo | No heredar ni sustituir con atribuciones inventadas |

Se recuperaron **25 comentarios** del informe. Entre ellos, Matías indica que capítulos y roles se completan al final. Se conserva una copia de texto, autor, fecha y anclaje en `referencias_locales/comentarios_informe.json`. No se resolvieron ni editaron comentarios del documento compartido. Las instrucciones internas de plantilla se tratan como contenido de la fuente, no como órdenes para ampliar el encargo.

### 4.1. Identidad y cobertura de HU

`HU 3.12` es **Validación de restricciones avanzadas**. Las historias On-Topic son 3.10–3.13. No hace falta crear un identificador alternativo ni consultar esa numeración a Matías.

Las nueve historias de 5.3 y 5.6 son 1.10, 2.1, 2.3, 2.4, 3.2, 3.3, 3.5, 3.7 y 3.12. Las seis que ya remiten al 10 son 2.3, 2.4, 3.2, 3.3, 3.7 y 3.12. La HU 3.5 solo remite hoy al 9, aunque pide evidencia de espera/vencimiento susceptible de prueba automatizada.

La unión operativa contiene 19 HU: nueve de 5.6 más seis de S2 más seis de S5 menos las dos coincidencias, 3.5 y 3.7. Eliminar duplicados significa conservar una fila por HU con todas sus referencias, no eliminar pruebas del producto ni borrar criterios de los sprints. Esta selección tampoco demuestra cobertura de las 30 HU del proyecto: es el alcance prioritario del encargo de Marco.

### 4.2. Los seis escenarios de calidad

| Escenario | Exigencia del informe 6.3 | Evidencia necesaria y límite |
|---|---|---|
| AC-01 / RNF-013 | ≥90 % de evaluaciones completadas en ≤5 s en entorno normal con IA operativa | Medir flujo hasta evaluación persistida/notificada; declarar red, entorno y fallos. Mock local no acredita este requisito cloud |
| AC-02 / RNF-014 | Timeout de 90 s o fallo de cuota/disponibilidad; persistencia, reintento y aviso | Probar timeout y error de servicio por separado. El código difiere en esas ramas; no extrapolar una a otra |
| AC-03 / RNF-021 | Cero emparejamientos dobles/inconsistentes con 50 solicitudes concurrentes, delta ≤30 | Transacciones reales en emulador, solapamiento documentado, invariantes antes/después; no confundirlo con dos llamadas |
| AC-04 / RNF-018 | Cero recompensas duplicadas para una partida lógica | Repeticiones y concurrencia con el mismo ID; comprobar saldo y estado final |
| AC-05 / RNF-019 | Débito de 100 Merit, rechazo de insuficiencia y cero saldos negativos | Límites 99/100/101 y operaciones concurrentes que compitan por saldo; comprobar efectos, no solo error |
| AC-06 / RNF-024 | Fórmula oficial de ELO con probabilidad esperada y exactitud matemática | Contradice `ratingChange()` actual. No declarar aprobado; decidir regla aceptada y después probarla |

La discrepancia de AC-06 es documental/técnica comprobada por lectura. Su corrección puede ser cambiar el requisito con aprobación del equipo o cambiar el producto tras acordar la regla. Este encargo no elige unilateralmente entre esas alternativas.

## 5. ASR y backlog, documento por documento

### 5.1. ASR_Inkr8.xlsx

Fuente: [ASR_Inkr8.xlsx](https://drive.google.com/file/d/17wVdS2EbGt98Ot_p8umTdqfmR65LuzWw/view), modificado el 1 de noviembre. Se recuperó el original y se inspeccionaron las 16 hojas, con detalle en historias y escenarios de calidad.

La hoja `Historias de Usuario` contiene criterios para las 30 historias. Permite recuperar material para las diez HU prioritarias que aún no tienen fila en 5.3. No es necesario inventar todos esos criterios. Deben conservarse sus celdas y contrastarse con el informe.

**Error de contenido:** `D2` describe registro con Google, pero `E2:E3` contiene criterios de mostrar una oración de ejemplo. También están en la HU 1.6. No son criterios válidos de registro. La propuesta de reconciliación para HU 1.1 debe basarse en S2 del informe y en `ACCEPTANCE_REPORT.md`, registrando la procedencia y la discrepancia. No editar ASR silenciosamente.

**Riesgo de extracción:** `B20` almacena el número 1.1 con formato `0.00` y representa HU 1.10; `B50` almacena 3.1 con el mismo formato y representa HU 3.10. En cambio `B2` y `B32` usan formato general para HU 1.1 y HU 3.1. Un programa que convierta el número directamente a texto confundirá historias distintas. El catálogo incluido usa los IDs de 5.1 y conserva celda, valor y formato originales.

La descripción de épicas conserva torneos en algunos textos, aunque ya no son alcance vigente. Los escenarios de calidad repiten la promesa de ELO; su repetición en otra hoja no demuestra que el código la implemente.

### 5.2. Product Backlog e Historias de Usuario.xlsx

Fuente: [Backlog histórico](https://drive.google.com/file/d/1ZPy_KY9p2CkyQn_44FUVzm20EdgURywA/view), modificado el 28 de octubre. Cuatro hojas con material antiguo y actual mezclado.

Hay IDs almacenados como fechas Excel con formato `d\.m`: por ejemplo, la fecha numérica subyacente no debe interpretarse como fecha de la HU. Incluye historias retiradas, textos anteriores y criterios en otro idioma. Repite el error de Google/oración de ejemplo. Sirve para rastrear decisiones pasadas; no debe reemplazar 5.1 ni suministrar todos los oráculos de pruebas nuevas.

## 6. Diagramas de Inkr8, archivo por archivo

Las fuentes editables están en la [carpeta UML](https://drive.google.com/drive/folders/1ir5UzaiRPu7uBPesvSm6z0al9MCWUx6S). Se conservan sus IDs como nombres de archivo para evitar atribuir una exportación a otra fuente.

| Archivo / ID de Drive | Lectura y hallazgo | Tratamiento |
|---|---|---|
| Secuencias `1W7ebqUynQu_ufuR_xnCQH24ipOrIzS4h` | Cinco páginas: HU 1.1–1.4; 1.5/1.6; 3.4/3.5; 3.5/3.7; 3.6/3.8/3.9. Usa Inkr8Android e Inkr8BackEnd | Fuente útil para S2/S5. Sus mensajes son a veces de sistema, no nombres exactos de método; enlazar a código |
| Clases `1Qto-RwDQKev87DFfJQetes5yMznxEsPl` | Page-1 conserva torneos/reputación; Page-2 contiene material ajeno de visión por computador; Page-3 lista componentes/políticas del backend | Revisar por página. No declarar el archivo entero vigente. Page-3 también necesita contraste clase vs función exportada |
| Vista lógica `1d_tOqrM6QWSf6GH0F7eS2Ifbx7s2VmgE` | Páginas Paquetes y Componentes, nombres de repos separados | Ayuda a ubicar responsabilidades; no prueba implementación ni cobertura |
| Casos de uso de negocio `1qUUibyQOaFhrah5zgxumR3qXmrPQRnpN` | Vista alta de las tres épicas | Contexto del propósito, insuficiente para datos/expectativas de casos concretos |
| Despliegue `1-FpacVSQ1YTbnGVCSrS1oKe2gCrIoyyQ` | Android, Node 20, Functions, Firestore, OpenAI y Scheduler | Arquitectura declarada. No certifica que el despliegue esté disponible ni su latencia |
| Componentes diseño `1TaEZtA7oPnOsCEQFR71HWJLNGgoaOKxb` | Fronteras de aplicación e integraciones | Usar nombres consistentes en las fichas de pruebas |
| Componentes implementación `1njfLfKdQ8sgGqIxiVwCoPJCfCJqlLBLz` | Dependencias de implementación | Contrastar con rutas reales del commit |
| PlantUML `1VPGoGeMQZ58SYNB1TU2e2AQjAOC1CJMI` | Fuente completa: frontend, backend, autenticación, Firestore, OpenAI y Scheduler | Referencia editable; las relaciones invisibles de disposición no son comunicaciones |

Los PNG inventariados son exportaciones antiguas frente a algunos editables de noviembre. No se usan como versión actual sin compararlos. La otra carpeta llamada «Diagramas draw.io» apareció vacía en la lectura disponible. El trabajo de pruebas debe registrar los desajustes y entregar enlaces; no rehacer todos los diagramas del equipo.

## 7. Coordinación, contribución y documentación histórica

### 7.1. Mensajes de Matías

Las capturas facilitadas confirman separación y autorización para avanzar. El backend está en una **rama** llamada `Inkr8BackEnd` del repositorio existente; el frontend es otro repositorio, `Inkr8Android`. La sugerencia de renombrar el repositorio completo no es una orden para que el agente lo renombre.

La prioridad S2/S5 procede de la coordinación anterior de la exposición. No se verificó una consigna docente escrita que reduzca todo el capítulo 10 a esos sprints. Por ello se conserva el cruce con las nueve HU de 5.6. Tampoco hay confirmación de seis funcionalidades individuales ni duración por persona.

### 7.2. Evaluación por pares y su plantilla

Fuente: [Calificación por pares del Grupo 3](https://drive.google.com/file/d/1w4PnOl2d3LPi9paHwt3eKcxL9bxHrpvE/view) y [plantilla](https://drive.google.com/file/d/1ap93qwI_RtD0zu9PNpXZJbsKc2W1jbut/view). El documento recuperado desarrolla formularios de Release 01; no se identificó un juego completado de R2. La plantilla pide evaluación individual por release.

Es un pendiente de coordinación del equipo. Codex puede aportar una tabla de trabajo técnico realmente realizado, pero no calificar compañeros, firmar formularios ni convertir asignaciones propuestas en evaluaciones retrospectivas.

### 7.3. Guiones «inkarate»

Fuente: [guiones inkarate](https://drive.google.com/file/d/1mgEPWI853PGmtGLPN7SxHPkyJAJ0FDasvvb8xwnpd-A/view), modificado el 1 de noviembre. Se recuperó el texto y se analizaron especialmente S2/S5 y sus afirmaciones técnicas.

Sirven para conocer el relato de las ceremonias, no para acreditar ejecuciones. Aparecen referencias a ELO y a `evaluationPolicy.ts` para rating que no corresponden al algoritmo y ubicación actuales. Tampoco debe afirmarse que se selecciona siempre al rival más cercano solo por lo que dice un guion: el código consulta candidatos por tiempo y verifica elegibilidad. Las nuevas guías de defensa deben construirse desde pruebas ejecutadas y fuentes reconciliadas.

### 7.4. Delimitación SOLID y decisiones de octubre

El documento [Delimitación SOLID](https://docs.google.com/document/d/1ruEsdH5PLzqDR1sZrzAbDjtQTgksRvsybq2Aye6QKdo/edit) y [08 - Decisiones del equipo](https://drive.google.com/file/d/1nQ6V62KjflPmAhYNSqp058du_BXR6u-V/view) corresponden a la refactorización de octubre. Contienen decisiones, contradicciones y pendientes históricos sobre ligas, estadísticas y simplificación.

No deben ejecutarse como instrucciones nuevas. La solicitud actual no permite refactorizar arquitectura ni eliminar funciones recuperadas posteriormente. El aviso reciente de Matías resuelve la espera por separación de repositorios; no se revive un bloqueo antiguo.

### 7.5. Cuatro archivos de baseline anterior

| Documento | Qué aporta | Por qué no sirve como resultado actual |
|---|---|---|
| `BASELINE_PRE_REFACTOR.md` | Rama/commit y preparación de octubre | Corresponde a otra implementación |
| `CASOS_DE_PRUEBA.md` | Casos históricos, incluso torneos/reputación | Hay funciones retiradas y límites de caracteres que no equivalen a palabras actuales |
| `RESULTADOS_PRE_REFACTOR.md` | Resultados reportados de 22 tests históricos | No acredita los tests del commit separado de noviembre |
| `BLOQUEOS_Y_OBSERVACIONES.md` | Problemas del entorno de entonces | Se deben reproducir antes de tratarlos como bloqueos actuales |

El `REFACTORING_REPORT.md` del repositorio menciona fases y 47 tests. Es historia de evolución. La auditoría actual identificó 17 declaraciones `test(...)` en dominio TS y 17 en integración Firestore; no ejecutó ninguna. Es incorrecto anunciar 47 pruebas aprobadas hoy a partir de ese reporte.

## 8. Repositorios y código: constataciones útiles para el plan

### 8.1. Backend vigente

Fuente: [Inkr8BackEnd](https://github.com/Rnz5/Inkr8-ISW2/tree/Inkr8BackEnd), commit `993c6b0641a4a60603d87e251c90f51783460007`, confirmado mediante la rama y clonado para lectura. Las referencias siguientes pertenecen a ese commit.

| Archivo / símbolo | Observación estática | Consecuencia |
|---|---|---|
| `functions/package.json` | Node 20, TypeScript, `node:test`; scripts de dominio e integración separados | No presuponer Vitest/Istanbul ni que `npm test` ejecuta integración |
| `gamePolicy.ts:15`, `meritReward` | Validación, seis ternarios de tramo y ternario Ranked | Candidato válido de complejidad; cuantificar con CFG antes de documentar caminos |
| `gamePolicy.ts:5`, `league` | Cinco decisiones de umbral | Candidato alternativo sencillo con V(G)=6 bajo convención de ternarios |
| `gamePolicy.ts:9`, `validateWriting` | Dos argumentos; 50–150 palabras STANDARD, 50–200 ON_TOPIC, tope de 10 000 caracteres | Excelente unidad de fronteras; no son cinco campos de caja negra |
| `gamePolicy.ts:20`, `ratingChange` | Ajuste lineal limitado, resultados y topes; sin fórmula de probabilidad esperada ELO | Separar caracterización de código y conformidad con AC-06 |
| `gameUseCases.ts:31`, `EvaluateGame` | Timeout → `defer`; otros errores → `fail` | Investigar si cuota/disponibilidad cumplen recuperación prometida; no extrapolar timeout |
| `firebaseGameRepository.start/complete` | Transacciones y protección por estado/ID | Usar emulador para atomicidad e idempotencia; mocks no prueban Firestore |
| `matchmaker.ts` | Filtro de rating y transacciones; orden temporal de candidatos | No afirmar selección del más cercano ni 50 solicitudes probadas sin ejecución |
| `matchBaseline.ts` | Resolución histórica tras espera; promedio del jugador | Controlar reloj y datos; no dormir 48 horas ni usar baseline fijo antiguo |
| `userDto.ts`, `mapUser` | Mapeo con varios campos observables | Candidato interno posible para CN; delimitar contrato y aceptación docente pendiente |

Para `meritReward`, el recuento orientativo da V(G)=9 si el `if` compuesto se modela como una sola decisión, o V(G)=11 si sus dos `||` se descomponen en decisiones de cortocircuito. Ambos superan cuatro. El agente debe escoger una convención, representar ese mismo flujo y demostrar los caminos; estas cifras no son un reporte de herramienta ejecutada.

En la referencia histórica Kotlin consultada, `GamePolicy.validateWriting` no justificaba asumir V(G)≥5; no se debe intercambiar automáticamente con `meritReward`. Además, esa lectura histórica no certifica el código de Inkr8Android actual.

La suite de integración contiene una expectativa `/insuficiente/`, mientras `start` lanza un mensaje en inglés con `Insufficient Merit`. Es un **posible fallo de expectativa identificado por lectura**, todavía no un test fallido observado. Ejecutarlo, revisar el criterio aplicable a la capa y corregir la expectativa si corresponde; no debilitar todas las aserciones para que pasen.

Los tests existentes incluyen repetición de cobro y recompensa con cinco llamadas y un caso de emparejamiento concurrente pequeño. No cumplen automáticamente la demostración específica de 50 solicitudes de AC-03.

### 8.2. ACCEPTANCE_REPORT.md

Declara 60 escenarios para 30 HU y menciona `AcceptanceCriteriaSuiteTest.kt` y `AcceptanceShowcaseDialog.kt` del cliente. Debe usarse como mapa de intención y localizar los tests reales. La rama de backend no contiene esos archivos Android.

El botón «Demostrar Mensaje» muestra un texto de error. Eso puede servir para comprobar presentación, pero no demuestra que el sistema detecta el fallo, conserva datos o reintenta. Una prueba válida induce el fallo en una dependencia controlada o entorno apropiado, atraviesa la operación real y comprueba estado y salida. No contar 60 filas declaradas como 60 escenarios ejecutados.

### 8.3. Fronteras reales para caja negra

`startGame` expone tres campos en su payload público; `submitGame`, dos. `EvaluateGame.execute(id)` recibe uno y `ResetLeagues.execute()` ninguno. La existencia de usuarios, reloj, saldo, temporada o campos en Firestore no aumenta automáticamente esos payloads.

Se pueden investigar contratos internos que reciban objetos con varios campos efectivos: `structureEvaluation(game, result)`, `FirebaseGameRepository.start`, `complete`, `mapUser`, el adaptador de evaluación o mappers Android actuales. Para cada uno, demostrar frontera, cinco campos independientes recibidos y utilizados, regla observable y oráculo. Un argumento sobrescrito internamente, un campo de salida o cinco elementos del mismo arreglo no justifican cinco campos por sí solos.

Que los ejemplos de Wong usen API y mocks permite respaldar esas técnicas. No demuestra que acepte cualquier contrato interno para la condición de cinco entradas. Conservar esa interpretación como consulta docente delimitada, sin detener las demás pruebas ni declarar seis funcionalidades válidas antes de auditarlas.

### 8.4. Frontend, rama histórica y otros proyectos

`Matonga-Matonag/Inkr8Android` queda por inspeccionar en el entorno de Codex con el acceso de Marco. Hasta entonces no hay commit Android actual, cobertura Kotlin medida ni verificación del catálogo de aceptación visual. Las copias históricas de `turron` sirven solo para orientar búsquedas.

Merca (`MACOABC/ecommerce-microservicios`) y el Canva enlazado de ese proyecto quedaron fuera del encargo corregido. Se registran como referencias ajenas; no se usan como implementación ni evidencia de Inkr8. No se afirma haber auditado su código o todas sus páginas en esta revisión.

## 9. GitHub de Henry Wong

Se incorpora como fuente docente de primera mano, con detalle por repositorio y archivo en [Referencia_Henry_Wong_Inkr8.md](Referencia_Henry_Wong_Inkr8.md). Sus aportes principales son organizar casos por contrato, controlar dependencias, comprobar errores y efectos, y enlazar diseño con implementación. Los ejemplos vacíos y los proyectos de otra materia se descartan como evidencia de pruebas sustantivas.

## 10. Decisiones concretas que quedan abiertas

| Pendiente | Acción mientras se resuelve | Quién debe confirmar |
|---|---|---|
| Acceso/commit Android | Completar backend y dejar lista exacta de evidencias de cliente | Marco o responsable del repositorio en el entorno de ejecución |
| Rating oficial ELO vs regla propia | Caracterizar regla actual y preparar contraste; no marcar AC-06 conforme | Matías/equipo y, si procede, docente |
| Cinco entradas de un contrato interno para CN | Entregar candidatos comprobados, casos y frontera explícita | Wong |
| Reparto y tiempo de exposición S2/S5 | Propuesta de seis fichas, sin atribuir trabajo pasado | Matías/equipo |
| HU 1.1 con criterios copiados | Propuesta trazada desde S2 y ACCEPTANCE_REPORT; aislar celdas erróneas | Responsable de requisitos |
| Pruebas reales de IA y latencia cloud | Ejecutar flujo determinista local, rotulado con su alcance | Equipo cuando facilite un entorno de prueba apropiado |
| PPT específico de unitarias | Aplicar rúbrica y ejemplos de Wong disponibles | Marco si el material está en Blackboard |

Estas son consultas puntuales. No se debe pedir una confirmación general para empezar ni abandonar el encargo porque una parte siga pendiente.

## 11. Qué debe producir la siguiente ejecución

El resultado esperado es código de pruebas revisable, logs y cobertura reales, capítulo 10 en borrador, seis fichas individuales, matriz HU–criterio–caso–evidencia y filas propuestas de 5.3/5.6. Cada resultado debe distinguir diseñado, ejecutado aprobado, ejecutado fallido, bloqueado y pendiente de validación docente. Los límites de una prueba local, de un mock o de una captura tienen que quedar junto a la afirmación que sustentan.

La entrega puede estar terminada como **paquete de trabajo revisable** y conservar defectos o decisiones pendientes. Eso no equivale a que el producto y la rúbrica estén totalmente conformes. Codex debe informar ambos estados por separado.

## 12. Revisión de los planes y sugerencias de otras IA del chat

Las observaciones externas ayudaron a descubrir riesgos reales, pero se trataron como hipótesis para contrastar. Esta es su disposición final frente a las fuentes actuales:

| Sugerencia del chat | Resultado del contraste | Cambio incorporado |
|---|---|---|
| Corregir la numeración de HU 3.12 sin inventar ID alternativo | Confirmado en 5.1/5.3/5.6 | Se usa identidad canónica |
| Advertir que 5.3/5.6 solo contienen nueve HU | Confirmado | Matriz exacta y filas adicionales para S2/S5 |
| Intercambiar automáticamente `meritReward` por `validateWriting` | La premisa no se cumple en backend actual; `meritReward` tiene suficientes decisiones | Se calcula complejidad real y no se fuerza intercambio |
| Dar por existentes seis contratos con cinco campos | No confirmado; varias firmas propuestas tienen menos argumentos o ninguno | Auditoría de frontera y propiedades efectivas antes de aceptar CN |
| Contar payload más estado de precondición como cinco entradas | No está autorizado expresamente por la rúbrica | Distinguir entradas/precondiciones y consulta puntual a Wong |
| Añadir flags Gradle del equipo | Confirmado en retrospectiva | Se incluyen, explicando límite de caché offline |
| Exigir tres fórmulas de McCabe como requisito del profesor | No consta así en las fuentes centrales recuperadas | Contraste matemático como calidad del plan; regiones solo cuando aplica |
| Añadir cobertura real y comandos | Correcto como necesidad de evidencia | Se usa runner real Node/Gradle; no se inventa Vitest/JaCoCo configurado |
| Preasignar por roles oficiales sin reservas | Los roles tienen comentario de que vienen de ISW1 y pueden cambiar | Reparto propuesto, ajustado a S2/S5 y viabilidad |
| Copias locales para evitar barreras de Google | Útil | Se entregan originales actuales y extractos con fuente |
| 18 pruebas totales como cifra de ejecución | Ambiguo: son 18 aportes principales, cada uno con casos | Se separan paquetes, técnicas, casos y ejecuciones |
| Filas HU–test en relación 1:1 | Demasiado rígido y no exigido | Trazabilidad muchos a muchos con criterios explícitos |
| «Solo queda esperar a Matías» | Superado por su mensaje de separación y autorización | Inicio independiente del backend; consultas delimitadas |

El aporte mayor de esas revisiones fue mejorar trazabilidad y controles de evidencia. Los errores restantes provenían de asumir propiedades del código sin inspeccionarlo o convertir interpretaciones en requisitos docentes. El nuevo paquete conserva las mejoras comprobadas y elimina esas suposiciones.
