# Paquete de Jean Carlo

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Jean Carlo de Jesús Rado Delgado. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Contrato de evaluación y representación de resultados. HU trazadas (vínculo de alcance, no criterio demostrado): HU 2.3, HU 3.6, HU 3.8, HU 3.9.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | league | V(G) = 6; 6 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | OpenAiWritingEvaluator.evaluate | 6 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | league | 12 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

Contrato WritingEvaluator y requisito de suministro de restricciones al evaluador. Las aserciones sobre JSON/modelo/timeout son de contrato/configuración actual; no demuestran calidad semántica de OpenAI ni latencia cloud. league caracteriza sus seis tramos.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-JEA-01.md). Alcance: La función league del backend clasifica el rating en seis tramos. El cliente tiene una función homóloga, pero este CFG pertenece únicamente al commit TypeScript indicado. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra

Frontera interna probada: `OpenAiWritingEvaluator.evaluate`. Firma y uso se revisaron en el commit fijado. Los cinco o más campos no representan cinco controles de pantalla.

| Campo | Tipo/dominio | Clases válidas | Inválida o fuera de contrato | Límites | Efecto observable |
|---|---|---|---|---|---|
| game.writingMode | enum | STANDARD / ON_TOPIC | fuera del contrato tipado | No aplica | JSON writingMode y maxWords |
| game.content | string | Texto controlado / Otro texto | texto semánticamente inválido requiere IA real | longitud se verifica antes, no aquí | submission |
| game.challenge.words | Word[] | ON_TOPIC: dos términos; STANDARD: cuatro; sustitución de un término | fuera de esquema no se exige validación nueva | un campo, no dos por elementos | requiredWords |
| game.challenge.topic | string/null | Nature / null | No aplica como invalidez; null es válido | No aplica | topic en request |
| game.challenge.theme | string/null | Life / Technology / null en STANDARD | No frontera de aceptación definida | No aplica | theme en request |
| game.challenge.advanced | string[] | dos reglas / [] | no son controles de UI ni predicados propios | No aplica numérica | advanced en request |

Las particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/functions/test/adapter.capitulo10.test.cjs`.

La base ON_TOPIC contiene dos palabras y un texto controlado de 50 palabras. La variante STANDARD cambia conjuntamente a cuatro palabras, topic y theme nulos y advanced ausente; mantiene las aserciones maxWords = 150, cuatro requiredWords, topic nulo y advanced vacío. La variante de words conserva dos palabras completas y cambia un término. Se observa el request y la respuesta de un SDK simulado; la reserva anterior del fixture STANDARD quedó corregida.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| CN-JEA-01-C01 | CN-JEA-01-C01 adaptador recibe seis campos efectivos y configura timeout 90000 sin retries SDK | Ejecutado aprobado | 5.7821 | [línea 12](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C02 | CN-JEA-01-C02 campo writingMode influye en request | Ejecutado aprobado | 0.7318 | [línea 17](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C03 | CN-JEA-01-C03 campo content influye en request | Ejecutado aprobado | 0.3233 | [línea 22](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C04 | CN-JEA-01-C04 campo words influye en request | Ejecutado aprobado | 0.2843 | [línea 27](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C05 | CN-JEA-01-C05 campo topic influye en request | Ejecutado aprobado | 0.2798 | [línea 32](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C06 | CN-JEA-01-C06 campo theme influye en request | Ejecutado aprobado | 0.218 | [línea 37](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C07 | CN-JEA-01-C07 campo advanced influye en request | Ejecutado aprobado | 0.2136 | [línea 42](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C01 | UT-JEA-01-C01 league 0 -> 1 / CB-JEA-01-P1 | Ejecutado aprobado | 0.3679 | [línea 297](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C02 | UT-JEA-01-C02 league 30 -> 2 / CB-JEA-01-P2 | Ejecutado aprobado | 0.2594 | [línea 302](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C03 | UT-JEA-01-C03 league 60 -> 3 / CB-JEA-01-P3 | Ejecutado aprobado | 0.248 | [línea 307](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C04 | UT-JEA-01-C04 league 90 -> 4 / CB-JEA-01-P4 | Ejecutado aprobado | 0.3216 | [línea 312](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C05 | UT-JEA-01-C05 league 120 -> 5 / CB-JEA-01-P5 | Ejecutado aprobado | 0.2589 | [línea 317](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C06 | UT-JEA-01-C06 league 150 -> 6 / CB-JEA-01-P6 | Ejecutado aprobado | 0.259 | [línea 322](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C07 | UT-JEA-01-C07 league 29 -> 1 | Ejecutado aprobado | 0.2654 | [línea 327](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C08 | UT-JEA-01-C08 league 59 -> 2 | Ejecutado aprobado | 0.2429 | [línea 332](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C09 | UT-JEA-01-C09 league 89 -> 3 | Ejecutado aprobado | 0.3852 | [línea 337](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C10 | UT-JEA-01-C10 league 119 -> 4 | Ejecutado aprobado | 0.3055 | [línea 342](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C11 | UT-JEA-01-C11 league 149 -> 5 | Ejecutado aprobado | 0.5008 | [línea 347](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-JEA-01-C12 | UT-JEA-01-C12 league 151 -> 6 | Ejecutado aprobado | 0.2855 | [línea 352](<../evidencias/cierre/backend/base-unit-final.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-JEA" functions/test/capitulo10.test.cjs functions/test/adapter.capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/domain/policy/userPolicy.ts`: 87.5% líneas, 100.0% ramas y 100.0% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.
