# Paquete de Marco

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Marco Antonio Bocanegra Carrión. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Merit y entrada Ranked. HU trazadas (vínculo de alcance, no criterio demostrado): HU 3.2, HU 3.3, HU 3.4.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | meritReward | V(G) = 11; 11 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | FirebaseGameRepository.start | 6 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | meritReward | 24 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

AC-05/RNF-019 y HU 3.3/3.4: costo 100, rechazo sin saldo negativo. Para meritReward se caracteriza la tabla 25/60/125/200/300/400/500 más floor(palabras/10), tope 40 y factor Ranked 1.5; los criterios no fijan esos tramos y requieren ratificación humana. Los casos aislados de 399/400/401 palabras caracterizan el bonus del método; no son envíos válidos del flujo actual, limitado a 150/200 palabras.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-MAR-01.md). Alcance: Flujo de la función indicada; llamadas auxiliares atómicas; excepciones implícitas de bibliotecas fuera del CFG. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra

Frontera interna probada: `FirebaseGameRepository.start`. Firma y uso se revisaron en el commit fijado. El parámetro season es sobrescrito por el reloj en start/complete y se excluye del conteo. El saldo leído es precondición, no entrada del callable. Los cinco o más campos no representan cinco controles de pantalla.

| Campo | Tipo/dominio | Clases válidas | Inválida o fuera de contrato | Límites | Efecto observable |
|---|---|---|---|---|---|
| id | string lógico | nuevo / repetido | propietario incompatible: rechazo | No frontera numérica; la identidad pública se valida en submissionIdentity | submissions/{id} y retorno Game.id |
| userId | usuario existente y abierto | existente | inexistente/cerrado | No aplica | autor y cuenta debitada |
| mode | PRACTICE / RANKED | dos enums | otros valores fuera del contrato TypeScript de este repositorio | No aplica | entryCost 0/100 y mode |
| writingMode | STANDARD / ON_TOPIC | dos enums | otros valores fuera del contrato tipado | No aplica | writingMode persistido |
| challenge | Challenge recibido | STANDARD: cuatro palabras; ON_TOPIC: dos y topic | validación de contenido se hace antes; no se exige nueva validación al repositorio | colección cuenta como un campo | challenge persistido |
| now | timestamp recibido | anchor / anchor+1 / anchor+2 | tipos no numéricos fuera del contrato | sin límite de aceptación definido | Game.timestamp |

Las particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/functions/integration/capitulo10.firestore.test.cjs`.

Los casos STANDARD usan cuatro palabras; los dos casos ON_TOPIC usan dos palabras y su tópico asociado. El repositorio persiste el reto recibido: esta prueba no añade validación de generación al método start.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| UT-MAR-01-C01 | UT-MAR-01-C01 meritReward(0, 50, false) -> 30 / CB-MAR-01-P1 | Ejecutado aprobado | 14.8881 | [línea 72](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C02 | UT-MAR-01-C02 meritReward(40, 50, false) -> 65 / CB-MAR-01-P2 | Ejecutado aprobado | 0.7847 | [línea 77](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C03 | UT-MAR-01-C03 meritReward(60, 50, false) -> 130 / CB-MAR-01-P3 | Ejecutado aprobado | 1.0651 | [línea 82](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C04 | UT-MAR-01-C04 meritReward(70, 50, false) -> 205 / CB-MAR-01-P4 | Ejecutado aprobado | 0.6277 | [línea 87](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C05 | UT-MAR-01-C05 meritReward(80, 50, false) -> 305 / CB-MAR-01-P5 | Ejecutado aprobado | 0.7263 | [línea 92](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C06 | UT-MAR-01-C06 meritReward(90, 50, false) -> 405 / CB-MAR-01-P6 | Ejecutado aprobado | 18.3921 | [línea 97](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C07 | UT-MAR-01-C07 meritReward(95, 50, false) -> 505 / CB-MAR-01-P7 | Ejecutado aprobado | 0.3726 | [línea 102](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C08 | UT-MAR-01-C08 meritReward(0, 50, true) -> 45 / CB-MAR-01-P8 | Ejecutado aprobado | 0.4087 | [línea 107](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C09 | UT-MAR-01-C09 meritReward(NaN, 50, false) -> invalid-argument / CB-MAR-01-P9 | Ejecutado aprobado | 19.5507 | [línea 112](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C10 | UT-MAR-01-C10 meritReward(-1, 50, false) -> invalid-argument / CB-MAR-01-P10 | Ejecutado aprobado | 0.3876 | [línea 117](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C11 | UT-MAR-01-C11 meritReward(101, 50, false) -> invalid-argument / CB-MAR-01-P11 | Ejecutado aprobado | 0.3307 | [línea 122](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C12 | UT-MAR-01-C12 meritReward(39, 50, false) -> 30 | Ejecutado aprobado | 0.2609 | [línea 127](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C13 | UT-MAR-01-C13 meritReward(59, 50, false) -> 65 | Ejecutado aprobado | 0.3015 | [línea 132](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C14 | UT-MAR-01-C14 meritReward(69, 50, false) -> 130 | Ejecutado aprobado | 0.2319 | [línea 137](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C15 | UT-MAR-01-C15 meritReward(79, 50, false) -> 205 | Ejecutado aprobado | 0.2989 | [línea 142](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C16 | UT-MAR-01-C16 meritReward(89, 50, false) -> 305 | Ejecutado aprobado | 0.2503 | [línea 147](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C17 | UT-MAR-01-C17 meritReward(94, 50, false) -> 405 | Ejecutado aprobado | 0.241 | [línea 152](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C18 | UT-MAR-01-C18 meritReward(100, 50, true) -> 757 | Ejecutado aprobado | 0.2944 | [línea 157](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C19 | UT-MAR-01-C19 meritReward(60, 9, false) -> 125 | Ejecutado aprobado | 0.2725 | [línea 162](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C20 | UT-MAR-01-C20 meritReward(60, 10, false) -> 126 | Ejecutado aprobado | 0.2322 | [línea 167](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C21 | UT-MAR-01-C21 meritReward(60, 399, false) -> 164 | Ejecutado aprobado | 0.2674 | [línea 172](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C22 | UT-MAR-01-C22 meritReward(60, 400, false) -> 165 | Ejecutado aprobado | 0.2435 | [línea 177](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C23 | UT-MAR-01-C23 meritReward(60, 401, false) -> 165 | Ejecutado aprobado | 0.2417 | [línea 182](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C24 | UT-MAR-01-C24 meritReward(Infinity, 50, false) -> invalid-argument | Ejecutado aprobado | 0.6128 | [línea 187](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-MAR-01-C01 | CN-MAR-01-C01 start seis campos efectivos y season sobrescrita no contada | Ejecutado aprobado | 3979.8073 | [línea 11](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-MAR-01-C02 | CN-MAR-01-C02 start seis campos efectivos y season sobrescrita no contada | Ejecutado aprobado | 147.7743 | [línea 16](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-MAR-01-C03 | CN-MAR-01-C03 start seis campos efectivos y season sobrescrita no contada | Ejecutado aprobado | 122.8874 | [línea 21](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-MAR-01-C04 | CN-MAR-01-C04 perfil inexistente rechaza inicio sin crear partida | Ejecutado aprobado | 66.5243 | [línea 26](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-MAR" functions/test/capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.
- CB/CN de esta ficha en Firestore, tras compilar: `firebase emulators:exec --project demo-inkr8 --only firestore "node --test --test-name-pattern=-MAR- functions/integration/capitulo10.firestore.test.cjs"`.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/domain/policy/gamePolicy.ts`: 84.0% líneas, 100.0% ramas y 100.0% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.
