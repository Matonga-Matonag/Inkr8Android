# Paquete de Pedro

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Pedro Iván Pacheco Castro. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Validación, evaluación y feedback. HU trazadas (vínculo de alcance, no criterio demostrado): HU 2.2, HU 2.3, HU 2.4, HU 3.12.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | validateWriting | V(G) = 6; 6 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | structureEvaluation | 10 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | EvaluateGame.execute | 10 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

Informe 5.3 HU 2.3/2.4/3.12: score 0–100, timeout diferido, preservación de score base y detalle de restricciones. HU 2.2/contrato WritingMode: 50–150 STANDARD y 50–200 ON_TOPIC; 10 000 caracteres como guarda del código, caracterización técnica.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-PED-01.md). Alcance: Función TypeScript validateWriting. Se incluye el ternario del mensaje de error: es código distinto del ternario del máximo. wordCount se considera llamada atómica. HU 2.2 adicional justificada por validación y envío; no se atribuye esta complejidad a Kotlin. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra

Frontera interna probada: `structureEvaluation`. Firma y uso se revisaron en el commit fijado. Los cinco o más campos no representan cinco controles de pantalla.

| Campo | Tipo/dominio | Clases válidas | Inválida o fuera de contrato | Límites | Efecto observable |
|---|---|---|---|---|---|
| game.content | string | 49/50/151 palabras; presencia/ausencia de términos | incumplimiento es resultado false, no excepción de entrada | 49/50; 150/151; semántica de texto | constraints.fulfilled |
| game.writingMode | enum | STANDARD / ON_TOPIC | otros fuera del contrato | No aplica | máximo 150/200 y etiqueta |
| game.challenge.words | Word[] | requerida presente / ausente | no se exige esquema nuevo a este método tipado | cardinalidad; no contar cada elemento como campo | reglas Use … |
| game.challenge.topic | string/null | topic / null | no relevancia o booleano faltante | No aplica | regla Topic o constraintsError |
| game.challenge.advanced | string[] | FIRST_PERSON / QUESTION / [] | UNKNOWN produce error de verificación | No frontera numérica de enums | primera persona y pregunta |
| result.spelling/vocabulary/coherence/creativity | cuatro strings separados | detalle no vacío | ausente/blanco | vacío vs no vacío; no límite máximo acordado | feedbackError |
| result.topicRelevant | boolean opcional | true / false | ausente no verificable | No aplica | resultado de topic / error |

Las particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/functions/test/capitulo10.test.cjs`.

Los fixtures de estructuración incluyen los campos obligatorios de Game y Word. Las variaciones de cardinalidad aíslan structureEvaluation; no se presentan como retos completos generados para una partida de usuario.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| CB-PED-01-C01 | CB-PED-01-C01 validateWriting STANDARD, caracteres=199, palabras=50 | Ejecutado aprobado | 0.5377 | [línea 192](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C02 | CB-PED-01-C02 validateWriting ON_TOPIC, caracteres=199, palabras=50 | Ejecutado aprobado | 0.4315 | [línea 197](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C03 | CB-PED-01-C03 validateWriting STANDARD, caracteres=10001, palabras=1 | Ejecutado aprobado | 0.4283 | [línea 202](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C04 | CB-PED-01-C04 validateWriting ON_TOPIC, caracteres=10001, palabras=1 | Ejecutado aprobado | 0.3141 | [línea 207](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C05 | CB-PED-01-C05 validateWriting STANDARD, caracteres=195, palabras=49 | Ejecutado aprobado | 0.3224 | [línea 212](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C06 | CB-PED-01-C06 validateWriting STANDARD, caracteres=603, palabras=151 | Ejecutado aprobado | 0.3878 | [línea 217](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C07 | CB-PED-01-C07 validateWriting STANDARD, caracteres=599, palabras=150 | Ejecutado aprobado | 0.2783 | [línea 222](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C08 | CB-PED-01-C08 validateWriting ON_TOPIC, caracteres=799, palabras=200 | Ejecutado aprobado | 0.3877 | [línea 227](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C09 | CB-PED-01-C09 validateWriting ON_TOPIC, caracteres=803, palabras=201 | Ejecutado aprobado | 0.4001 | [línea 232](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C10 | CB-PED-01-C10 validateWriting STANDARD, caracteres=0, palabras=0 | Ejecutado aprobado | 0.4917 | [línea 237](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C11 | CB-PED-01-C11 validateWriting STANDARD, caracteres=10000, palabras=50 | Ejecutado aprobado | 0.5337 | [línea 242](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C12 | CB-PED-01-C12 validateWriting STANDARD, caracteres=10001, palabras=50 | Ejecutado aprobado | 0.5007 | [línea 247](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C01 | UT-PED-01-C01 EvaluateGame éxito práctica completa sin match | Ejecutado aprobado | 2.0371 | [línea 407](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C02 | UT-PED-01-C02 EvaluateGame éxito Ranked completa antes de match | Ejecutado aprobado | 2.1603 | [línea 412](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C03 | UT-PED-01-C03 EvaluateGame ya evaluado no recompensa | Ejecutado aprobado | 11.1623 | [línea 417](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C04 | UT-PED-01-C04 EvaluateGame timeout controlado difiere sin completar | Ejecutado aprobado | 1.5391 | [línea 422](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C05 | UT-PED-01-C05 EvaluateGame rechaza score=NaN | Ejecutado aprobado | 1.2489 | [línea 427](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C06 | UT-PED-01-C06 EvaluateGame rechaza score=-1 | Ejecutado aprobado | 0.7488 | [línea 432](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C07 | UT-PED-01-C07 EvaluateGame rechaza score=101 | Ejecutado aprobado | 1.8369 | [línea 437](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C08 | UT-PED-01-C08 EvaluateGame cuota 429 falla sin reintento automático (caracterización AC-02) | Ejecutado aprobado | 3.3734 | [línea 442](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C09 | UT-PED-01-C09 EvaluateGame fallo de persistencia invoca fail dos veces (diagnóstico) | Ejecutado aprobado | 1.0476 | [línea 447](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C10 | UT-PED-01-C10 EvaluateGame servicio 503 falla sin diferir (caracterización AC-02) | Ejecutado aprobado | 0.787 | [línea 452](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C01 | CN-PED-01-C01 estructura feedback y restricciones desde campos recibidos | Ejecutado aprobado | 13.3363 | [línea 482](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C02 | CN-PED-01-C02 feedback incompleto preserva score y comunica error | Ejecutado aprobado | 2.3279 | [línea 487](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C03 | CN-PED-01-C03 texto y palabras ausentes fallan restricciones específicas | Ejecutado aprobado | 0.6846 | [línea 492](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C04 | CN-PED-01-C04 writingMode discrimina 151 palabras y conserva detalles | Ejecutado aprobado | 2.4056 | [línea 497](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C05 | CN-PED-01-C05 regla avanzada desconocida informa incumplimiento verificable | Ejecutado aprobado | 0.5285 | [línea 502](<../evidencias/cierre/backend/base-unit-final.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-PED" functions/test/capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/domain/usecase/gameUseCases.ts`: 81.13% líneas, 86.96% ramas y 50.0% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.
