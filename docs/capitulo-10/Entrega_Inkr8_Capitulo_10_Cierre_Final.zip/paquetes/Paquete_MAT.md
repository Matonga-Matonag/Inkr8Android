# Paquete de Matías

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Matías Gonzalo Villar Córdova Alva. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Perfil y apoyo a sesión/progreso. HU trazadas (vínculo de alcance, no criterio demostrado): HU 1.1, HU 1.2, HU 1.3, HU 1.4, HU 1.10, HU 3.6.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | mapUser | V(G) = 7; 7 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | mapUser | 7 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | mapUser | 7 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

Contrato UserDto/User: campos opcionales reciben defaults documentados en ficha. Preservar ID, cero, nombre, email y username es caracterización del mapper; HU 1.1 de Google se reconcilia por S2 y ACCEPTANCE_REPORT, no por ASR E2:E3.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-MAT-01.md). Alcance: Flujo de la función indicada; llamadas auxiliares atómicas; excepciones implícitas de bibliotecas fuera del CFG. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra

Frontera interna probada: `mapUser`. Firma y uso se revisaron en el commit fijado. Los cinco o más campos no representan cinco controles de pantalla.

| Campo | Tipo/dominio | Clases válidas | Inválida o fuera de contrato | Límites | Efecto observable |
|---|---|---|---|---|---|
| id | string | u / other | sin validador prometido | No aplica | User.id |
| dto.name | string opcional | Marco | ausente/vacío usa Writer | vacío/no vacío | User.name |
| dto.email | string opcional | m@example.test / vacío | ausente/null usa null | No validación de email prometida | User.email |
| dto.merit | number opcional | 1000 / 0 | ausente/null usa 0 | no validación económica prometida en mapper | User.merit |
| dto.rating | number opcional | 60 / 0 | ausente/null usa 0 | no umbral propio del mapper | User.rating |
| dto.seasonIndex | number opcional | 0 | ausente usa MIN_SAFE_INTEGER | sentinela, no rango de negocio | User.seasonIndex |
| dto.username | string opcional | marco / vacío | ausente/null usa null | no longitud validada aquí | User.username |

Las particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/functions/test/capitulo10.test.cjs`.

La CN caracteriza las siete entradas efectivas del mapper. No prueba autenticación, sesión, validación de email ni reglas de saldo.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| UT-MAT-01-C01 | UT-MAT-01-C01 / CB-MAT-01-P1 mapUser conserva todos los campos | Ejecutado aprobado | 1.6985 | [línea 357](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C02 | UT-MAT-01-C02 / CB-MAT-01-P2 mapUser default de name | Ejecutado aprobado | 0.4882 | [línea 362](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C03 | UT-MAT-01-C03 / CB-MAT-01-P3 mapUser default de email | Ejecutado aprobado | 0.3396 | [línea 367](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C04 | UT-MAT-01-C04 / CB-MAT-01-P4 mapUser default de merit | Ejecutado aprobado | 0.2614 | [línea 372](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C05 | UT-MAT-01-C05 / CB-MAT-01-P5 mapUser default de rating | Ejecutado aprobado | 0.227 | [línea 377](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C06 | UT-MAT-01-C06 / CB-MAT-01-P6 mapUser default de seasonIndex | Ejecutado aprobado | 0.2462 | [línea 382](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C07 | UT-MAT-01-C07 / CB-MAT-01-P7 mapUser default de username | Ejecutado aprobado | 0.2184 | [línea 387](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-MAT-01-C01 | CN-MAT-01-C01 mapUser frontera de siete campos, identidad externa | Ejecutado aprobado | 0.3258 | [línea 392](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-MAT-01-C02 | CN-MAT-01-C02 mapUser conserva cero y cadena vacía según contrato | Ejecutado aprobado | 0.311 | [línea 397](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-MAT-01-C03 | CN-MAT-01-C03 mapUser nullish sin validar tipos fuera de UserDto | Ejecutado aprobado | 0.3284 | [línea 402](<../evidencias/cierre/backend/base-unit-final.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-MAT" functions/test/capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/data/dto/userDto.ts`: 66.67% líneas, 100.0% ramas y 100.0% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.
