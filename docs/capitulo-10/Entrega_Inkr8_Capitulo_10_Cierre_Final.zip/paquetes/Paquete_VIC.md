# Paquete de Víctor

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Víctor Manuel Camarena Paredes. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Cierre, matchmaking y variación de rating. HU trazadas (vínculo de alcance, no criterio demostrado): HU 3.2, HU 3.5, HU 3.7, HU 3.9.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | ratingChange | V(G) = 5; 5 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | FirebaseGameRepository.complete | 7 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | ratingChange | 9 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

HU 3.2/AC-04: acreditación única; AC-03: delta ≤30 y sin dobles. ratingChange se caracteriza como regla propia; AC-06 sigue discrepante y no es su oráculo de aprobación.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-VIC-01.md). Alcance: Caracterización de la regla actual de rating; no conformidad con ELO oficial AC-06. Math.min/max no añaden decisiones propias. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra

Frontera interna probada: `FirebaseGameRepository.complete`. Firma y uso se revisaron en el commit fijado. El parámetro season es sobrescrito por el reloj en start/complete y se excluye del conteo. El saldo leído es precondición, no entrada del callable. Los cinco o más campos no representan cinco controles de pantalla.

| Campo | Tipo/dominio | Clases válidas | Inválida o fuera de contrato | Límites | Efecto observable |
|---|---|---|---|---|---|
| game.id | string | g / other | no se añade validador de ID aquí | No aplica | documento final |
| game.authorId | string | alice / bob | perfil ausente/cerrado tratado en implementación | No aplica | usuario acreditado |
| game.content | string | 50 / 60 palabras | invalidación de envío pertenece a submit | count/10 y tope son caracterización | meritEarned |
| game.mode | enum | RANKED / PRACTICE | otros fuera del contrato | No aplica | multiplicador y matchStatus |
| game.seasonIndex | number | actual 0 / anterior −1 | temporada anterior es válida, expirada para rating | igual / distinto de actual | PENDING / EXPIRED |
| evaluation.score | number | 60 / 95, más límites unitarios | NaN/<0/>100 rechazados por regla | 0/100 y tramos caracterizados | recompensa |
| evaluation.feedback | string | Feedback específico / Otro feedback | no prometer validador de string adicional | No umbral definido | feedback preservado |

Las particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/functions/integration/capitulo10.firestore.test.cjs`.

El caso EXPIRED crea y envía la partida con el reloj en SEASON_ANCHOR_MS - 1, avanza a SEASON_ANCHOR_MS y entonces completa. La temporada anterior se obtiene del flujo real; no se modifica manualmente seasonIndex.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| UT-VIC-01-C01 | UT-VIC-01-C01 ratingChange 100/100/DRAW -> 1 / CB-VIC-01-P1 | Ejecutado aprobado | 0.6842 | [línea 252](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C02 | UT-VIC-01-C02 ratingChange 100/100/LOSS -> -6 / CB-VIC-01-P2 | Ejecutado aprobado | 0.2613 | [línea 257](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C03 | UT-VIC-01-C03 ratingChange 100/100/WIN -> 4 / CB-VIC-01-P3 | Ejecutado aprobado | 0.2479 | [línea 262](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C04 | UT-VIC-01-C04 ratingChange 150/150/WIN -> 3 / CB-VIC-01-P4 | Ejecutado aprobado | 0.4845 | [línea 267](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C05 | UT-VIC-01-C05 ratingChange 180/180/WIN -> 2 / CB-VIC-01-P5 | Ejecutado aprobado | 0.4275 | [línea 272](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C06 | UT-VIC-01-C06 ratingChange 100/200/WIN -> 9 | Ejecutado aprobado | 0.2722 | [línea 277](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C07 | UT-VIC-01-C07 ratingChange 200/100/LOSS -> -11 | Ejecutado aprobado | 0.3594 | [línea 282](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C08 | UT-VIC-01-C08 ratingChange 100/200/LOSS -> -1 | Ejecutado aprobado | 0.2953 | [línea 287](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C09 | UT-VIC-01-C09 ratingChange 0/0/LOSS -> -6 | Ejecutado aprobado | 0.2454 | [línea 292](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-VIC-01-C01 | CN-VIC-01-C01 complete campos del Game y Evaluation influyen en liquidación | Ejecutado aprobado | 195.253 | [línea 52](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-VIC-01-C02 | CN-VIC-01-C02 complete campos del Game y Evaluation influyen en liquidación | Ejecutado aprobado | 203.6837 | [línea 57](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-VIC-01-C03 | CN-VIC-01-C03 complete campos del Game y Evaluation influyen en liquidación | Ejecutado aprobado | 206.385 | [línea 62](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-VIC-01-C04 | CN-VIC-01-C04 id y authorId dirigen la escritura a otra partida y cuenta | Ejecutado aprobado | 231.1441 | [línea 67](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-VIC" functions/test/capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.
- CB/CN de esta ficha en Firestore, tras compilar: `firebase emulators:exec --project demo-inkr8 --only firestore "node --test --test-name-pattern=-VIC- functions/integration/capitulo10.firestore.test.cjs"`.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/domain/policy/gamePolicy.ts`: 84.0% líneas, 100.0% ramas y 100.0% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.
