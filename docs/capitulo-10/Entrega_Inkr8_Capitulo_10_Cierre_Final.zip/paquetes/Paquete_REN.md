# Paquete de Renzo

**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: Renzo Ubaldo Adrianzén Vía. La revisión y reproducción individual requieren evidencia propia (EXT-02).

Funcionalidad: Home, metadata y oración de ejemplo. HU trazadas (vínculo de alcance, no criterio demostrado): HU 1.5, HU 1.6.

Base backend `993c6b0641a4a60603d87e251c90f51783460007`; apoyo Android `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.

## Viabilidad de las tres técnicas

| Técnica | Frontera / método | Condición | Estado técnico | Pendiente |
|---|---|---|---|---|
| CB | dailyWord | V(G) = 7; 7 caminos independientes | Casos testigo aprobados; base independiente | Reproducción/aporte individual (EXT-02) |
| CN | GetDailyHome.execute → FirebaseContentRepository.dailyWord | 5 campos reales recibidos | Casos ejecutados aprobados; contrato interno | Aceptación docente de frontera interna y reparto |
| Unitaria | GetWordExample.execute | 5 casos distinguibles de ese método | Ejecutados aprobados | Reproducción y aporte individual |

## Oráculo y criterio

ASR E 10: E 13: cinco metadatos Home y oración que incluya palabra; el ejemplo sentence es otro dato y no se suma a los cinco de hasMetadata. Vacío/espacios no son metadata completa. Rechazo de contenido y proveedor controlado, no UI.

Rúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.

## Caja blanca

[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/CB-REN-01.md). Alcance: Flujo conectado exterior de dailyWord; el callback transaccional empieza en su propia entrada y se excluye del conteo. Tampoco se suman words.find, words() ni hasMetadata. Sus efectos se ejercitan en Firestore, pero no elevan V(G) de este grafo. La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.

## Caja negra principal: Home observable

Se ejecuta `GetDailyHome.execute → FirebaseContentRepository.dailyWord → Firestore` y se observa Home, caché y errores. Cinco entradas reales del catálogo persistido; **no** son cinco argumentos públicos: getHome recibe cero y dailyWord recibe day. No se llama al helper privado hasMetadata en estos 25 casos. La evidencia anterior del helper sigue como regresión auxiliar, sin sustituir la aceptación docente de esta frontera.

| Campo persistido | Salida | Particiones ejecutadas | Límite aplicable | Efecto |
|---|---|---|---|---|
| word | word.text | Dos valores no vacíos; vacío, espacios y ausente | Vacío después de trim/no vacío; no hay máximo lingüístico prometido | Home/caché exactos o error preciso; fuente intacta |
| definition | word.definition | Dos valores no vacíos; vacío, espacios y ausente | Vacío después de trim/no vacío; no hay máximo lingüístico prometido | Home/caché exactos o error preciso; fuente intacta |
| phonetic | word.phonetic | Dos valores no vacíos; vacío, espacios y ausente | Vacío después de trim/no vacío; no hay máximo lingüístico prometido | Home/caché exactos o error preciso; fuente intacta |
| partOfSpeech | word.partOfSpeech | Dos valores no vacíos; vacío, espacios y ausente | Vacío después de trim/no vacío; no hay máximo lingüístico prometido | Home/caché exactos o error preciso; fuente intacta |
| rarity | word.rarity | Dos valores no vacíos; vacío, espacios y ausente | Vacío después de trim/no vacío; no hay máximo lingüístico prometido | Home/caché exactos o error preciso; fuente intacta |

25/25 casos: 6 de preservación/variación, 15 negativos por campo y 4 de caché/inactividad. Ver [contrato, opciones y pregunta exacta para Wong](../cierre/caja_negra/CN_Renzo_Observable.md). Solo EXT-01 puede confirmar aceptación docente; no se inventan campos ni se cuenta sentence/isActive/day para alcanzar cinco.

## Casos, resultados y reproducción

| Caso | Escenario/fixture | Resultado base | Duración ms | Evidencia final |
|---|---|---|---|---|
| UT-REN-01-C01 | UT-REN-01-C01 GetWordExample {"text":"ink", "sentence":"A bottle of ink."} | Ejecutado aprobado | 4.3713 | [línea 457](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C02 | UT-REN-01-C02 GetWordExample {"text":"árbol", "sentence":"El ÁRBOL crece."} | Ejecutado aprobado | 11.8173 | [línea 462](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C03 | UT-REN-01-C03 GetWordExample {"text":"ink", "sentence":"Think carefully."} | Ejecutado aprobado | 3.1215 | [línea 467](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C04 | UT-REN-01-C04 GetWordExample {"text":"ink", "sentence":"   "} | Ejecutado aprobado | 0.4014 | [línea 472](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C05 | UT-REN-01-C05 GetWordExample propaga fallo de proveedor controlado | Ejecutado aprobado | 0.7874 | [línea 477](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-REN-01-C01 | CB-REN-01-C01 dailyWord camino P1 | Ejecutado aprobado | 43.5362 | [línea 89](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C02 | CB-REN-01-C02 dailyWord camino P2 | Ejecutado aprobado | 23.6693 | [línea 94](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C03 | CB-REN-01-C03 dailyWord camino P3 | Ejecutado aprobado | 37.8235 | [línea 99](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C04 | CB-REN-01-C04 dailyWord camino P4 | Ejecutado aprobado | 91.3239 | [línea 104](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C05 | CB-REN-01-C05 dailyWord camino P5 | Ejecutado aprobado | 76.4632 | [línea 109](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C06 | CB-REN-01-C06 dailyWord camino P6 | Ejecutado aprobado | 47.9526 | [línea 114](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C07 | CB-REN-01-C07 dailyWord camino P7 | Ejecutado aprobado | 36.1177 | [línea 119](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C01 | CIERRE-CN-REN-C01 Home expone cinco metadatos completos y crea cache exacto | Ejecutado aprobado | 997.0492 | [línea 174](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C02 | CIERRE-CN-REN-C02 Home conserva variacion correcta del campo persistido word | Ejecutado aprobado | 84.5553 | [línea 180](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C03 | CIERRE-CN-REN-C03 Home conserva variacion correcta del campo persistido definition | Ejecutado aprobado | 79.9769 | [línea 186](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C04 | CIERRE-CN-REN-C04 Home conserva variacion correcta del campo persistido phonetic | Ejecutado aprobado | 112.3795 | [línea 192](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C05 | CIERRE-CN-REN-C05 Home conserva variacion correcta del campo persistido partOfSpeech | Ejecutado aprobado | 93.6405 | [línea 198](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C06 | CIERRE-CN-REN-C06 Home conserva variacion correcta del campo persistido rarity | Ejecutado aprobado | 78.3156 | [línea 204](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C07 | CIERRE-CN-REN-C07 Home rechaza word empty sin crear cache ni modificar catalogo | Ejecutado aprobado | 77.394 | [línea 210](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C08 | CIERRE-CN-REN-C08 Home rechaza word whitespace sin crear cache ni modificar catalogo | Ejecutado aprobado | 63.3777 | [línea 216](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C09 | CIERRE-CN-REN-C09 Home rechaza word absent sin crear cache ni modificar catalogo | Ejecutado aprobado | 60.1742 | [línea 222](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C10 | CIERRE-CN-REN-C10 Home rechaza definition empty sin crear cache ni modificar catalogo | Ejecutado aprobado | 62.4909 | [línea 228](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C11 | CIERRE-CN-REN-C11 Home rechaza definition whitespace sin crear cache ni modificar catalogo | Ejecutado aprobado | 60.7899 | [línea 234](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C12 | CIERRE-CN-REN-C12 Home rechaza definition absent sin crear cache ni modificar catalogo | Ejecutado aprobado | 46.4942 | [línea 240](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C13 | CIERRE-CN-REN-C13 Home rechaza phonetic empty sin crear cache ni modificar catalogo | Ejecutado aprobado | 33.8274 | [línea 246](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C14 | CIERRE-CN-REN-C14 Home rechaza phonetic whitespace sin crear cache ni modificar catalogo | Ejecutado aprobado | 60.0072 | [línea 252](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C15 | CIERRE-CN-REN-C15 Home rechaza phonetic absent sin crear cache ni modificar catalogo | Ejecutado aprobado | 46.5034 | [línea 258](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C16 | CIERRE-CN-REN-C16 Home rechaza partOfSpeech empty sin crear cache ni modificar catalogo | Ejecutado aprobado | 47.3656 | [línea 264](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C17 | CIERRE-CN-REN-C17 Home rechaza partOfSpeech whitespace sin crear cache ni modificar catalogo | Ejecutado aprobado | 48.3949 | [línea 270](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C18 | CIERRE-CN-REN-C18 Home rechaza partOfSpeech absent sin crear cache ni modificar catalogo | Ejecutado aprobado | 50.135 | [línea 276](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C19 | CIERRE-CN-REN-C19 Home rechaza rarity empty sin crear cache ni modificar catalogo | Ejecutado aprobado | 58.1695 | [línea 282](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C20 | CIERRE-CN-REN-C20 Home rechaza rarity whitespace sin crear cache ni modificar catalogo | Ejecutado aprobado | 46.8069 | [línea 288](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C21 | CIERRE-CN-REN-C21 Home rechaza rarity absent sin crear cache ni modificar catalogo | Ejecutado aprobado | 49.3111 | [línea 294](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C22 | CIERRE-CN-REN-C22 cache valido conserva los cinco metadatos aunque no haya catalogo | Ejecutado aprobado | 60.694 | [línea 300](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C23 | CIERRE-CN-REN-C23 cache incompleto se repara desde palabra activa del mismo texto | Ejecutado aprobado | 98.305 | [línea 306](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C24 | CIERRE-CN-REN-C24 cache incompleto de texto inexistente falla sin cambiar palabra del dia | Ejecutado aprobado | 44.2388 | [línea 312](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CIERRE-CN-REN-C25 | CIERRE-CN-REN-C25 palabra inactiva no se usa ni crea cache | Ejecutado aprobado | 47.197 | [línea 318](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

Los arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.

Desde la raíz backend, con Node 20 y dependencias instaladas mediante `npm --prefix functions ci`:

- Unidad con cobertura: `npm --prefix functions run test:coverage`.
- Ficha unitaria aislada, tras `npm --prefix functions run build`: `node --test --test-name-pattern="(UT|CB|CN)-REN" functions/test/capitulo10.test.cjs`.
- Firestore funcional con cobertura: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"`. Resultado final de la suite: 100 aprobados, cero fallos.
- CB auxiliar de esta ficha en Firestore, tras compilar: `firebase emulators:exec --project demo-inkr8 --only firestore "node --test --test-name-pattern=-REN- functions/integration/capitulo10.firestore.test.cjs"`.

La carga de 50 solicitudes se reproduce aparte mediante `test:concurrency`; conserva un fallo en la base y se informa en la investigación Firestore. No forma parte de los 100 casos funcionales.

Cobertura medida del archivo unitario `src/domain/usecase/contentUseCases.ts`: 75.0% líneas, 88.24% ramas y 81.82% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.

## Validación individual por completar

Revisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar EXT-01 sobre la frontera Home observable y el reparto; hasMetadata queda solo como antecedente auxiliar. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.

## Estado de cierre A/B/C

A: diseño CB/UT, casos distinguidos y cobertura por archivo contrastados; base backend 116/116 y funcional 100/100. B: defectos de producto documentados en capítulo 10.5, sin ocultarlos mediante caracterización. C: aceptación de frontera CN y participación individual, inventario único [EXT-01/02](../Pendientes_Externos.md). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

CN principal sin filtros ni omitidos: `firebase emulators:exec --project demo-inkr8 --only firestore "node --test functions/integration/cierre.cn-renzo.test.cjs"`. Preparar Node 20/JDK 21/JAR como indica README_Ejecucion.
