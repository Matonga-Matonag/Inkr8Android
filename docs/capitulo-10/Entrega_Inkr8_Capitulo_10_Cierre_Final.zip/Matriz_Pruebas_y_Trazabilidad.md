# Matriz de pruebas y trazabilidad final

Se conservan 19 HU prioritarias y HU 2.2. Hay 396 relaciones muchos a muchos y 323 casos únicos de base; el número de relaciones no es un número de pruebas ni aceptación de HU. Los negativos 3.6/3.8 ya no dependen de constantes: fallan en operación/UI y pasan únicamente en propuesta separada. El negativo 3.9 tiene evidencia local de mapper, ViewModel, mensaje y recuperación.

| HU | Comprobación local / carencia | Pendiente integral |
|---|---|---|
| HU 1.1 | Fallo inducido en signIn produce GOOGLE_SIGNIN_FAILED y signedIn=false. | OAuth Google real, navegación y perfil sin duplicación tras recrear proceso; conciliación pendiente de requisitos. |
| HU 1.2 | Dos claims concurrentes: solo uno prospera; el otro recibe Username … is already in use. | Mostrar resultado/mensaje en pantalla y validación humana del criterio. |
| HU 1.3 | UID null deja signedIn=false y usuario ausente. | Restauración tras muerte de proceso, almacenamiento real de auth y navegación Login/Home. |
| HU 1.4 | Error de logout conserva sesión e informa LOGOUT_FAILED; reintento probado. | Cierre efectivo Firebase Auth y pantalla Login. |
| HU 1.5 | Contenido incompleto/ausente rechazado; ViewModel expone mensaje de fallo controlado. | Pantalla Home, audio, botones y recuperación real de red. |
| HU 1.6 | Proveedor controlado falla y ViewModel muestra error; reintento funciona. | Click y texto renderizados en dispositivo con proveedor real. |
| HU 1.10 | Inicialización controlada fallida produce PROGRESS_RETRIEVE_FAILED. | Logout/login real y recuperación de historial desde cliente recreado. |
| HU 2.1 | Fallo start controlado produce INTERNET_ACTION_FAILED. | Cuatro restricciones visibles y botón de reintento sin conexión real. |
| HU 2.3 | Timeout de excepción controlada persiste FAILED+nextRetryAt; recuperación a 5 min; cuota 429/503 no difiere. | OpenAI real y ≥90% de evaluaciones completas ≤5 s; timeout real por reloj del SDK y UI; corrección AC-02 cuota/disponibilidad. |
| HU 2.4 | Feedback incompleto conserva score base y devuelve aviso requerido. | Pantalla de resultados y navegación real. |
| HU 3.2 | Fallo de complete controlado no acredita premio; registra dos llamadas fail como diagnóstico. | Monto y mensaje Unable to connect to the server en UI; confirmar tabla de economía como regla de negocio. |
| HU 3.3 | 99 rechaza sin partida ni saldo negativo; integración concilia mensaje de capa backend. | Mensaje de HU 3.3 difiere del de HU 3.4; revisar contrato de UX sin sustituir los criterios. |
| HU 3.4 | Insufficient Merit detiene inicio y se traduce al aviso Ranked en ViewModel. | Acceso/pantalla real y saldo visible. |
| HU 3.5 | Recuperación 48 h y promedio histórico verificados; base 50 falla; propuesta 3×50 y 51 pasa. Ventana 100 heredada comprobada en ambas. | Decisión de incorporar desempate y validación externa; histórico TRANS-01 de causa exacta abierta. |
| HU 3.6 | Fallo inducido en operación real yUI local; base muestra literal incorrecto. Corrección separada verificada. | Incorporación del parche cliente y validación externa; ver EXT-07/09. |
| HU 3.7 | Fallo de matching persiste matchError y recuperación exitosa lo limpia. | Decidir ELO oficial frente a regla propia y verificar mensaje en UI; escala AC-03 parcial. |
| HU 3.8 | Fallo inducido en operación real yUI local; base muestra literal incorrecto. Corrección separada verificada. | Incorporación del parche cliente y validación externa; ver EXT-07/09. |
| HU 3.9 | Mapper conserva delta inválido como null; ViewModel/UI muestran Server failure y reconexión restaura−6 sin nuevo envío. | Regla ELO y servicio/pantalla con datos reales; EXT-03/07. |
| HU 3.12 | topicRelevant ausente o regla desconocida devuelve Compliance with restrictions could not be verified. | Semántica de relevancia con OpenAI real y mensaje renderizado en cliente. |
| HU 2.2 | 49/151/201 y 10 001 caracteres rechazan, con 50 palabras controladas en el caso de caracteres. | Botón Submit y aviso en pantalla; incorporación adicional justificada por CB de Pedro. |

[CSV](Matriz_Pruebas_y_Trazabilidad.csv), [JSON](Matriz_Pruebas_y_Trazabilidad.json), [casos únicos](Casos_ejecutados.json), [38+2 criterios](revision/Criterios_Demostrados.md). La propuesta se informa en sus reportes separados; no reemplaza resultados de base.
