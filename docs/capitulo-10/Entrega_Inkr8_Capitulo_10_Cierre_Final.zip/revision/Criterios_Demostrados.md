# Evidencia por criterio de aceptación

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

38 criterios de 19 HU prioritarias y 2 de HU 2.2 adicional. HU trazada no equivale a criterio integral demostrado. Los tres negativos solicitados ya ejecutan operación/mapper/ViewModel/UI: 3.6 y 3.8 reproducen defectos de base; 3.9 demuestra su cláusula local de fallo. No se certifica E2E de Google/OpenAI ni ELO.

## HU 1.1-S — Registro con Google

Fuente: Informe S2 + ACCEPTANCE_REPORT.md; ASR Historias de Usuario!E2:E3 rechazado por copia

PROPUESTA pendiente: al autenticar correctamente con Google, inicializar/recuperar el perfil y acceder a Home sin reinicializar perfil existente; referencia S2 y ACCEPTANCE_REPORT.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- El callable invocado en proceso inicializa perfil nuevo con 1000 Merit en emulador.
- SessionViewModel carga el perfil tras UID de autenticación simulada.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-11 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_1_scenario1_google_signin_success | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.1-F — Registro con Google

Fuente: Informe S2 + ACCEPTANCE_REPORT.md; ASR Historias de Usuario!E2:E3 rechazado por copia

PROPUESTA pendiente: al fallar autenticación Google, impedir acceso y mostrar Google sign-in failed. Please try again.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- AuthRepository controlado lanza un fallo y SessionViewModel queda signedIn=false con GOOGLE_SIGNIN_FAILED.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_1_scenario2_google_signin_failure | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.2-S — Selección de username único

Fuente: ASR Historias de Usuario!E 4: E 5; fuente complementaria

Dado que soy un usuario e ingreso un username que no existe en la base de datos,
cuando confirmo mi elección,
entonces el sistema debe guardar el username y asociarlo permanentemente a mi cuenta.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Username se persiste de forma permanente y se conserva al reinicializar el usuario.
- ViewModel de perfil confirma guardado cuando el repositorio controlado acepta el nombre.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-13 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_2_scenario1_unique_username_saved_permanently | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.2-F — Selección de username único

Fuente: ASR Historias de Usuario!E 4: E 5; fuente complementaria

Dado que soy un usuario e ingreso un username ya registrado,
cuando intento guardarlo,
entonces el sistema debe impedir el registro y mostrar el mensaje “Username <USERNAME> is already in use”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Dos claims concurrentes por nombres que difieren en mayúsculas/minúsculas producen un ganador y un rechazo; el claim ganador no es sobreescrito.
- ViewModel traduce el rechazo controlado a Username … is already in use.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-13 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_2_scenario2_username_already_in_use_rejected | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.3-S — Inicio de sesión persistente

Fuente: ASR Historias de Usuario!E 6: E 7; fuente complementaria

Dado que soy un usuario que inició sesión previamente,
cuando vuelvo a abrir la aplicación,
entonces el sistema debe restaurar automáticamente su sesión y dirigirlo a la pantalla principal.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- SessionViewModel trata el UID inicial de ObserveSession como sesión activa y carga el perfil.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_3_scenario1_persistent_session_restores | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |
| ANDROID-ContentViewModelTest.persistedSessionRestoresAndLogoutFailureCanBeRetried | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ContentViewModelTest.xml>) |

## HU 1.3-F — Inicio de sesión persistente

Fuente: ASR Historias de Usuario!E 6: E 7; fuente complementaria

Dado que soy un usuario que cerró sesión previamente,
cuando abro la aplicación,
entonces el sistema debe mostrar la pantalla de inicio de sesión.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- UID inicial null deja signedIn=false y usuario ausente en SessionViewModel.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_3_scenario2_logged_out_shows_login_screen | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.4-S — Cierre de sesión

Fuente: ASR Historias de Usuario!E 8: E 9; fuente complementaria

Dado que soy un usuario y estoy autenticado,
cuando selecciono la opción “Log out”,
entonces el sistema debe finalizar la sesión y redirigirme a la pantalla de inicio de sesión.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- signOut controlado emite UID null y el ViewModel limpia sesión/usuario.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_4_scenario1_manual_logout_redirects_to_login | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |
| ANDROID-ContentViewModelTest.persistedSessionRestoresAndLogoutFailureCanBeRetried | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ContentViewModelTest.xml>) |

## HU 1.4-F — Cierre de sesión

Fuente: ASR Historias de Usuario!E 8: E 9; fuente complementaria

Dado que soy un usuario y estoy autenticado
cuando ocurre un problema al cerrar sesión e intento salir de la aplicación,
entonces el sistema debe mostrar el mensaje “Error when logging out. Please try again”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Fallo inducido de signOut produce LOGOUT_FAILED; la prueba de ContentViewModel conserva usuario y permite reintentar.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_4_scenario2_logout_failure_shows_error_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |
| ANDROID-ContentViewModelTest.persistedSessionRestoresAndLogoutFailureCanBeRetried | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ContentViewModelTest.xml>) |

## HU 1.5-S — Visualización de pantalla Home

Fuente: ASR Historias de Usuario!E 10: E 11; fuente complementaria

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando la sección "Word of the Moment" se carga en la interfaz,
entonces el sistema debe mostrar la palabra destacada con su pronunciación fonética, su tipo de palabra, su rareza, su definición, un botón para reproducir el audio y un botón para usar la palabra en un ejemplo de oración.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- dailyWord devuelve metadatos completos y mantiene la palabra del día después de eliminar un elemento de la fuente.
- toWord preserva texto, definición, oración, fonética, tipo y rareza.
- HomeViewModel recibe palabra/fonética/rareza de proveedor controlado.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-10 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C04 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| AND_REN_C01 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| AND_REN_C04 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_5_scenario1_word_of_moment_loaded_with_metadata | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.5-F — Visualización de pantalla Home

Fuente: ASR Historias de Usuario!E 10: E 11; fuente complementaria

Dado que soy un usuario autenticado pero pierdo la conexión a internet al ingresar al "Home",
cuando el sistema intenta recuperar los datos de la palabra del momento desde el servidor,
entonces el sistema debe mostrar el mensaje "The Word of the Moment could not be loaded. Please check your connection" junto con un botón para reintentar.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- dailyWord rechaza fuente vacía o metadatos incompletos.
- Fallo de getHome controlado produce WORD_OF_MOMENT_FAILED en estado del ViewModel.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CB-REN-01-C02 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CB-REN-01-C07 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_5_scenario2_word_of_moment_failure_shows_retry_and_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.6-S — Aparición de oración de ejemplo (“Word of the moment”)

Fuente: ASR Historias de Usuario!E 12: E 13; fuente complementaria

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando hago clic en el botón "Show example sentence",
entonces debe mostrarse una oración de ejemplo que incluya la palabra del momento.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- GetWordExample verifica palabra completa, Unicode y día recibido; no acepta coincidencia de ink dentro de Think.
- HomeViewModel solicita oración bajo demanda usando el día de Home.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-REN-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C02 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-REN-01-C03 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-ContentViewModelTest.exampleIsRequestedOnDemandUsingTheLoadedDayAndCanRetry | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ContentViewModelTest.xml>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_6_scenario1_example_sentence_displays_word | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.6-F — Aparición de oración de ejemplo (“Word of the moment”)

Fuente: ASR Historias de Usuario!E 12: E 13; fuente complementaria

Dado que soy un usuario autenticado y me encuentro en la pantalla de "Home",
cuando hago clic en el botón "Show example sentence" pero el servidor de contenido no responde o falla,
entonces el sistema debe mostrar el mensaje "The example could not be loaded. Please try again".

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- GetWordExample propaga fallo del proveedor controlado.
- HomeViewModel convierte el fallo de ejemplo en mensaje canónico y el reintento controlado tiene éxito.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-REN-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-ContentViewModelTest.exampleIsRequestedOnDemandUsingTheLoadedDayAndCanRetry | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ContentViewModelTest.xml>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_6_scenario2_example_sentence_failure_shows_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.10-S — Persistencia del historial entre sesiones

Fuente: Informe vigente tabla 5.3

Dado que el usuario tiene partidas registradas en su cuenta
cuando cierra la sesión activa y vuelve a ingresar posteriormente
entonces el sistema debe de recuperar el historial junto con las estadísticas previamente guardadas.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Historial y estadísticas competitivas persistidos en Firestore se conservan después de reinicializar el usuario y cambiar temporada.
- SessionViewModel carga campos de perfil de un repositorio controlado.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-15 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_10_scenario1_progress_persists_across_sessions | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 1.10-F — Persistencia del historial entre sesiones

Fuente: Informe vigente tabla 5.3

Dado que soy un usuario registrado y me encuentro en la pantalla de inicio de sesión 
cuando ingreso mis credenciales pero ocurre un fallo en el sistema al intentar recuperar los datos almacenados
entonces el sistema debe mostrar el mensaje “We were unable to retrieve your progress information. Please try again”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Fallo controlado de inicialización de usuario llega a SessionViewModel como PROGRESS_RETRIEVE_FAILED.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu1_10_scenario2_progress_retrieval_failure_shows_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 2.1-S — Visualización de pantalla de escritura y restricciones

Fuente: Informe vigente tabla 5.3

Dado que me encuentro en la pantalla de escritura y tengo conexión a internet,
cuando solicito iniciar una nueva práctica,
entonces el sistema me muestra cuatro restricciones activas (por ejemplo, límite de palabras y uso de cuatro palabras de la base de datos).

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Backend conserva challenge STANDARD con cuatro palabras.
- GameViewModel observa las cuatro palabras del juego creado por el fixture corregido.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-MAR-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| BASE-INT-11 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu2_1_scenario1_active_constraints_displayed | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 2.1-F — Visualización de pantalla de escritura y restricciones

Fuente: Informe vigente tabla 5.3

Dado que me encuentro en la pantalla de escritura pero mi dispositivo no tiene conexión,
cuando intento cargar una nueva partida,
entonces el sistema muestra el mensaje “The action cannot be performed. Please check your Internet connection” y un botón para reintentar.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Fallo de start controlado en Ranked/Standard produce INTERNET_ACTION_FAILED.
- Reintento de start en GameViewModel reutiliza el ID lógico de la petición.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ANDROID-AcceptanceCriteriaSuiteTest.hu2_1_scenario2_writing_screen_offline_shows_retry_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |
| ANDROID-GameViewModelTest.networkRetryReusesTheSameRankedRequestId | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.GameViewModelTest.xml>) |

## HU 2.2-S — Redacción y envío de párrafo

Fuente: ASR Historias de Usuario!E 24: E 25; fuente complementaria

Dado que he terminado de escribir mi párrafo cumpliendo con los requisitos mínimos,
cuando presiono el botón "Submit",
entonces el sistema captura mi texto y lo envía al backend.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- validateWriting admite 50 y 150 palabras STANDARD y 200 ON_TOPIC; 10 000 caracteres con 50 palabras es válido.
- GameViewModel habilita canSubmit y llama submit una vez con texto válido.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CB-PED-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C07 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C08 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C11 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu2_2_scenario1_submit_sends_valid_text | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 2.2-F — Redacción y envío de párrafo

Fuente: ASR Historias de Usuario!E 24: E 25; fuente complementaria

Dado que intento enviar mi respuesta pero el campo de texto está vacío o no cumple con el mínimo de caracteres requeridos,
cuando presiono el botón "Submit",
entonces el botón permanece bloqueado y el sistema muestra el mensaje "Your text does not meet the requirements”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- 49/151/201 palabras y 10 001 caracteres se rechazan según modo sin confundir conteo de palabras y caracteres.
- canSubmit=false y send no invoca submit ante texto inválido; devuelve TEXT_REQUIREMENTS_NOT_MET en estado.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CB-PED-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C06 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C09 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CB-PED-01-C12 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu2_2_scenario2_submit_blocked_on_invalid_text | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 2.3-S — Evaluación automática del párrafo

Fuente: Informe vigente tabla 5.3

Dado que envié mi texto correctamente,
cuando R8 termina de procesarlo,
entonces se me asigna automáticamente una puntuación de 0 a 100 basada en coherencia, vocabulario, creatividad y cumplimiento de restricciones.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- EvaluateGame acepta score controlado válido, completa y luego llama matching en Ranked.
- Scores NaN, −1 y 101 son rechazados antes de completar.
- El adaptador forma el JSON/timeout/configuración y procesa respuesta del SDK simulado.
- complete persiste evaluación y estado EVALUATED en emulador.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-PED-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C02 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C06 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C07 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-JEA-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-VIC-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 2.3-F — Evaluación automática del párrafo

Fuente: Informe vigente tabla 5.3

Dado que el texto ha sido enviado pero el servicio de evaluación supera el tiempo límite de espera,
cuando se cumple el timeout definido,
entonces el sistema muestra el mensaje “The evaluation is taking longer than expected. We'll let you know when your results are ready” y registra el envío para reintento posterior.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Timeout de excepción controlada se traduce a EvaluationTimeout y defer.
- Emulador persiste FAILED con nextRetryAt y mensaje; antes de cinco minutos no recupera y al límite devuelve PENDING sin repetir débito.
- Configuración SDK timeout=90000 y maxRetries=0 se observa en el doble.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| ADAPT-01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-PED-01-C04 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| AC02-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| BASE-INT-14 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 2.4-S — Visualización de retroalimentación detallada

Fuente: Informe vigente tabla 5.3

Dado que la evaluación de mi texto ha concluido,
cuando el sistema procesa y estructura correctamente los resultados recibidos,
entonces soy redirigido a una pantalla que muestra mi puntaje final, qué restricciones cumplí y comentarios específicos sobre ortografía, vocabulario y coherencia.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- structureEvaluation conserva score/feedback y produce restricciones a partir de los campos recibidos.
- Los flags de feedback incompleto no aparecen con los campos de detalle válidos del fixture.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-PED-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |

## HU 2.4-F — Visualización de retroalimentación detallada

Fuente: Informe vigente tabla 5.3

Dado que ocurre un error al procesar la estructura del feedback recibido,
cuando soy redirigido a la pantalla de resultados,
entonces el sistema muestra mi puntaje base junto con el mensaje “The detailed feedback could not be loaded at this time”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Feedback incompleto conserva score base y devuelve DETAILED_FEEDBACK_ERROR.
- Mapper Kotlin real conserva score ante estructura de feedback malformada y marca el detalle ausente.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-PED-01-C02 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-FeedbackMappingTest.malformedFeedbackRetainsScoreAndMarksOnlyTheMissingDetails | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.FeedbackMappingTest.xml>) |

## HU 3.2-S — Obtención de Merit por partida

Fuente: Informe vigente tabla 5.3

Dado que he completado una partida válida y ha sido evaluado por R8, 
cuando se procesa el resultado de la partida, 
entonces el sistema acredita automáticamente la cantidad correspondiente de Merit en mi cuenta y muestra el monto obtenido.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- meritReward reproduce tramos/límites de la regla actual como caracterización.
- complete acredita saldo y meritEarned una sola vez tras diez cierres concurrentes y dos repeticiones del mismo ID.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-MAR-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C03 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C07 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C08 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAR-01-C18 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-VIC-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-VIC-01-C04 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| AC04-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.2-F — Obtención de Merit por partida

Fuente: Informe vigente tabla 5.3

Dado que he completado una partida válida pero ocurre un fallo en la conexión al servidor,
cuando el sistema intenta acreditar la recompensa,
entonces el sistema debe mostrar el mensaje “Unable to connect to the server”.

**Estado local:** No demostrado funcionalmente; evidencia auxiliar. **Integral E2E:** no demostrado.


UT-PED-01-C09 comprueba interacciones de error; la suite histórica de cliente solo compara la constante del mensaje.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-PED-01-C09 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_2_scenario2_merit_reward_failure_shows_message | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.3-S — Pago de entrada a partidas Ranked

Fuente: Informe vigente tabla 5.3

Dado que poseo suficiente saldo Merit en mi cuenta,
cuando selecciono a ingresar a un modo de juego ranked,
entonces el sistema descuenta el monto de entrada correspondiente de mi saldo, actualiza el saldo total y permite el acceso a la partida.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- start Ranked con 100 o 101 Merit descuenta exactamente 100 y crea partida DRAFT.
- Diez partidas compiten por los mismos 100: una se crea y el saldo final es cero.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| AC05-C02 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| AC05-C03 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| AC05-C04 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| CN-MAR-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.3-F — Pago de entrada a partidas Ranked

Fuente: Informe vigente tabla 5.3

Dado que no poseo suficiente saldo Merit en mi cuenta,
cuando selecciono a ingresar a un modo de juego con tarifa,
entonces el sistema bloquea el acceso y debe mostrar el mensaje “You don't have enough Merit to enter”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Con 99 Merit el backend devuelve failed-precondition, conserva saldo y no crea partida.
- Las solicitudes rechazadas por competencia no generan saldo negativo ni partidas extra.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| AC05-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| AC05-C04 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.4-S — Acceso al modo Ranked

Fuente: ASR Historias de Usuario!E 38: E 39; fuente complementaria

Dado que soy usuario autenticado y el saldo Merit para usar el modo Ranked,
cuando selecciono la opción “Play Ranked”,
entonces el sistema descuenta el costo de entrada y inicia una sesión competitiva Ranked, permitiendo ingresar al flujo competitivo.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- El callable/start de backend crea partida Ranked y debita el costo.
- GameViewModel controlado recibe una partida Ranked correctamente.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-MAR-01-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| BASE-INT-11 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_4_scenario1_play_ranked_starts_competitive_session | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.4-F — Acceso al modo Ranked

Fuente: ASR Historias de Usuario!E 38: E 39; fuente complementaria

Dado que soy usuario autenticado pero no tengo el saldo Merit para usar el modo Ranked,
cuando selecciono la opción “Play Ranked”,
entonces el sistema detiene el proceso y muestra el mensaje "The ranked match cannot be started. Insufficient Merit"

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Backend impide iniciar por saldo insuficiente sin efectos indebidos.
- GameViewModel traduce Insufficient Merit al aviso Ranked canónico.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| AC05-C01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_4_scenario2_play_ranked_blocked_insufficient_merit | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.5-S — Emparejamiento con otro jugador

Fuente: Informe vigente tabla 5.3

Dado que me encuentro habilitado para jugar Ranked,
cuando termine de escribir mi párrafo,
entonces el sistema me registra en la cola de emparejamiento asincrónico y asigna mi párrafo al de un rival cuyo párrafo también se encontraba en espera de un emparejamiento.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Emulador empareja partidas evaluadas de autores diferentes con resultados recíprocos.
- Delta 30 se admite; 31, mismo autor, modo incompatible o perfil cerrado no forman pareja.
- Prioridad entre timestamps antiguos y recientes se comprueba.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-06 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-01 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-02 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-03 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-04 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-05 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-06 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.5-F — Emparejamiento con otro jugador

Fuente: Informe vigente tabla 5.3

Dado que me encuentro habilitado para jugar Ranked pero no hay párrafos esperando a ser emparejados en la cola asincrónica
cuando pasan 48 horas sin que mi párrafo sea emparejado,
entonces el sistema detiene el proceso, y evalúa mi párrafo con mi puntuación promedio.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- A las 48 h − 1 ms la partida sigue pendiente; a las 48 h se resuelve por baseline con reloj controlado.
- Tres operaciones concurrentes esperan todas, exigen cero rechazos y pico tres; no repiten rating/Merit.
- REV-MATCH-07 comprueba promedio 70 de historia [60, 80], distinto de la puntuación actual 80.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-07 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| REV-MATCH-07 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.6-S — Consulta de rating actual

Fuente: ASR Historias de Usuario!E 42: E 43; fuente complementaria

Dado que poseo una cuenta con actividad competitiva,
cuando accedo a mi perfil,
entonces el sistema muestra mi rating actual.

**Estado local:** No demostrado funcionalmente; evidencia auxiliar. **Integral E2E:** no demostrado.


mapUser preserva el campo rating; la prueba histórica de cliente construye User y lee la propiedad. Eso no prueba consulta del perfil.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-MAT-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-MAT-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_6_scenario1_current_rating_displayed_in_profile | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.6-F — Consulta de rating actual

Fuente: ASR Historias de Usuario!E 42: E 43; fuente complementaria

Dado que poseo una cuenta con actividad competitiva pero ocurre un fallo al querer recuperar el rating,
cuando accedo a mi perfil,
entonces el sistema muestra el mensaje "Server failure”.

**Estado local:** B: defecto de mensaje reproducido en base; corrección separada verificada. **Integral E2E:** no demostrado.

- Fallo real inducido en dependencia; estado, mensaje observado y efectos comprobados en ViewModel y pantalla. La base no satisface el literal requerido.

La propuesta cliente pasa estos escenarios; no se atribuye su aprobación a la base. No hay Google/Firebase cloud real.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CLI_HU36_C01 | fallido | Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ClienteNegativeFlowTest.xml>) |
| UI_HU36_C01 | fallido | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |
| INT_HU36_C02 | fallido | SDK, repositorio, reglas y emulador reales; inicialización/sesión controladas. Sin Google/OpenAI real | [registro](<../cierre/ui/base-sdk/instrumentation.log>) |

## HU 3.7-S — Actualización de rating tras una partida

Fuente: Informe vigente tabla 5.3

Dado que he terminado una partida Ranked y cuenta con una evaluación válida,
cuando el sistema procesa los resultados de la partida,
entonces el sistema actualiza el rating según las reglas establecidas.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- ratingChange reproduce la regla lineal actual en nueve situaciones como caracterización.
- Emulador persiste actualización de rating de pareja y evita repetirla/cambiar temporada incorrectamente.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| UT-VIC-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C02 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C03 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C04 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| UT-VIC-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| BASE-INT-06 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |
| BASE-INT-08 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.7-F — Actualización de rating tras una partida

Fuente: Informe vigente tabla 5.3

Dado que una partida Ranked ha finalizado pero hubo un problema al calcular el rating,
cuando el sistema procesa los resultados de la partida,
entonces el sistema muestra el mensaje “The game ranking could not be updated”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- Fallo controlado de matching persiste matchError canónico y una recuperación exitosa lo limpia.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| BASE-INT-17 | aprobado | Firestore emulado | [registro](<../cierre/matchmaking/evidencias/base-functional-final/run-01.log>) |

## HU 3.8-S — Visualización del resultado de la partida

Fuente: ASR Historias de Usuario!E 46: E 47; fuente complementaria

Dado que he terminado una partida Ranked, se ha asignado con la de otro usuario y cuenta con una evaluación válida,
cuando se acceda a la pantalla de resultados,
entonces el sistema muestra si fue victoria, derrota o empate.

**Estado local:** No demostrado funcionalmente; evidencia auxiliar. **Integral E2E:** no demostrado.


GameDto.toDomain interpreta WIN/LOSS/DRAW y datos del oponente. El test histórico solo construye MatchResult.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| AND_JEA_C01 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| AND_JEA_C02 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| AND_JEA_C03 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_8_scenario1_match_outcome_displays_win_loss_draw | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.8-F — Visualización del resultado de la partida

Fuente: ASR Historias de Usuario!E 46: E 47; fuente complementaria

Dado que una partida Ranked ha finalizado pero hubo un problema al obtener los resultados,
cuando se acceda a la pantalla de resultados,
entonces el sistema muestra el mensaje "The game result could not be updated”.

**Estado local:** B: defecto de mensaje reproducido en base; corrección separada verificada. **Integral E2E:** no demostrado.

- Fallo real inducido en dependencia; estado, mensaje observado y efectos comprobados en ViewModel y pantalla. La base no satisface el literal requerido.

La propuesta cliente pasa estos escenarios; no se atribuye su aprobación a la base. No hay Google/Firebase cloud real.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CLI_HU38_C01 | fallido | Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ClienteNegativeFlowTest.xml>) |
| CLI_HU38_C03 | aprobado | Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ClienteNegativeFlowTest.xml>) |
| CLI_HU38_C04 | fallido | Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ClienteNegativeFlowTest.xml>) |
| UI_HU38_C01 | fallido | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |
| UI_HU38_C02 | aprobado | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |
| UI_HU38_C03 | fallido | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |

## HU 3.9-S — Consulta de variación del rating

Fuente: ASR Historias de Usuario!E 48: E 49; fuente complementaria

Dado que he terminado una partida Ranked y se calculó la variación de puntos,
cuando se accede a la pantalla de resultados,
entonces el sistema indica la cantidad de rating perdido o ganado basado en la diferencias de ratings entre los usuarios que fueron emparejados

**Estado local:** No demostrado funcionalmente; evidencia auxiliar. **Integral E2E:** no demostrado.


El mapper conserva +4, −6 y ausencia de variación; ratingChange se caracteriza, sin aprobar ELO ni renderizar la variación.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| AND_JEA_C01 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| AND_JEA_C02 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| AND_JEA_C03 | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.Capitulo10MappingTest.xml>) |
| UT-VIC-01-C03 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| ANDROID-AcceptanceCriteriaSuiteTest.hu3_9_scenario1_rating_variation_displayed | aprobado | JVM con dobles o mapper real; no pantalla renderizada | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml>) |

## HU 3.9-F — Consulta de variación del rating

Fuente: ASR Historias de Usuario!E 48: E 49; fuente complementaria

Dado que una partida Ranked ha finalizado pero no se pudo calcular la variación del rating,
cuando se accede a la pantalla de resultados,
entonces el sistema muestra el mensaje "Server failure”.

**Estado local:** A: cláusula local de fallo y mensaje demostrada en mapper, ViewModel y UI. **Integral E2E:** no demostrado.

- Dato ratingChange inválido se conserva como null; UI real muestra Server failure y no inventa cero; reconexión restaura −6 sin nuevo envío.

Repositorios controlados. No se certifica regla ELO ni servicio remoto.

| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CLI_HU39_C01 | aprobado | Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto | [registro](<../cierre/cliente/base-all-coverage-xml/TEST-com.inkr8.presentation.ClienteNegativeFlowTest.xml>) |
| UI_HU39_C01 | aprobado | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |
| UI_HU39_C02 | aprobado | Compose y ViewModel reales en AVD; repositorios controlados explícitos | [registro](<../cierre/ui/base-visual/instrumentation.log>) |

## HU 3.12-S — Validación de restricciones avanzadas

Fuente: Informe vigente tabla 5.3

Dado que he enviado una respuesta en una partida On-Topic,
cuando R8 procesa mi texto,
entonces el sistema determina cuáles restricciones avanzadas fueron cumplidas y cuáles no.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- structureEvaluation determina primera persona, pregunta, palabras y longitud del texto controlado; discrimina reglas cumplidas/incumplidas.
- La relevancia de tópico se incorpora a partir de un booleano controlado.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-PED-01-C01 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C03 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C04 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |

## HU 3.12-F — Validación de restricciones avanzadas

Fuente: Informe vigente tabla 5.3

Dado que he enviado una respuesta en una partida On-Topic,
cuando ocurre un fallo durante la validación de restricciones,
entonces el sistema muestra el mensaje “Compliance with restrictions could not be verified”.

**Estado local:** Parcial: cláusulas locales demostradas. **Integral E2E:** no demostrado.

- topicRelevant ausente o regla avanzada desconocida produce Compliance with restrictions could not be verified.
- El score base se conserva ante feedback/validación incompletos.



| Caso | Resultado base | Nivel | Evidencia |
|---|---|---|---|
| CN-PED-01-C02 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |
| CN-PED-01-C05 | aprobado | Node con dobles | [registro](<../evidencias/cierre/backend/base-unit-final.log>) |

Versiones procesables: [JSON](Criterios_Demostrados.json), [CSV](Criterios_Demostrados.csv). Correcciones del cliente: [propuesta](../cierre/cliente/Reporte_Cliente.md); sus aprobaciones no se atribuyen a la base. Pendientes externos: [inventario único](../Pendientes_Externos.md).
