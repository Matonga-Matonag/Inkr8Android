# Contraste técnico de los seis paquetes

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

La fuente es Rubrica!D18 de la [rúbrica original](../fuentes/originales/Rubrica_Final_Proyecto_2026_2.xlsx). Se verificaron seis CFG con V≥5, bases independientes respaldadas por 42 casos aprobados y 67 unitarias principales (al menos 4 por método). Los cinco o más campos se verifican en cada frontera declarada, sin confundirlos con cinco controles de UI. La aceptación docente y participación individual no se fabrican.

| Paquete | CB / V(G) | UT / casos | CN / campos |
|---|---|---|---|
| Marco | meritReward / 11 | meritReward / 24 | FirebaseGameRepository.start / 6 |
| Pedro | validateWriting / 6 | EvaluateGame.execute / 10 | structureEvaluation / 10 |
| Víctor | ratingChange / 5 | ratingChange / 9 | FirebaseGameRepository.complete / 7 |
| Jean Carlo | league / 6 | league / 12 | OpenAiWritingEvaluator.evaluate / 6 |
| Renzo | dailyWord / 7 | GetWordExample.execute / 5 | GetDailyHome.execute → FirebaseContentRepository.dailyWord / 5 |
| Matías | mapUser / 7 | mapUser / 7 | mapUser / 7 |

Los 42 caminos conservan CFG coherentes y testigos en logs finales; no se afirma trazado dinámico de nodos. Los casos unitarios son distinguibles por entradas, errores y efectos, y la [cobertura medida](../evidencias/Cobertura.md) se informa por archivo/módulo, sin inventar porcentajes por método.

Renzo mejora la frontera desde el helper privado a Home observable: 25/25 casos, cinco campos reales de catálogo, particiones vacío/espacios/ausente/no vacío y efectos de caché. No tiene cinco argumentos públicos: getHome recibe cero y dailyWord uno. [Opciones comprobadas y consulta exacta](../cierre/caja_negra/CN_Renzo_Observable.md); la decisión docente sigue en EXT-01. Los otros contratos internos conservan también su reserva docente.

Los resultados actuales de base son 116/116 unidad y 100/100 funcional. Los fallos de carga, mensajes y recuperación automática permanecen en el registro de defectos; no invalidan el conteo estructural ni lo convierten en aceptación integral. [Datos](Auditoria_Rubrica.json), [seis fichas](../paquetes/Seis_fichas.json), [pendientes únicos](../Pendientes_Externos.md).
