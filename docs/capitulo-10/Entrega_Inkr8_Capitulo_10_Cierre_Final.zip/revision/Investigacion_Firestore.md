# Investigación de Firestore — antecedentes y cierre

Cierre actual: base 26/50 llamadas, 26 MATCHED/13 parejas, pico 50; propuesta 3×50/50 y 51/51. Los ensayos que siguen son antecedentes y no se suman al cierre. [Validación ampliada](../cierre/matchmaking/Validacion_Final.md).

Se mantuvieron 50 solicitudes, datos válidos con timestamps empatados, solapamiento medido y las aserciones originales. Se contrastaron dos versiones del emulador, controles mínimos y una copia aislada del producto.

| Ensayo | Variable / operación | Resultado |
|---|---|---|
| r01 | Emulador 1.22, producto original | 6/50 llamadas sin error; 50 solapadas; falla |
| r02 | 50 transacciones independientes, sin Inkr8 | 50/50 |
| r03 | 50 independientes con escritura compartida seasons/s 0 | 50/50; no basta por sí sola para atribuir el fallo |
| r04 | 50 operaciones sobre 25 pares independientes | 50/50 |
| r05 | 50 incrementos sobre 1 documento, sin Inkr8 | 11/50; 39 ABORTED, sin bajar concurrencia |
| r06 | Traza SDK del producto original | 45 ABORTED; hasta 5 intentos del SDK; mayor concentración en m 10 |
| r07/r08 | 48 h de forma aislada, 10 por versión 1.22/1.19.8 | 20/20 aprobados |
| r09 | Carga original y luego 5 recuperaciones a 48 h | Carga falla; 5/5 recuperaciones aprobadas |
| p04 | Solo desempate, 3 repeticiones carga original | 3 × 50/50; 25 parejas, pico de 50 y cero violaciones cada vez |
| p05/p06/p07 | Cierre propuesta, sin sumar a base | 51 funcionales + 116 de unidad + 1 de carga = 168/168 backend |

## Causa y alcance

La carga falla por contención transaccional observada en este entorno. El control mínimo sin Inkr8 también falla al competir 50 transacciones por un documento; los controles independientes y por parejas aprueban. La traza del recorrido original concentra lecturas en pocos candidatos. La mejora con un único cambio de orden de desempate demuestra que ese recorrido contribuye al problema en este perfil. No demuestra que todo error sea del producto ni que toda contención sea exclusiva del emulador. Los datos empatados son válidos y permanecieron iguales.

Firebase documenta diferencias transaccionales del emulador y demoras de liberación de bloqueos bajo escrituras concurrentes. Sus SDK reintentan un número finito de veces ante contención. Estas limitaciones apoyan el diagnóstico, sin sustituir los controles ejecutados. [Emulador](https://firebase.google.com/docs/emulator-suite/connect_firestore#transactions), [contención](https://firebase.google.com/docs/firestore/transaction-data-contention).

El error histórico de 48 h procede de una operación transaccional que el servidor reportó inválida/cerrada. No se encontró un cálculo incorrecto del reloj ni un cambio indebido de temporada. Su causa exacta no se reprodujo en 25 diagnósticos posteriores ni en la suite funcional final. El ajuste de fixture evita abandonar operaciones en curso cuando una falla y evita compartir la instancia de carga; no es prueba de eliminación universal del error 3.

## Correcciones de prueba y datos

| Cambio | Qué se hizo | Verificación |
|---|---|---|
| Separación de carga | El cuerpo de AC 03 se movió intacto a capitulo 10.concurrency.test.cjs; SHA del cuerpo coincide con la entrega previa. Instancia nueva para funcional y carga. | Pico de 50 y aserciones 50 llamadas completas, 50 partidas MATCHED, 25 parejas y cero violaciones conservadas. |
| Recuperación a 48 h | Promise.allSettled espera las 3 operaciones; se exige cero rechazos y se mide pico de 3. Se conserva 48 h − 1 ms / 48 h, resultado y rating único; se añadió Merit inalterado. | 51/51 funcionales; error histórico no borrado. |
| Datos CN | ON_TOPIC con 2 palabras; partida expirada creada realmente antes del cambio de temporada; Game/Word completos en Pedro/Jean; texto de 50 palabras y fixture STANDARD coherente con 4 palabras. | 116/116 de unidad/adaptador y 51/51 de emulador. |
| Regresiones de propuesta | Siete casos nuevos: delta 31/30, prioridad del timestamp antiguo, mismo autor, modo incompatible, perfil cerrado, promedio histórico de 70 calculado de 60/80. | Aprobados en base y copia con propuesta. |

## Reproducción de controles

Desde la carpeta de trabajo de esta entrega, por ejemplo:

```powershell
python work/revision/serve_and_run.py --jar work/revision/cloud-firestore-emulator-v1.22.0.jar --mode shared-counter control -- node --test functions/integration/revision.controls.test.cjs
```

El helper abre exclusivamente loopback/demo-inkr8, conserva comando, hash del JAR, log de servidor y resultado. Cambiar mode por independent/shared-season/pairs reproduce los otros controles; siguen siendo 50 operaciones. Los comandos originales de cada experimento están en `evidencias/revision/<ensayo>/experiment.json`. No forman parte del denominador final de 257 casos ni de la aportación individual.

## Clasificación del origen

| Origen | Carga de 50 | Recuperación de 48 h |
|---|---|---|
| Producto | El recorrido original concentra candidatos; cambiar solo el desempate permite completar este perfil. Corrección candidata aparte. | No se ha demostrado un defecto de cálculo ni una corrección de producto para el error histórico. |
| Prueba | Se aisló la carga en otra instancia; su cuerpo y todas las aserciones permanecen iguales. | `Promise.all` podía dejar solicitudes activas tras un rechazo y permitir limpieza prematura. `allSettled` espera las tres y exige cero errores; no se acredita eliminación universal. |
| Datos | Los timestamps empatados son válidos y se conservaron. | No se encontró un error de reloj; los fixtures de temporada usados en CN se corrigieron de forma independiente. |
| Entorno | El control sin Inkr8 también agota reintentos por lock timeout. El comportamiento no certifica capacidad cloud. | El servidor/SDK informó transacción inválida/cerrada; la causa exacta sigue sin reproducirse. |

Evidencia principal: [carga base](../evidencias/AC03_50_solicitudes.json), [48 h y tres solicitudes](../evidencias/recuperacion_48h.json), [control mínimo](../evidencias/revision/r05-control-shared-counter/experiment.json), [traza del producto](../evidencias/revision/r06-product-trace/experiment.json), [propuesta final](../evidencias/revision/p07-propuesta-final-load/experiment.json). El índice de [evidencias de revisión](../evidencias/revision/LEEME.md) distingue ensayos exploratorios y resultados finales.
