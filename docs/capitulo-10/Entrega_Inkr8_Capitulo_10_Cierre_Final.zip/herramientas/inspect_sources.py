import hashlib, json, pathlib
from docx import Document
from openpyxl import load_workbook
from pypdf import PdfReader
root=pathlib.Path(__file__).resolve().parent.parent
p=root/'work/Paquete_Codex_Inkr8/Paquete_Codex_Inkr8'
out=root/'outputs/evidencias'; out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((p/'manifest_sha256.json').read_text(encoding='utf-8-sig'))
checks=[dict(path=f['path'],ok=(hashlib.sha256((p/f['path']).read_bytes()).hexdigest()==f['sha256'])) for f in manifest['files']]
for name in ['Prompt_Inkr8_Capitulo_10.md','Auditoria_Documental_Inkr8.md','Referencia_Henry_Wong_Inkr8.md']:
    checks.append(dict(path='adjunto/'+name,ok=(p/name).read_bytes()==(pathlib.Path('D:/Descargas')/name).read_bytes()))
(out/'integridad_fuentes.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding='utf-8')
original=p/'referencias_locales/originales'; sources={}
wb=load_workbook(original/'Rubrica_Final_Proyecto_2026_2.xlsx',data_only=False)
sources['rubrica_D18']=wb['Rubrica']['D18'].value
asr=load_workbook(original/'ASR_Inkr8.xlsx',data_only=False)
sources['asr_muestras']={c:{'valor':asr['Historias de Usuario'][c].value,'formato':asr['Historias de Usuario'][c].number_format} for c in ['B2','B20','B50','D2','E2','E3']}
doc=Document(original/'Informe_Grupo_3_2026-11-05.docx')
tables=[[[c.text for c in r.cells] for r in t.rows] for t in doc.tables]
sources['tablas_pertinentes']=[{'index_zero_based':i,'rows':t} for i,t in enumerate(tables) if (any('HU 3.12' in ' '.join(r) for r in t) and any('HU 2.3' in ' '.join(r) for r in t)) or (any('AC-01' in ' '.join(r) for r in t))]
for filename,pages in [('Guia_Uso_IA_ISW2.pdf',[7,8,9,10,11,12]),('Enunciado_Proyecto_Final.pdf',[0,1,2,3]),('Semana_12_Pruebas_Rendimiento_v2.pdf',[8,9,30,31,32,36,37,54,55,56])]:
    reader=PdfReader(original/filename)
    sources[filename]={'page_count':len(reader.pages),'pages':[{'page':i+1,'text':reader.pages[i].extract_text()} for i in pages if i<len(reader.pages)]}
(out/'contraste_fuentes_primarias.json').write_text(json.dumps(sources,indent=2,ensure_ascii=False,default=str),encoding='utf-8')
print('integridad',sum(c['ok'] for c in checks),'/',len(checks))
print('Rubrica D18:',sources['rubrica_D18'])
print('Tablas pertinentes:',[(x['index_zero_based'],len(x['rows']),x['rows'][0]) for x in sources['tablas_pertinentes']])
