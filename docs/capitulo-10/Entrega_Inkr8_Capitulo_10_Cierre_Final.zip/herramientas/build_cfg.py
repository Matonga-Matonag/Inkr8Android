import json,pathlib
root=pathlib.Path(__file__).resolve().parent.parent; out=root/'outputs'; target=out/'caja_blanca';target.mkdir(parents=True,exist_ok=True)
def rank(rows):
    pivots={}
    for row in rows:
        n=row
        while n:
            b=n.bit_length()-1
            if b in pivots:n^=pivots[b]
            else:pivots[b]=n;break
    return len(pivots)
graphs=[]
def save(code,person,symbol,file,nodes,edges,paths,cases,scope='Flujo de la función indicada; llamadas auxiliares atómicas; excepciones implícitas de bibliotecas fuera del CFG.'):
    original_nodes=nodes
    numbering={key:f'N{i+1:02d}' for i,key in enumerate(nodes)}
    nodes={numbering[key]:value for key,value in nodes.items()}
    edges=[(numbering[a],numbering[b]) for a,b in edges]
    paths=[[numbering[x] for x in path] for path in paths]
    assert all(a in nodes and b in nodes for a,b in edges)
    assert len(set(edges))==len(edges)
    vectors=[]; previous=0; ps=[]
    for i,path in enumerate(paths):
        v=0
        for edge in zip(path,path[1:]):
            assert edge in edges,(symbol,edge)
            v^=1<<edges.index(edge)
        vectors.append(v); r=rank(vectors)
        ps.append({'id':f'P{i+1}','nodes':path,'case':cases[i],'rank_prefix':r,'independent':r>previous});previous=r
    vg=len(edges)-len(nodes)+2
    degrees=[sum(a==n for a,b in edges) for n in nodes]; alt=1+sum(max(d-1,0) for d in degrees)
    assert vg==alt and vg>=5,(symbol,vg,alt)
    assert len(paths)==vg and rank(vectors)==vg,(symbol,vg,len(paths),rank(vectors))
    src=root/'work/backend/functions/src'/file
    lines=src.read_text(encoding='utf-8').splitlines()
    if symbol=='dailyWord':
        start=next(i for i,s in enumerate(lines) if 'async dailyWord(' in s)
        end=next(i for i,s in enumerate(lines[start+1:],start+1) if 'private hasMetadata' in s)
    else:
        start=next(i for i,s in enumerate(lines) if f'function {symbol}(' in s)
        end=next((i for i in range(start+1,len(lines)) if lines[i].startswith('export ')),len(lines))
    edge_labels={}
    for node in nodes:
        outgoing=[(a,b) for a,b in edges if a==node]
        if len(outgoing)==2:
            edge_labels['->'.join(outgoing[0])]='T';edge_labels['->'.join(outgoing[1])]='F'
    g={'id':code,'person':person,'symbol':symbol,'source':'functions/src/'+file,'line_start':start+1,'line_end':end,'scope':scope,'nodes':nodes,'edges':edges,'edge_labels':edge_labels,'paths':ps,'N':len(nodes),'E':len(edges),'components':1,'V':vg,'decision_sum':alt,'path_vector_rank_GF2':rank(vectors)};graphs.append(g)
    content=f'# {code} {person} — {symbol}\n\nBase `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `{g["source"]}:{start+1}`.\n\n{scope}\n\n'
    content+='Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.\n\n'
    content+=f'**N={len(nodes)}, E={len(edges)}, componentes=1; V(G)=E−N+2={vg}.** El contraste `1+Σ(grado_salida−1)` da {alt}. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.\n\n'
    def source_fragment(node):
        if node=='X':return None
        if symbol=='meritReward':return 'export function' if node=='S' else ('if (' if node in ['A','B','C','ERR'] else ('const base' if node.startswith('D') or node.startswith('V') else 'return Math.floor'))
        if symbol=='validateWriting':return 'const count' if node=='S' else ('if (' if node in ['A','B','C','M150','M200','D'] else ('throw new' if node in ['F','E150','E200','ERR'] else '  }'))
        if symbol=='ratingChange':return 'const adjustment' if node=='S' else ('outcome === "DRAW"' if node in ['D','DR'] else ('outcome === "LOSS"' if node in ['L','LR'] else 'return Math.max'))
        if symbol=='league':return 'export function' if node=='S' else 'return rating'
        if symbol=='mapUser':return 'export function' if node=='S' else ('return {id' if node[-1:] in ['0','1','2'] else 'rating: dto.rating')
        if symbol=='dailyWord':
            if node=='S':return 'const ref ='
            if node in ['A','B','CACHED']:return 'if (saved.exists'
            if node in ['C','EMPTY']:return 'if (!words.length)'
            if node in ['D','FIND','CHOOSE']:return 'const word = saved.exists'
            if node in ['E','F','ERR']:return 'if (!word ||'
            if node=='TX':return 'return this.db.runTransaction'
        return None
    annotations={}
    for node in original_nodes:
        fragment=source_fragment(node)
        if fragment:
            pos=next((i for i in range(start,end) if fragment in lines[i]),None)
            if pos is not None:annotations.setdefault(pos,[]).append(numbering[node])
    content+='## Fuente numerada\n\nLos comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.\n\n```typescript\n'+'\n'.join(f'{i+1:03d}  {lines[i]}'+(' // '+', '.join(annotations[i]) if i in annotations else '') for i in range(start,end))+'\n```\n\n'
    content+='## Nodos y grafo\n\n| Nodo | Código / operación representada |\n|---|---|\n'+'\n'.join(f'| {n} | {label.replace("|","&#124;")} |' for n,label in nodes.items())+'\n\n```mermaid\nflowchart TD\n'
    content+='\n'.join(f'  {n}["{label.replace(chr(34),chr(39)).replace("<","&lt;")}"]' for n,label in nodes.items())+'\n'
    content+='\n'.join(f'  {a} -->'+(f'|{edge_labels[a+"->"+b]}|' if a+'->'+b in edge_labels else '')+f' {b}' for a,b in edges)+'\n```\n\nT/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.\n\n'
    content+='## Base factible y ejecución\n\n| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |\n|---|---|---|---|\n'
    content+='\n'.join(f'| {p["id"]} | {" → ".join(p["nodes"])} | {p["case"]} | {p["rank_prefix"]} |' for p in ps)+'\n\n'
    content+=f'Los {vg} vectores de incidencia de aristas tienen rango {vg} en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en '+('[final-firestore-functional.log](../evidencias/final-firestore-functional.log)' if symbol=='dailyWord' else '[final-node20-unit.log](../evidencias/final-node20-unit.log)')+'. Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.\n'
    (target/(code+'.md')).write_text(content,encoding='utf-8')

# Merit: 3 decisiones de validación + 6 umbrales + Ranked = 10 decisiones.
n={'S':'Entrada score,count,ranked','A':'!Number.isFinite(score)?','B':'score < 0?','C':'score > 100?','ERR':'throw invalid-argument'}
e=[('S','A'),('A','ERR'),('A','B'),('B','ERR'),('B','C'),('C','ERR'),('C','D95')]
thresholds=[95,90,80,70,60,40]; bases=[500,400,300,200,125,60,25]
for i,t in enumerate(thresholds):
    n['D'+str(t)]=f'score >= {t}?';n['V'+str(bases[i])]=f'base = {bases[i]}'
    e.extend([('D'+str(t),'V'+str(bases[i])),('D'+str(t),'D'+str(thresholds[i+1]) if i<5 else 'V25')])
n.update(V25='base = 25',R='ranked?',M15='factor = 1.5',M1='factor = 1',RET='floor((base + min(floor(count/10),40))*factor)',X='Salida común')
e.extend([('V'+str(b),'R') for b in bases]+[('R','M15'),('R','M1'),('M15','RET'),('M1','RET'),('RET','X'),('ERR','X')])
def merit_path(score,ranked=False):
    path=['S','A'];
    if score=='NaN':return path+['ERR','X']
    path+=['B']
    if score<0:return path+['ERR','X']
    path+=['C']
    if score>100:return path+['ERR','X']
    for t,b in zip(thresholds,bases):
        path+=['D'+str(t)]
        if score>=t:path+=['V'+str(b)];break
    else:path+=['V25']
    return path+['R','M15' if ranked else 'M1','RET','X']
save('CB-MAR-01','Marco','meritReward','domain/policy/gamePolicy.ts',n,e,[merit_path(s,r) for s,r in [(0,False),(40,False),(60,False),(70,False),(80,False),(90,False),(95,False),(0,True),('NaN',False),(-1,False),(101,False)]],[f'UT-MAR-01-C{i:02d}' for i in range(1,12)])

n={'S':'wordCount(text)','A':'text.length > 10000?','B':'count < 50?','C':'mode === STANDARD? (máximo)','M150':'max = 150','M200':'max = 200','D':'count > max?','V':'return void','F':'mode === STANDARD? (mensaje)','E150':'mensaje 50..150','E200':'mensaje 50..200','ERR':'throw invalid-argument','X':'Salida común'}
e=[('S','A'),('A','F'),('A','B'),('B','F'),('B','C'),('C','M150'),('C','M200'),('M150','D'),('M200','D'),('D','F'),('D','V'),('F','E150'),('F','E200'),('E150','ERR'),('E200','ERR'),('ERR','X'),('V','X')]
paths=[['S','A','B','C','M150','D','V','X'],['S','A','B','C','M200','D','V','X'],['S','A','F','E150','ERR','X'],['S','A','F','E200','ERR','X'],['S','A','B','F','E150','ERR','X'],['S','A','B','C','M150','D','F','E150','ERR','X']]
save('CB-PED-01','Pedro','validateWriting','domain/policy/gamePolicy.ts',n,e,paths,[f'CB-PED-01-C{i:02d}' for i in range(1,7)],'Función TypeScript validateWriting. Se incluye el ternario del mensaje de error: es código distinto del ternario del máximo. wordCount se considera llamada atómica. HU 2.2 adicional justificada por validación y envío; no se atribuye esta complejidad a Kotlin.')

n={'S':'adjustment = clamp((opponent-mine)*0.05)','D':'outcome === DRAW?','DR':'return 1','L':'outcome === LOSS?','LR':'return min(-1,round(-6+adjustment))','H180':'mine >= 180?','V2':'cap = 2','H150':'mine >= 150?','V3':'cap = 3','VI':'cap = Infinity','WR':'return max(1,min(round(4+adjustment),cap))','X':'Salida común'}
e=[('S','D'),('D','DR'),('D','L'),('DR','X'),('L','LR'),('L','H180'),('LR','X'),('H180','V2'),('H180','H150'),('H150','V3'),('H150','VI'),('V2','WR'),('V3','WR'),('VI','WR'),('WR','X')]
paths=[['S','D','DR','X'],['S','D','L','LR','X'],['S','D','L','H180','H150','VI','WR','X'],['S','D','L','H180','H150','V3','WR','X'],['S','D','L','H180','V2','WR','X']]
save('CB-VIC-01','Víctor','ratingChange','domain/policy/gamePolicy.ts',n,e,paths,[f'UT-VIC-01-C{i:02d}' for i in range(1,6)],'Caracterización de la regla actual de rating; no conformidad con ELO oficial AC-06. Math.min/max no añaden decisiones propias.')

n={'S':'Entrada rating','X':'Salida común'};e=[('S','D30')];paths=[]
for i,t in enumerate([30,60,90,120,150]):
    n[f'D{t}']=f'rating < {t}?';n[f'R{i+1}']=f'return {i+1}'
    e.extend([(f'D{t}',f'R{i+1}'),(f'R{i+1}','X'),(f'D{t}',f'D{[30,60,90,120,150][i+1]}' if i<4 else 'R6')])
n['R6']='return 6';e.append(('R6','X'))
for i in range(6):paths.append(['S']+[f'D{t}' for t in [30,60,90,120,150][:min(i+1,5)]]+[f'R{i+1}','X'])
save('CB-JEA-01','Jean Carlo','league','domain/policy/gamePolicy.ts',n,e,paths,[f'UT-JEA-01-C{i:02d}' for i in range(1,7)],'Rotación de candidato: league del backend da soporte al rating mostrado. El cliente tiene una función homóloga, pero este CFG pertenece únicamente al commit TypeScript indicado.')

n={'S':'leer saved dailyWords/day','A':'saved.exists?','B':'hasMetadata(saved)?','CACHED':'return saved','C':'!words.length?','EMPTY':'throw No hay palabras activas','D':'saved.exists? (selección)','FIND':'words.find(text == saved.text)','CHOOSE':'selección módulo del día','E':'!word?','F':'!hasMetadata(word)?','ERR':'throw información incompleta','TX':'return db.runTransaction(callback)','X':'Salida común'}
e=[('S','A'),('A','B'),('A','C'),('B','CACHED'),('B','C'),('CACHED','X'),('C','EMPTY'),('C','D'),('EMPTY','X'),('D','FIND'),('D','CHOOSE'),('FIND','E'),('CHOOSE','E'),('E','ERR'),('E','F'),('F','ERR'),('F','TX'),('ERR','X'),('TX','X')]
paths=[['S','A','B','CACHED','X'],['S','A','C','EMPTY','X'],['S','A','B','C','EMPTY','X'],['S','A','C','D','CHOOSE','E','F','TX','X'],['S','A','B','C','D','FIND','E','F','TX','X'],['S','A','B','C','D','FIND','E','ERR','X'],['S','A','C','D','CHOOSE','E','F','ERR','X']]
save('CB-REN-01','Renzo','dailyWord','data/repository/firebaseContentRepository.ts',n,e,paths,[f'CB-REN-01-C{i:02d}' for i in range(1,8)],'Flujo conectado exterior de dailyWord; el callback transaccional empieza en su propia entrada y se excluye del conteo. Tampoco se suman words.find, words() ni hasMetadata. Sus efectos se ejercitan en Firestore, pero no elevan V(G) de este grafo.')

n={'S':'Entrada id,dto','X':'Salida User'};e=[('S','D0')];keys=['name','email','merit','rating','seasonIndex','username']
for i,key in enumerate(keys):
    n[f'D{i}']=f'{key}: valor definido'+(' y truthy?' if i==0 else '? (??)');n[f'V{i}']=f'usar dto.{key}';n[f'F{i}']=f'default {key}'
    nxt=f'D{i+1}' if i<5 else 'X';e.extend([(f'D{i}',f'V{i}'),(f'D{i}',f'F{i}'),(f'V{i}',nxt),(f'F{i}',nxt)])
paths=[]
for missing in [None,0,1,2,3,4,5]:
    path=['S']
    for i in range(6):path.extend([f'D{i}',f'F{i}' if i==missing else f'V{i}'])
    paths.append(path+['X'])
save('CB-MAT-01','Matías','mapUser','data/dto/userDto.ts',n,e,paths,[f'UT-MAT-01-C{i:02d}' for i in range(1,8)])
(target/'grafos_y_caminos.json').write_text(json.dumps(graphs,indent=2,ensure_ascii=False),encoding='utf-8')
print([(g['id'],g['N'],g['E'],g['V'],g['path_vector_rank_GF2']) for g in graphs])
