import collections,csv,datetime,hashlib,json,os,pathlib,re,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
root=pathlib.Path(__file__).resolve().parent.parent; out=root/'outputs'; ev=out/'evidencias'; package=root/'work/Paquete_Codex_Inkr8/Paquete_Codex_Inkr8'
BACK='993c6b0641a4a60603d87e251c90f51783460007'; FRONT='d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c'
def read(p):return pathlib.Path(p).read_text(encoding='utf-8-sig')
def write(p,s):p=out/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def js(p,obj):write(p,json.dumps(obj,ensure_ascii=False,indent=2,default=str))
def table(headers,rows):
    clean=lambda v:str(v).replace('|','&#124;').replace('\n','<br>')
    return '| '+' | '.join(headers)+' |\n|'+ '|'.join('---' for _ in headers)+'|\n'+'\n'.join('| '+' | '.join(clean(v) for v in r)+' |' for r in rows)+'\n'
def csvout(p,rows,fields=None):
    if not rows:return
    dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(dict.fromkeys(k for row in rows for k in row)));w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

catalog=json.loads(read(package/'catalogo_hu.json')); byhu={h['id']:h for h in catalog}; priority=[h for h in catalog if h['in_priority_union']]; selected=priority+[byhu['HU 2.2']]
graphs=json.loads(read(out/'caja_blanca/grafos_y_caminos.json'))
evidence_labels=['final-node20-unit','final-firestore-functional','final-firestore-concurrency','android-final-offline']
assert all((ev/(x+'.json')).exists() for x in evidence_labels)
quality=json.loads(read(ev/'AC03_50_solicitudes.json'))

# Copias de los reportes reales. No se recrean sus resultados.
for module,task,report in [('domain','test','test'),('app','testDebugUnitTest','jacocoDebugUnitTestReport')]:
    repo=root/'work/frontend'/module
    shutil.copytree(repo/'build/test-results'/task,ev/f'android-{module}-xml',dirs_exist_ok=True)
    shutil.copytree(repo/'build/reports/tests'/task,ev/f'android-{module}-tests-html',dirs_exist_ok=True)
    shutil.copytree(repo/'build/reports/jacoco'/report,ev/f'android-{module}-jacoco',dirs_exist_ok=True)

def tap(label,prefix):
    lines=read(ev/(label+'.log')).splitlines(); rows=[]; base=0
    for i,line in enumerate(lines):
        m=re.match(r'^(not ok|ok) (\d+) - (.+)$',line)
        if not m:continue
        name=m[3];idmatch=re.match(r'((?:UT|CB|CN)-[A-Z]{3}-\d{2}-C\d+|AC\d{2}-C\d+|ADAPT-\d+|REV-MATCH-\d+)',name)
        if idmatch:caseid=idmatch[1]
        else:base+=1;caseid=f'{prefix}-{base:02d}'
        dur=next((re.search(r'duration_ms: ([\d.]+)',s)[1] for s in lines[i+1:i+8] if re.search(r'duration_ms: ([\d.]+)',s)),None)
        rows.append({'id':caseid,'name':name,'suite':label,'result':'Ejecutado aprobado' if m[1]=='ok' else 'Ejecutado fallido','duration_ms':float(dur) if dur else None,'evidence':f'evidencias/{label}.log','evidence_line':i+1,'repository':'backend','commit':BACK})
    return rows
cases=tap('final-node20-unit','BASE-DOM')+tap('final-firestore-functional','BASE-INT')+tap('final-firestore-concurrency','BASE-LOAD')
android=[]
for module in ['domain','app']:
    for xml in sorted((ev/f'android-{module}-xml').glob('TEST*.xml')):
        suite=ET.parse(xml).getroot()
        for t in suite.findall('testcase'):
            testname=t.attrib['name'];idmatch=re.match(r'(AND_[A-Z]{3}_C\d+)',testname)
            name='ANDROID-'+t.attrib.get('classname',suite.attrib['name']).split('.')[-1]+'.'+testname
            android.append({'id':idmatch[1] if idmatch else name,'name':testname,'class':t.attrib.get('classname',suite.attrib['name']),'suite':'android-final-offline','result':'Omitido' if t.find('skipped') is not None else ('Ejecutado fallido' if t.find('failure') is not None or t.find('error') is not None else 'Ejecutado aprobado'),'duration_ms':float(t.attrib.get('time',0))*1000,'evidence':str(xml.relative_to(out)).replace('\\','/'),'evidence_line':None,'repository':'frontend','commit':FRONT})
cases+=android; assert len({(x['repository'],x['id']) for x in cases})==len(cases)
counts={label:collections.Counter(c['result'] for c in cases if c['suite']==label) for label in evidence_labels}
assert len(cases)==257,(len(cases),counts)
assert counts['final-node20-unit']['Ejecutado aprobado']==116
assert sum(counts['final-firestore-functional'].values())==51 and sum(counts['final-firestore-concurrency'].values())==1
assert counts['android-final-offline']['Ejecutado aprobado']==89

package_info=[
 {'key':'MAR','short':'Marco','person':'Marco Antonio Bocanegra Carrión','cb':'meritReward','unit':'meritReward','cn':'FirebaseGameRepository.start','hu':['HU 3.2','HU 3.3','HU 3.4'],'purpose':'Merit y entrada Ranked','unit_count':24,'cn_fields':['id','userId','mode','writingMode','challenge','now'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/integration/capitulo10.firestore.test.cjs'},
 {'key':'PED','short':'Pedro','person':'Pedro Iván Pacheco Castro','cb':'validateWriting','unit':'EvaluateGame.execute','cn':'structureEvaluation','hu':['HU 2.2','HU 2.3','HU 2.4','HU 3.12'],'purpose':'Validación, evaluación y feedback','unit_count':10,'cn_fields':['game.content','game.writingMode','game.challenge.words','game.challenge.topic','game.challenge.advanced','result.spelling','result.vocabulary','result.coherence','result.creativity','result.topicRelevant'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/test/capitulo10.test.cjs'},
 {'key':'VIC','short':'Víctor','person':'Víctor Manuel Camarena Paredes','cb':'ratingChange','unit':'ratingChange','cn':'FirebaseGameRepository.complete','hu':['HU 3.2','HU 3.5','HU 3.7','HU 3.9'],'purpose':'Cierre, matchmaking y variación de rating','unit_count':9,'cn_fields':['game.id','game.authorId','game.content','game.mode','game.seasonIndex','evaluation.score','evaluation.feedback'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/integration/capitulo10.firestore.test.cjs'},
 {'key':'JEA','short':'Jean Carlo','person':'Jean Carlo de Jesús Rado Delgado','cb':'league','unit':'league','cn':'OpenAiWritingEvaluator.evaluate','hu':['HU 2.3','HU 3.6','HU 3.8','HU 3.9'],'purpose':'Contrato de evaluación y representación de resultados','unit_count':12,'cn_fields':['game.writingMode','game.content','game.challenge.words','game.challenge.topic','game.challenge.theme','game.challenge.advanced'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/test/adapter.capitulo10.test.cjs'},
 {'key':'REN','short':'Renzo','person':'Renzo Ubaldo Adrianzén Vía','cb':'dailyWord','unit':'GetWordExample.execute','cn':'FirebaseContentRepository.hasMetadata','hu':['HU 1.5','HU 1.6'],'purpose':'Home, metadata y oración de ejemplo','unit_count':5,'cn_fields':['word.text','word.definition','word.phonetic','word.partOfSpeech','word.rarity'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/integration/capitulo10.firestore.test.cjs'},
 {'key':'MAT','short':'Matías','person':'Matías Gonzalo Villar Córdova Alva','cb':'mapUser','unit':'mapUser','cn':'mapUser','hu':['HU 1.1','HU 1.2','HU 1.3','HU 1.4','HU 1.10','HU 3.6'],'purpose':'Perfil y apoyo a sesión/progreso','unit_count':7,'cn_fields':['id','dto.name','dto.email','dto.merit','dto.rating','dto.seasonIndex','dto.username'],'unit_file':'functions/test/capitulo10.test.cjs','cn_file':'functions/test/capitulo10.test.cjs'},
]
for p in package_info:
    p.update(prepared_by='Codex a solicitud de Marco; no atribución de autoría humana',responsible_status='Propuesto; no confirmado',human_review='Pendiente',individual_reproduction='No confirmada',execution_by='Agente Codex con herramientas locales',teaching_acceptance='Pendiente para CN interna y reparto individual')
    p['graph']=next(g for g in graphs if g['person']==p['short'])
    actual=[c for c in cases if c['id'].startswith(f'UT-{p["key"]}-01-C')]
    assert len(actual)==p['unit_count'] and all(c['result']=='Ejecutado aprobado' for c in actual)

# Contratos y oráculos; la tabla de economía y rating es caracterización explícita.
oracles={
 'MAR':'AC-05/RNF-019 y HU 3.3/3.4: costo 100, rechazo sin saldo negativo. Para meritReward se caracteriza la tabla 25/60/125/200/300/400/500 más floor(palabras/10), tope 40 y factor Ranked 1.5; los criterios no fijan esos tramos y requieren ratificación humana.',
 'PED':'Informe 5.3 HU 2.3/2.4/3.12: score 0–100, timeout diferido, preservación de score base y detalle de restricciones. HU 2.2/contrato WritingMode: 50–150 STANDARD y 50–200 ON_TOPIC; 10 000 caracteres como guarda del código, caracterización técnica.',
 'VIC':'HU 3.2/AC-04: acreditación única; AC-03: delta ≤30 y sin dobles. ratingChange se caracteriza como regla propia; AC-06 sigue discrepante y no es su oráculo de aprobación.',
 'JEA':'Contrato WritingEvaluator y requisito de suministro de restricciones al evaluador. Las aserciones sobre JSON/modelo/timeout son de contrato/configuración actual; no demuestran calidad semántica de OpenAI ni latencia cloud. league caracteriza sus seis tramos.',
 'REN':'ASR E10:E13: cinco metadatos Home y oración que incluya palabra; el ejemplo sentence es otro dato y no se suma a los cinco de hasMetadata. Vacío/espacios no son metadata completa. Rechazo de contenido y proveedor controlado, no UI.',
 'MAT':'Contrato UserDto/User: campos opcionales reciben defaults documentados en ficha. Preservar ID, cero, nombre, email y username es caracterización del mapper; HU 1.1 de Google se reconcilia por S2 y ACCEPTANCE_REPORT, no por ASR E2:E3.'}

def bind(c):
    id=c['id'];name=c['name'];hu=[];tech='regresión';sym='Ver fuente del caso';role='comportamiento';criterion='Evidencia auxiliar; no acredita por sí sola el criterio completo'
    if id.startswith('UT-MAR'):hu=['HU 3.2'];tech='unitaria'+(' / caja blanca' if int(id[-2:])<=11 else '');sym='meritReward'
    elif id.startswith('CB-PED'):hu=['HU 2.2'];tech='caja blanca';sym='validateWriting'
    elif id.startswith('UT-PED'):hu=['HU 2.3'];tech='unitaria';sym='EvaluateGame.execute';hu+=['HU 3.2'] if id.endswith('09') else []
    elif id.startswith('UT-VIC'):hu=['HU 3.7','HU 3.9'];tech='unitaria'+(' / caja blanca' if int(id[-2:])<=5 else '');sym='ratingChange'
    elif id.startswith('UT-JEA'):hu=['HU 3.6'];tech='unitaria'+(' / caja blanca' if int(id[-2:])<=6 else '');sym='league';role='auxiliar'
    elif id.startswith('UT-REN'):hu=['HU 1.6'];tech='unitaria';sym='GetWordExample.execute'
    elif id.startswith('UT-MAT'):hu=['HU 1.1','HU 3.6'];tech='unitaria / caja blanca';sym='mapUser';role='auxiliar'
    elif id.startswith('CN-MAR'):hu=['HU 3.3','HU 3.4','HU 2.1'];tech='caja negra interna';sym='FirebaseGameRepository.start'
    elif id.startswith('CN-PED'):hu=['HU 2.4','HU 3.12'];tech='caja negra interna';sym='structureEvaluation'
    elif id.startswith('CN-VIC'):hu=['HU 3.2'];tech='caja negra interna';sym='FirebaseGameRepository.complete'
    elif id.startswith('CN-JEA') or id.startswith('ADAPT'):hu=['HU 2.3'];tech='caja negra interna / adaptador SDK simulado';sym='OpenAiWritingEvaluator.evaluate'
    elif id.startswith('CN-REN'):hu=['HU 1.5'];tech='caja negra interna';sym='FirebaseContentRepository.hasMetadata'
    elif id.startswith('CN-MAT'):hu=['HU 1.1','HU 3.6'];tech='caja negra interna';sym='mapUser';role='auxiliar'
    elif id.startswith('CB-REN'):hu=['HU 1.5'];tech='caja blanca / integración';sym='FirebaseContentRepository.dailyWord'
    elif id.startswith('REV-MATCH'):hu=['HU 3.5','HU 3.7'];tech='integración de regresión';sym='Matchmaker / MatchBaseline'
    elif id.startswith('AC02'):hu=['HU 2.3'];tech='integración / calidad';sym='EvaluateGame + FirebaseGameRepository.defer/recoverEvaluations'
    elif id.startswith('AC03'):hu=['HU 3.5','HU 3.7'];tech='concurrencia / calidad';sym='FirebaseMatchRepository.match / Matchmaker.pair'
    elif id.startswith('AC04'):hu=['HU 3.2'];tech='concurrencia / calidad';sym='FirebaseGameRepository.complete'
    elif id.startswith('AC05'):hu=['HU 3.3','HU 3.4'];tech='concurrencia / límites';sym='FirebaseGameRepository.start'
    elif c['repository']=='frontend':
        if m:=re.search(r'hu(\d+)_(\d+)_scenario([12])',name):hu=[f'HU {m[1]}.{m[2]}'];criterion='Éxito' if m[3]=='1' else 'Fallo'
        elif id.startswith('AND_PED'):hu=['HU 2.2'];sym='GamePolicy.validateWriting';tech='unitaria de límites'
        elif id.startswith('AND_REN'):hu=['HU 1.5'];sym='WireMap.toWord';tech='mapper'
        elif id.startswith('AND_JEA'):hu=['HU 3.8','HU 3.9'];sym='GameDto.toDomain';tech='mapper'
        elif 'FeedbackMapping' in id:hu=['HU 2.4','HU 3.12'];sym='GameDto.toDomain';tech='mapper'
        elif 'ContentViewModelTest' in id:
            hu=['HU 1.6'] if 'example' in name.lower() else (['HU 1.3','HU 1.4'] if 'Session' in name else ['HU 1.10']);tech='ViewModel con repositorios controlados'
        elif 'GameViewModelTest' in id:hu=['HU 2.1','HU 2.2','HU 3.4'];tech='ViewModel con repositorios controlados'
        elif 'GamePolicyTest' in id:hu=['HU 2.2'] if 'writing' in name.lower() else [];tech='unitaria histórica'
        if 'AcceptanceCriteriaSuiteTest' in id:
            text=read(root/'work/frontend/app/src/test/java/com/inkr8/presentation/AcceptanceCriteriaSuiteTest.kt')
            start=text.find('fun '+name+'(');end=text.find('\n    @Test',start+1);body=text[start:end if end!=-1 else None]
            role='ViewModel con dobles' if 'val vm =' in body else 'constante o constructor DTO; no funcional'
            sym='AcceptanceCriteriaSuiteTest.'+name
    else:
        # Mapas de intención para regresión existente: no agregan nuevas HU al alcance.
        patterns=[('matching policies',['HU 3.5']),('user name',['HU 1.2']),('name update',['HU 1.2']),('home use case',['HU 1.5']),('numeric leagues',['HU 3.6']),('basic rewards',['HU 3.2','HU 3.7']),('writing validation',['HU 2.2']),('evaluat',['HU 2.3']),('constraints validate',['HU 3.12','HU 2.4']),('progress',['HU 1.10']),('example lookup',['HU 1.6']),('duplicate entry',['HU 3.3','HU 3.4']),('insufficient balance',['HU 3.3','HU 3.4','HU 2.2']),('settlement awards',['HU 3.2']),('late evaluation',['HU 3.2','HU 3.7']),('matchmaking',['HU 3.5','HU 3.7']),('48 hours',['HU 3.5']),('recovery expires',['HU 3.5']),('daily word is stable',['HU 1.5','HU 2.1']),('callable contracts',['HU 1.1','HU 1.2','HU 1.5','HU 1.6','HU 2.1','HU 2.2']),('username claims',['HU 1.2']),('timeout recovery',['HU 2.3']),('match failures',['HU 3.7'])]
        for token,ids in patterns:
            if token in name:hu=ids;break
        if 'constraints validate' in name:hu=['HU 2.4','HU 3.12']
        if 'concurrent evaluation settlement' in name:hu=['HU 3.2']
        if 'progress persists' in name:hu=['HU 1.10']
    c.update(hu=[h for h in hu if h in {s['id'] for s in selected}],techniques=tech,symbol=sym,evidence_role=role,criterion_scope=criterion)
    c['package']=next((p['short'] for p in package_info if p['key'] in id and not id.startswith('BASE')), 'Regresión compartida')
    c['environment']='JVM con SDK/repositorios simulados; sin pantalla renderizada' if c['repository']=='frontend' else ('Firestore local demo-inkr8' if 'firestore' in c['suite'] else 'Node 20; dependencias controladas')
for c in cases:bind(c)
for c in cases:
    ident=c['id'];c['repository_url']='https://github.com/Rnz5/Inkr8-ISW2' if c['repository']=='backend' else 'https://github.com/Matonga-Matonag/Inkr8Android'
    c['branch_base']='Inkr8BackEnd' if c['repository']=='backend' else 'main';c['branch_local']='pruebas/capitulo-10';c['command_metadata']='evidencias/'+c['suite']+'.json'
    if c['repository']=='frontend':
        folder='domain/src/test/kotlin/com/inkr8/domain/' if '.domain.' in c.get('class','') else 'app/src/test/java/com/inkr8/presentation/'
        c['test_source']='codigo/frontend/'+folder+c.get('class','').split('.')[-1]+'.kt'
    else:
        file='functions/test/capitulo10.test.cjs'
        if ident.startswith('BASE-DOM'):file='functions/test/domain.test.cjs'
        elif ident.startswith('BASE-INT'):file='functions/integration/firestore.test.cjs'
        elif ident.startswith(('CN-MAR','CN-VIC','CN-REN','CB-REN','AC')):file='functions/integration/capitulo10.firestore.test.cjs'
        elif ident.startswith(('CN-JEA','ADAPT')):file='functions/test/adapter.capitulo10.test.cjs'
        if ident.startswith('AC03'):file='functions/integration/capitulo10.concurrency.test.cjs'
        elif ident.startswith('REV-MATCH'):file='functions/integration/revision.regression.test.cjs'
        c['test_source']='codigo/backend/'+file
    c['inputs']='Fixture identificado por '+c['name']+' en '+c['test_source']
    c['operation']=c['symbol'];c['expected']='Aserciones literales e interacciones del caso en '+c['test_source']+'; el resultado del runner no se usa como oráculo'
    if ident.startswith('UT-MAR'):
        c['inputs']='rewardCases['+str(int(ident[-2:])-1)+'] = '+c['name'].split('meritReward(')[1].split(')')[0]
        c['expected']=c['name'].split(' -> ')[1].split(' / ')[0]
    elif ident.startswith(('UT-VIC','UT-JEA')):c['expected']=c['name'].split(' -> ')[1].split(' / ')[0]
    elif ident.startswith('CB-PED'):c['inputs']='writingCases['+str(int(ident[-2:])-1)+']; '+c['name'];c['expected']='Acepta casos C01,C02,C07,C08,C11; rechaza con invalid-argument C03,C04,C05,C06,C09,C10,C12'
    elif ident.startswith('UT-PED'):
        configs={1:'PENDING/PRACTICE, score 74',2:'PENDING/RANKED, score 74',3:'EVALUATED',4:'EvaluationTimeout controlado',5:'score NaN',6:'score -1',7:'score 101',8:'excepción status 429',9:'complete lanza DB offline',10:'excepción status 503'}
        expectations={1:'get,evaluate,complete; sin match/fail/defer',2:'get,evaluate,complete,match; en ese orden',3:'solo get; no evalúa ni premia',4:'get,evaluate,defer; no complete/match',5:'failed-precondition; get,evaluate,fail',6:'failed-precondition; get,evaluate,fail',7:'failed-precondition; get,evaluate,fail',8:'repropaga error; get,evaluate,fail; sin defer (brecha AC-02)',9:'repropaga error; get,evaluate,complete,fail,fail (diagnóstico)',10:'repropaga error; get,evaluate,fail; sin defer (brecha AC-02)'}
        n=int(ident[-2:]);c['inputs']='evaluationHarness: '+configs[n]+'; fixture g, STANDARD, 50 palabras ink, clock=0';c['expected']=expectations[n]
    elif ident.startswith('UT-REN'):
        n=int(ident[-2:]);c['inputs']=('exampleCases['+str(n-1)+']; '+c['name']) if n<5 else 'Proveedor dailyWord lanza Error(content unavailable); clock=0'
        c['expected']={1:'{sentence:A bottle of ink.}, pide day 0',2:'{sentence:El ÁRBOL crece.}, pide day 0',3:'failed-precondition; ink no coincide con Think',4:'failed-precondition; oración en blanco',5:'Propaga el mismo error del proveedor'}[n]
    elif ident.startswith('UT-MAT'):
        n=int(ident[-2:]);keys=['name','email','merit','rating','seasonIndex','username'];c['inputs']='id=u, fullUser={name:Marco,email:m@example.test,merit:1000,rating:60,seasonIndex:0,username:marco}'+('' if n==1 else '; eliminar '+keys[n-2]);c['expected']='Conservar objeto completo' if n==1 else 'Default solo del campo eliminado: Writer/null/0/0/MIN_SAFE_INTEGER/null; los demás se conservan'
    c['observed']=c['result']+'; ver aserciones y localizador de evidencia'
    source_root=root/'work'/c['repository']; test_relative=c['test_source'].split('codigo/'+c['repository']+'/',1)[1]
    test_text=read(source_root/test_relative).splitlines()
    token=c['name'] if ident.startswith('BASE-') else (c['name'] if c['repository']=='frontend' else ident.rsplit('-C',1)[0])
    c['test_source_line']=next((i+1 for i,line in enumerate(test_text) if token in line),None)
js('Casos_ejecutados.json',cases);csvout('Casos_ejecutados.csv',cases)
write('Casos_Detallados.md','# Casos y oráculos reproducibles\n\nLas fichas procesables contienen datos o fixture identificable, operación, esperado, resultado, duración del runner, fuente del test, comando, commit y evidencia. Los casos unitarios principales siguientes tienen datos y esperados acotados; los arrays/fixtures completos y sus aserciones están en los fuentes incluidos. No se simula una observación del usuario por tener un test de constructor o constante.\n\n'+table(['Caso','Entradas / fixture','Operación','Esperado independiente / caracterización','Observado','Duración ms','Evidencia'],[[c['id'],c['inputs'],c['operation'],c['expected'],c['result'],c['duration_ms'],c['evidence']+(f':{c["evidence_line"]}' if c['evidence_line'] else '')] for c in cases if c['id'].startswith('UT-')]))

# Cobertura por archivo, sin sumar porcentajes de suites o incluir tests como producto.
coverage=[]
for label in ['final-node20-unit','final-firestore-functional','final-firestore-concurrency']:
    for line in read(ev/(label+'.log')).splitlines():
        m=re.match(r'^#\s+(src[^|]+)\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|(.*)$',line)
        if m:coverage.append({'report':label,'scope':m[1].strip().replace('\\','/'),'line_pct':float(m[2]),'branch_pct':float(m[3]),'function_pct':float(m[4]),'uncovered_lines':m[5].strip(),'tool':'Node 20.19.0 native experimental coverage, V8 y sourcemaps','commit':BACK})
android_coverage=[]
for module,filename in [('domain','jacocoTestReport.xml'),('app','jacocoDebugUnitTestReport.xml')]:
    x=ET.parse(ev/f'android-{module}-jacoco'/filename).getroot()
    def counters(node):return {c.attrib['type']:{'covered':int(c.attrib['covered']),'missed':int(c.attrib['missed']),'pct':round(int(c.attrib['covered'])*100/(int(c.attrib['covered'])+int(c.attrib['missed'])),2) if int(c.attrib['covered'])+int(c.attrib['missed']) else None} for c in node.findall('counter')}
    android_coverage.append({'module':module,'scope':'todo el bytecode de clases de producción incluido en reporte','counters':counters(x),'tool':'JaCoCo 0.8.14; Gradle 9.1.0; JDK 21.0.9','commit':FRONT})
    for cls in x.findall('.//class'):
        if cls.attrib['name'].endswith(('GamePolicy','DomainMappersKt','HomeViewModel','SessionViewModel','GameViewModel')):
            android_coverage.append({'module':module,'scope':cls.attrib['name'],'counters':counters(cls),'tool':'JaCoCo 0.8.14','commit':FRONT})
js('evidencias/Cobertura_archivos.json',coverage);csvout('evidencias/Cobertura_archivos.csv',coverage);js('evidencias/Cobertura_Android.json',android_coverage)
covmd='# Cobertura medida\n\nSe presentan archivos/módulos como denominadores disponibles. No se suman porcentajes ni se equiparan cobertura de ramas, caminos y criterios. Los totales `all files` del runner incluyen tests y no se usan como cobertura de producto.\n\n## Backend\n\n'
covmd+='La instrumentación ejecuta JS en `functions/lib`. El runner Node 20 usa sus mapas y muestra rutas TypeScript; `verificacion_mapeo_cobertura.json` contrasta entradas V8, mapa, línea original y hash de la fuente (por ejemplo meritReward JS 23 → TS 15). Las líneas de interfaces/imports aparecen como no cubiertas: se conservan esas cifras del runner sin corregirlas manualmente. No se afirma un porcentaje por método cuando el reporte solo lo da por archivo.\n\n'
covmd+=table(['Reporte','Archivo TS reportado','Líneas %','Ramas %','Funciones %','Líneas sin cubrir'],[[r['report'],r['scope'],r['line_pct'],r['branch_pct'],r['function_pct'],r['uncovered_lines']] for r in coverage])
covmd+='\n## Android\n\nEl XML incluye clases y código generado del compilador de cada módulo. No se excluyeron pantallas sin pruebas para elevar la cifra. JaCoCo mide métodos de bytecode, que no equivalen directamente a funciones TypeScript. El reporte de app incluye el bytecode debug Kotlin y Java verificado en `intermediates`; excluye clases de tests porque se apuntó solo al directorio debug. No se midieron Compose UI ni instrumentadas.\n\n'
covmd+=table(['Módulo/alcance','Líneas cubiertas/total (%)','Ramas cubiertas/total (%)','Métodos cubiertos/total (%)'],[[r['module']+' / '+r['scope']]+[f'{r["counters"].get(k,{}).get("covered","n.a.")}/{r["counters"].get(k,{}).get("covered",0)+r["counters"].get(k,{}).get("missed",0)} ({r["counters"].get(k,{}).get("pct","n.a.")}%)' for k in ['LINE','BRANCH','METHOD']] for r in android_coverage])
covmd+='\nHTML completos: [dominio](android-domain-jacoco/html/index.html), [app](android-app-jacoco/html/index.html). XML originales en esas carpetas. Comandos y tiempos del runner: [Android final](android-final-offline.json), [Node unidad](final-node20-unit.json), [Node Firestore](final-node20-firestore.json). Las ramas descubiertas permanecen en el reporte; no se prometió ni se exige aquí 100% universal.\n'
write('evidencias/Cobertura.md',covmd)

# Resumen acotado por criterio de las 19 HU. Ninguna marca supone certificación de UI/cloud.
scopes={
'HU 1.1':('Inicialización backend 1000 Merit y estados de sign-in en SessionViewModel con FakeAuthRepo.','Fallo inducido en signIn produce GOOGLE_SIGNIN_FAILED y signedIn=false.','OAuth Google real, navegación y perfil sin duplicación tras recrear proceso; conciliación pendiente de requisitos.'),
'HU 1.2':('Persistencia, username permanente y normalización NFKC de colisión en emulador.','Dos claims concurrentes: solo uno prospera; el otro recibe Username … is already in use.','Mostrar resultado/mensaje en pantalla y validación humana del criterio.'),
'HU 1.3':('SessionViewModel recibe UID previamente activo y carga perfil.','UID null deja signedIn=false y usuario ausente.','Restauración tras muerte de proceso, almacenamiento real de auth y navegación Login/Home.'),
'HU 1.4':('signOut controlado emite UID null; el estado limpia usuario.','Error de logout conserva sesión e informa LOGOUT_FAILED; reintento probado.','Cierre efectivo Firebase Auth y pantalla Login.'),
'HU 1.5':('dailyWord y metadatos en Firestore; HomeViewModel recibe campos.','Contenido incompleto/ausente rechazado; ViewModel expone mensaje de fallo controlado.','Pantalla Home, audio, botones y recuperación real de red.'),
'HU 1.6':('GetWordExample valida palabra completa Unicode; ViewModel pide el día visible.','Proveedor controlado falla y ViewModel muestra error; reintento funciona.','Click y texto renderizados en dispositivo con proveedor real.'),
'HU 1.10':('Historial/estadísticas persisten al reinicializar usuario en emulador; SessionViewModel restaura perfil.','Inicialización controlada fallida produce PROGRESS_RETRIEVE_FAILED.','Logout/login real y recuperación de historial desde cliente recreado.'),
'HU 2.1':('Backend conserva challenge STANDARD; ViewModel observa cuatro palabras tras corregir fixture.','Fallo start controlado produce INTERNET_ACTION_FAILED.','Cuatro restricciones visibles y botón de reintento sin conexión real.'),
'HU 2.3':('Score 0–100 validado, contrato del SDK y complete con evaluador determinista.','Timeout de excepción controlada persiste FAILED+nextRetryAt; recuperación a 5 min; cuota 429/503 no difiere.','OpenAI real y ≥90% de evaluaciones completas ≤5s; timeout real por reloj del SDK y UI; corrección AC-02 cuota/disponibilidad.'),
'HU 2.4':('structureEvaluation preserva detalle, score y restricciones; mapper real del cliente se ejecuta.','Feedback incompleto conserva score base y devuelve aviso requerido.','Pantalla de resultados y navegación real.'),
'HU 3.2':('Saldo antes/después y una sola recompensa por ID, incluso 10 cierres concurrentes y dos repetidos.','Fallo de complete controlado no acredita premio; registra dos llamadas fail como diagnóstico.','Monto y mensaje Unable to connect to the server en UI; confirmar tabla de economía como regla de negocio.'),
'HU 3.3':('Entrada 100 y saldo final con 100/101; competencia por los mismos 100.','99 rechaza sin partida ni saldo negativo; integración concilia mensaje de capa backend.','Mensaje de HU 3.3 difiere del de HU 3.4; revisar contrato de UX sin sustituir los criterios.'),
'HU 3.4':('Inicio Ranked con débito real y estado GameViewModel con fake controlado.','Insufficient Merit detiene inicio y se traduce al aviso Ranked en ViewModel.','Acceso/pantalla real y saldo visible.'),
'HU 3.5':('Pareja pequeña concurrente comprobada; perfil de 50 solicitudes solo resuelve una parte.','Ensayos previos: 48h−1 mantiene PENDING y a 48h resuelve con promedio 80. La última suite completa falló con Transaction is invalid or closed; ver diagnóstico aislado.','AC-03 a escala y estabilidad de recuperación 48h no cerrados; estudiar errores transaccionales y repetir tras diagnóstico/corrección acordados.'),
'HU 3.6':('mapUser preserva rating y league caracteriza seis tramos; otros tests solo construyen User.','La suite existente comprueba la constante Server failure, sin inducir error del perfil.','Recuperación real del rating, fallo inducido en lectura y pantalla del perfil. Este criterio negativo solo tiene evidencia de constante.'),
'HU 3.7':('Rating de pareja pequeña y regla propia caracterizada; pareo evita temporada cruzada.','Fallo de matching persiste matchError y recuperación exitosa lo limpia.','Decidir ELO oficial frente a regla propia y verificar mensaje en UI; escala AC-03 parcial.'),
'HU 3.8':('GameDto.toDomain interpreta WIN/LOSS/DRAW y descarta estructura de match inválida.','La suite histórica solo compara constante de mensaje; no induce fallo de recuperación de resultado.','Pantalla Victoria/Derrota/Empate y fallo de carga real/controlado a través del ViewModel.'),
'HU 3.9':('Mapper conserva +4, −6 y null; ratingChange se caracteriza, sin validar ELO.','La suite histórica solo compara constante Server failure.','Variación visible, fallo de cálculo/obtención atravesando la operación real y regla acordada.'),
'HU 3.12':('Restricciones de primera persona/pregunta/palabras y resultado tópico controlado se estructuran.','topicRelevant ausente o regla desconocida devuelve Compliance with restrictions could not be verified.','Semántica de relevancia con OpenAI real y mensaje renderizado en cliente.'),
'HU 2.2':('Límites 50/150/200 y validación antes de enviar en backend y cliente.','49/151/201 y 10 001 caracteres rechazan, con 50 palabras controladas en el caso de caracteres.','Botón Submit y aviso en pantalla; incorporación adicional justificada por CB de Pedro.')}

trace=[]; criterion_rows=[]
for h in selected:
    hid=h['id'];related=[c for c in cases if hid in c['hu']]
    for c in related:
        design=next(('caja_blanca/'+g['id']+'.md' for g in graphs if g['symbol'] in c['symbol']), 'Matriz_Pruebas_y_Trazabilidad.md')
        criteria_text=h.get('report_5_3',{}).get('criteria') or ('Propuesta S2/ACCEPTANCE_REPORT: registro Google correcto inicializa/recupera perfil; autenticación fallida impide acceso y muestra error; pendiente validación' if hid=='HU 1.1' else h['asr']['success']+'\n'+h['asr']['failure'])
        trace.append({'HU':hid,'titulo':h['title'],'criterio_y_fuente':('Informe tabla 5.3' if h.get('in_5_3') else ('Propuesta desde S2/ACCEPTANCE_REPORT, ASR rechazado' if hid=='HU 1.1' else 'ASR Historias de Usuario!'+h['asr']['criteria_cells'])),'criterio_texto_fuente':criteria_text,'criterio_alcance_del_caso':c['criterion_scope'],'diseño':design,'simbolo':c['symbol'],'commit':c['commit'],'paquete':c['package'],'tecnica':c['techniques'],'caso':c['id'],'datos':c['inputs'],'esperado':c['expected'],'fuente_test':c['test_source']+(f':{c["test_source_line"]}' if c['test_source_line'] else ''),'entorno':c['environment'],'resultado':c['result'],'evidencia':c['evidence']+(f':{c["evidence_line"]}' if c['evidence_line'] else ''),'limite':scopes[hid][2],'rol_evidencia':c['evidence_role']})
    criterion_rows.append({'HU':hid,'titulo':h['title'],'prioridad':h['in_priority_union'],'apunta_10_previo':hid in ['HU 2.3','HU 2.4','HU 3.2','HU 3.3','HU 3.7','HU 3.12'],'exito_comprobado_acotado':scopes[hid][0],'fallo_comprobado_o_carencia':scopes[hid][1],'pendiente_para_cierre':scopes[hid][2],'criterio_completo_usuario':'No cerrado','casos_relacionados':[c['id'] for c in related]})
js('Matriz_Pruebas_y_Trazabilidad.json',trace);csvout('Matriz_Pruebas_y_Trazabilidad.csv',trace);js('Criterios_y_limites.json',criterion_rows)
matrix='# Matriz de pruebas y trazabilidad\n\nHay 19 HU prioritarias y una adicional justificada, HU 2.2, por validateWriting. Las relaciones son muchos a muchos; las filas de CSV/JSON no son ejecuciones adicionales. Se conservan por separado los '+str(len(cases))+' casos distintos de las tres suites finales.\n\n'
matrix+='No se cierra ninguna de las 19 HU de extremo a extremo. Todas tienen evidencia relacionada, pero HU 3.6, 3.8 y 3.9 conservan negativos que solo comparan constantes. Las seis HU que ya apuntaban al 10 tienen evidencia acotada, y ninguna está íntegramente acreditada con UI/servicio real. La resolución de 48h de HU 3.5 aprobó en baseline y diagnóstico aislado, pero falló en la última suite completa: TRANS-01 sigue abierto.\n\n'
matrix+=table(['HU','Criterio positivo comprobado en alcance acotado','Criterio negativo y límite','Falta para cerrar'],[[r['HU']+' '+r['titulo'],r['exito_comprobado_acotado'],r['fallo_comprobado_o_carencia'],r['pendiente_para_cierre']] for r in criterion_rows])
matrix+='\nLa versión procesable añade símbolo, commit, paquete/técnica, caso, entorno, fuente, resultado, log/línea y límite. [CSV](Matriz_Pruebas_y_Trazabilidad.csv), [JSON](Matriz_Pruebas_y_Trazabilidad.json), [casos distintos](Casos_ejecutados.json). Las duraciones proceden de TAP o JUnit XML y no son latencia productiva.\n'
write('Matriz_Pruebas_y_Trazabilidad.md',matrix)

# Fichas de CN: dominios y observación de cada campo, sin inflar con estado ni salidas.
cn_details={
'MAR': [('id','string lógico','nuevo / repetido','propietario incompatible: rechazo','No frontera numérica; la identidad pública se valida en submissionIdentity','submissions/{id} y retorno Game.id'),('userId','usuario existente y abierto','existente','inexistente/cerrado','No aplica','autor y cuenta debitada'),('mode','PRACTICE / RANKED','dos enums','otros valores fuera del contrato TypeScript de este repositorio','No aplica','entryCost 0/100 y mode'),('writingMode','STANDARD / ON_TOPIC','dos enums','otros valores fuera del contrato tipado','No aplica','writingMode persistido'),('challenge','Challenge recibido','palabras y topic de fixture','validación de contenido se hace antes; no se exige nueva validación al repositorio','colección cuenta como un campo','challenge persistido'),('now','timestamp recibido','anchor / anchor+1 / anchor+2','tipos no numéricos fuera del contrato','sin límite de aceptación definido','Game.timestamp')],
'PED':[('game.content','string','49/50/151 palabras; presencia/ausencia de términos','incumplimiento es resultado false, no excepción de entrada','49/50; 150/151; semántica de texto','constraints.fulfilled'),('game.writingMode','enum','STANDARD / ON_TOPIC','otros fuera del contrato','No aplica','máximo 150/200 y etiqueta'),('game.challenge.words','Word[]','requerida presente / ausente','no se exige esquema nuevo a este método tipado','cardinalidad; no contar cada elemento como campo','reglas Use …'),('game.challenge.topic','string/null','topic / null','no relevancia o booleano faltante','No aplica','regla Topic o constraintsError'),('game.challenge.advanced','string[]','FIRST_PERSON / QUESTION / []','UNKNOWN produce error de verificación','No frontera numérica de enums','primera persona y pregunta'),('result.spelling/vocabulary/coherence/creativity','cuatro strings separados','detalle no vacío','ausente/blanco','vacío vs no vacío; no límite máximo acordado','feedbackError'),('result.topicRelevant','boolean opcional','true / false','ausente no verificable','No aplica','resultado de topic / error')],
'VIC':[('game.id','string','g / other','no se añade validador de ID aquí','No aplica','documento final'),('game.authorId','string','alice / bob','perfil ausente/cerrado tratado en implementación','No aplica','usuario acreditado'),('game.content','string','50 / 60 palabras','invalidación de envío pertenece a submit','count/10 y tope son caracterización','meritEarned'),('game.mode','enum','RANKED / PRACTICE','otros fuera del contrato','No aplica','multiplicador y matchStatus'),('game.seasonIndex','number','actual 0 / anterior −1','temporada anterior es válida, expirada para rating','igual / distinto de actual','PENDING / EXPIRED'),('evaluation.score','number','60 / 95, más límites unitarios','NaN/<0/>100 rechazados por regla','0/100 y tramos caracterizados','recompensa'),('evaluation.feedback','string','Feedback específico / Otro feedback','no prometer validador de string adicional','No umbral definido','feedback preservado')],
'JEA':[('game.writingMode','enum','STANDARD / ON_TOPIC','fuera del contrato tipado','No aplica','JSON writingMode y maxWords'),('game.content','string','Texto controlado / Otro texto','texto semánticamente inválido requiere IA real','longitud se verifica antes, no aquí','submission'),('game.challenge.words','Word[]','dos términos / uno distinto','fuera de esquema no se exige validación nueva','un campo, no dos por elementos','requiredWords'),('game.challenge.topic','string/null','Nature / null','No aplica como invalidez; null es válido','No aplica','topic en request'),('game.challenge.theme','string/null','Life / Technology','No frontera de aceptación definida','No aplica','theme en request'),('game.challenge.advanced','string[]','dos reglas / []','no son controles de UI ni predicados propios','No aplica numérica','advanced en request')],
'REN':[('word.'+k,'string requerido','texto no vacío','vacío / espacios, tipo inválido fuera de Word','vacío/no vacío; sin umbral máximo acordado','boolean hasMetadata y rechazo dailyWord de información incompleta') for k in ['text','definition','phonetic','partOfSpeech','rarity']],
'MAT':[('id','string','u / other','sin validador prometido','No aplica','User.id'),('dto.name','string opcional','Marco','ausente/vacío usa Writer','vacío/no vacío','User.name'),('dto.email','string opcional','m@example.test / vacío','ausente/null usa null','No validación de email prometida','User.email'),('dto.merit','number opcional','1000 / 0','ausente/null usa 0','no validación económica prometida en mapper','User.merit'),('dto.rating','number opcional','60 / 0','ausente/null usa 0','no umbral propio del mapper','User.rating'),('dto.seasonIndex','number opcional','0','ausente usa MIN_SAFE_INTEGER','sentinela, no rango de negocio','User.seasonIndex'),('dto.username','string opcional','marco / vacío','ausente/null usa null','no longitud validada aquí','User.username')]
}
for p in package_info:
    g=p['graph'];key=p['key'];ids=[c['id'] for c in cases if c['id'].startswith(('UT-'+key,'CN-'+key,'CB-'+key))]
    text=f'# Paquete de {p["short"]}\n\n**Responsable propuesto:** {p["person"]}. No confirmado. Preparado por Codex a solicitud de Marco. Revisión humana y reproducción individual: pendientes. Ejecutado automáticamente por el agente; no se atribuye escritura ni ejecución a este integrante.\n\n'
    text+=f'Funcionalidad: {p["purpose"]}. HU: '+', '.join(p['hu'])+'.\n\n'
    text+=f'Base backend `{BACK}`; apoyo Android `{FRONT}`. Rama local de ambas copias `pruebas/capitulo-10`. El parche no está publicado.\n\n'
    text+=f'## Viabilidad de las tres técnicas\n\n'+table(['Técnica','Frontera / método','Condición','Estado técnico','Pendiente'],[['CB',p['cb'],f'V(G)={g["V"]}; {g["V"]} caminos independientes','Caminos ejecutados aprobados','Revisión humana del CFG'],['CN',p['cn'],str(len(p['cn_fields']))+' campos reales recibidos','Casos ejecutados aprobados; contrato interno','Aceptación docente de frontera interna y reparto'],['Unitaria',p['unit'],str(p['unit_count'])+' casos distinguibles de ese método','Ejecutados aprobados','Reproducción y aporte individual']])
    text+='\n## Oráculo y criterio\n\n'+oracles[key]+'\n\nRúbrica original `Rubrica!D18`: CB complejidad >4, CN más de cuatro campos, un método unitario con al menos cuatro casos y participación de todos. El PASS técnico no confirma esta participación.\n\n'
    text+=f'## Caja blanca\n\n[Fuente numerada, CFG, N/E, fórmulas y base](../caja_blanca/{g["id"]}.md). Alcance: {g["scope"]} La prueba CB se reutiliza con unitarias cuando comparte entradas; no se duplica el conteo.\n\n'
    text+='## Caja negra\n\nFrontera interna probada: `'+p['cn']+'`. Firma y uso se revisaron en el commit fijado. '+('El parámetro season es sobrescrito por el reloj en start/complete y se excluye del conteo. El saldo leído es precondición, no entrada del callable. ' if key in ['MAR','VIC'] else '')+'Los cinco o más campos no representan cinco controles de pantalla.\n\n'
    text+=table(['Campo','Tipo/dominio','Clases válidas','Inválida o fuera de contrato','Límites','Efecto observable'],cn_details[key])
    text+='\nLas particiones que quedan fuera del contrato tipado se describen sin inventar una obligación de validación. Los casos concretos están en los fixtures y aserciones de `codigo/backend/'+p['cn_file']+'`. CN de Renzo observa directamente el helper privado TypeScript compilado: su aceptación como funcionalidad docente es especialmente pendiente. Jean observa request/respuesta de SDK simulado; no evaluación semántica real.\n\n'
    text+='## Casos, resultados y reproducción\n\n'+table(['Caso','Objetivo / datos del nombre del runner','Resultado','Duración ms (runner)','Log'],[[c['id'],c['name'],c['result'],c['duration_ms'],f'[{c["evidence"]}](../{c["evidence"]})'+(f' línea {c["evidence_line"]}' if c['evidence_line'] else '')] for c in cases if c['id'] in ids])
    text+='\nLos arrays de datos de los tests mantienen cada fila identificada por el runner. Los esperados son valores literales y aserciones de errores/efectos; no se obtienen llamando al método bajo prueba. Para economía/rating, esos literales caracterizan el comportamiento actual y no sustituyen una regla de negocio aprobada.\n\n'
    text+='Desde raíz backend, con Node 20: `npm --prefix functions ci`, `npm --prefix functions test`. Para toda integración: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration"`. La integración global conserva el fallo de AC-03; reproducir la ficha por separado con `node --test --test-name-pattern=UT-'+key+' functions/test/capitulo10.test.cjs` tras compilar. Para CN/CB de emulador, ejecutar el mismo patrón dentro de emulators:exec y seleccionar `functions/integration/capitulo10.firestore.test.cjs`.\n\n'
    text+='[Cobertura por archivo/módulo](../evidencias/Cobertura.md). La cobertura medida no garantiza UI, atomicidad si se usó un doble, ni independencia de caminos por sí sola.\n\n## Validación individual por completar\n\nRevisor y fecha: pendiente. Comando reproducido y resultado contrastado: pendiente. Aporte/cambio concreto del integrante: pendiente. Consultar al docente si acepta esta frontera interna de CN y la rotación propuesta. No se afirma que ejecutar un comando por sí solo satisfaga la participación exigida.\n'
    write('paquetes/Paquete_'+key+'.md',text)
js('paquetes/Seis_fichas.json',package_info)
viability=[]
for p in package_info:
    for kind,method,rule,brecha in [('CB',p['cb'],f'V={p["graph"]["V"]}', 'Sin brecha técnica del grafo; revisar humanamente'),('CN',p['cn'],f'{len(p["cn_fields"])} campos reales','Pendiente aceptación docente de contrato interno'),('UT',p['unit'],f'{p["unit_count"]} casos','Sin brecha técnica de mínimo; participación individual pendiente')]:
        viability.append({'paquete':p['short'],'tecnica':kind,'metodo_frontera':method,'HU':p['hu'],'oraculo':oracles[p['key']],'criterio_rubrica':'Rubrica!D18: '+rule,'existente':'dominio e integración revisados; casos nuevos de capitulo10 completan brechas; se conservan baseline y dos correcciones de fixtures/expectativas','brecha':brecha,'simbolo_commit':BACK,'fuente_ficha':'paquetes/Paquete_'+p['key']+'.md'})
csvout('Matriz_Viabilidad.csv',viability);js('Matriz_Viabilidad.json',viability)

# Filas completas, conservando encabezados y contenido original de las nueve.
f='# Filas propuestas para 5.3 y 5.6\n\nBorrador para revisión/inserción; el informe compartido no fue editado. Se conservan las nueve historias y sus criterios. Las diez ausentes S2/S5 se añaden desde ASR contrastado; HU 2.2 es una incorporación adicional justificada por validar escritura en CB-PED-01 y sus límites en Android. Los estados declarados en las fuentes no se convierten en conformidad ejecutada.\n\n## Tabla 5.3\n\n'
rows=[]
for h in selected:
    hid=h['id'];criteria=h.get('report_5_3',{}).get('criteria')
    if hid=='HU 1.1':criteria='PROPUESTA DE RECONCILIACIÓN: '+('Dado que continúo con Google y autentico correctamente, cuando se inicializa/recupera mi perfil, entonces ingreso a Home con 1000 Merit iniciales sin reinicializar cuentas existentes. Dado que falla la autenticación, cuando intento ingresar, entonces se impide el acceso y se muestra Google sign-in failed. Please try again. Fuente: informe S2 y ACCEPTANCE_REPORT.md del backend. ASR E2:E3 se rechaza por copia de oración de ejemplo. Pendiente validación de requisitos.')
    elif not criteria:criteria=h['asr']['success'].strip()+'\n\n'+h['asr']['failure'].strip()
    source='Informe vigente, tabla 5.3 (conservado)' if h.get('in_5_3') else ('Propuesta S2 + ACCEPTANCE_REPORT' if hid=='HU 1.1' else 'ASR Historias de Usuario!'+h['asr']['criteria_cells']+'; fuente complementaria')
    rows.append([hid,h.get('report_5_3',{}).get('story',h['asr']['story']),criteria,h['release'],'Conservar estado declarado por separado. Verificación parcial; '+source+'. '+scopes[hid][2]])
f+=table(['ID','Historia de usuario','Criterios de aceptación','Release','Estado / observación'],rows)
f+='\n## Tabla 5.6\n\nLos nueve registros siguientes mantienen el elemento y evidencia comprometidos; se agregan pruebas y límites a su propuesta. En HU 3.5 se añade Cap. 10 porque la espera/vencimiento de 48h se ejecutó. Cap. 9 se conserva donde ya estaba; se propone también para las nuevas HU con evidencia visual pendiente.\n\n'
headers=['Requisito / HU','Release','Sprint','Elemento de diseño / implementación','Resultado / estado','Evidencia','Ubicación']; rows=[]; five_six=[]
for h in selected:
    hid=h['id'];old=h.get('report_5_6');ids=[c['id'] for c in cases if hid in c['hu']]
    tests=', '.join(ids[:10])+(' … (relación completa en matriz)' if len(ids)>10 else '')
    if old:
        row=dict(old);row['Resultado / estado']='Estado original: '+old['Resultado / estado']+'. Verificación actual parcial; '+scopes[hid][2]
        row['Evidencia']=old['Evidencia']+' | Evidencia ejecutada: '+tests+'; registros en Matriz_Pruebas_y_Trazabilidad.csv. Capturas UI pendientes.'
        if hid=='HU 3.5':row['Ubicación']=old['Ubicación']+' / Cap. 10 (espera 48h ejecutada; AC-03 parcial)'
    else:
        sprint='S2' if hid.startswith('HU 1.') else ('S5' if hid.startswith('HU 3.') else 'S1 (propuesto, contrastar)')
        row=dict(zip(headers,[hid,h['release'],sprint,' / '.join(sorted({c['symbol'] for c in cases if hid in c['hu']})) or 'Cliente, validar acceso/pantalla','Propuesta; evidencia parcial. '+scopes[hid][2],'Tests: '+tests+'. Capturas/procedimiento UI pendientes. Fuente: '+('reconciliación S2/ACCEPTANCE_REPORT' if hid=='HU 1.1' else 'ASR '+h['asr']['criteria_cells']),'Cap. 9 / Cap. 10 (propuesto)']))
    five_six.append(row);rows.append([row.get(k,'') for k in headers])
f+=table(headers,rows);f+='\nSe preservan las seis referencias originales a Cap. 10 (2.3, 2.4, 3.2, 3.3, 3.7, 3.12). En las nueve filas originales no se borra ninguna referencia a Cap. 9. La evidencia es muchos a muchos: no contar la misma ejecución más de una vez al usarla para varias HU.\n'
write('Filas_5_3_y_5_6.md',f);js('Filas_5_6.json',five_six)

# Defectos con naturaleza y causa explícitas.
defects=[
 {'id':'TEST-01','nature':'Defecto de expectativa de test','requirement':'HU 3.3/3.4, contrato de error de capa','evidence':'baseline-firestore.log, test 2; final-node20-firestore.log','reproduction':'npm --prefix functions run test:integration con emulador local en base sin patch','expected':'Código failed-precondition y mensaje inglés del contrato Ranked','observed':'La expectativa /insuficiente/ falla ante Insufficient Merit','severity':'Media: impide baseline verde sin ser por sí solo defecto de negocio','cause':'Confirmada: regex en español obsoleta en integración','state':'Corregido solo en test local, sin publicar','action':'Revisar patch; conserva código y texto exactos, no debilita la aserción'},
 {'id':'TEST-02','nature':'Defecto de fixture Android','requirement':'HU 2.1 y suite histórica de modo On-Topic','evidence':'android-app-baseline-xml/TEST-com.inkr8.presentation.AcceptanceCriteriaSuiteTest.xml; android-final-offline.log','reproduction':'gradlew.bat :domain:test :app:testDebugUnitTest --offline --no-daemon --max-workers=2 en base','expected':'Observar la misma partida devuelta por start, con cuatro palabras o modo ON_TOPIC','observed':'FakeGameRepo.observe sustituye por Game STANDARD y palabras vacías; 2 tests fallidos de 70','severity':'Media: evidencia de cliente inválida; no prueba defecto de producto','cause':'Confirmada en fixture: observe emite objeto fijo','state':'Corregido fixture local; 78/78 tests app posteriores','action':'Revisar mapa de partidas del doble y resultado de ambas aserciones'},
 {'id':'CODE-01','nature':'Brecha de recuperación reproducida','requirement':'AC-02/RNF-014; HU 2.3','evidence':'AC02_cuota.json; AC02-C02; UT-PED-01-C08/C10; ADAPT-03/05','reproduction':'Evaluador controlado lanza status 429; ejecutar EvaluateGame, avanzar 5 min y recoverEvaluations','expected':'Según AC-02, envío persistido para reintento ante cuota/disponibilidad','observed':'FAILED con nextRetryAt null; recoverEvaluations no lo devuelve a PENDING. 503 sigue rama genérica en unidad','severity':'Alta: trabajo puede requerir reintento manual y no recuperación prometida','cause':'Confirmada: solo EvaluationTimeout usa defer; catch genérico usa fail','state':'Abierto; tests de caracterización aprueban el comportamiento defectuoso, no AC-02','action':'Acordar clasificación de errores recuperables, política de reintento y aviso; luego corregir producto y añadir aserción de conformidad'},
 {'id':'LOAD-01','nature':'Resultado parcial de concurrencia en emulador','requirement':'AC-03/RNF-021, HU 3.5/3.7','evidence':'AC03_50_solicitudes.json; ac03-aislado.log; final-node20-firestore.log','reproduction':'Perfil AC03-C01: 50 usuarios, rating 100, una partida evaluada única por usuario, cola compartida y 50 llamadas solapadas','expected':'Cero dobles/inconsistentes y delta ≤30 para perfil 50. El test añade objetivo conservador de completar y resolver las 50 sin errores','observed':f'Último ensayo aislado: {quality["completed"]}/50 llamadas completadas, {quality.get("matched",0)} partidas MATCHED, {quality.get("verifiedPairs",0)} parejas recíprocas, {len(quality.get("violations",[]))} violaciones observadas en resueltas; resto PENDING/ABORTED','severity':'Alta para el perfil ensayado; no extrapolable a cloud','cause':'Confirmado el error Transaction lock timeout; hipótesis de contención por selección concurrente sobre la misma cola. No se ha aislado una causa raíz de producción','state':'Abierto/parcial. No se observaron dobles en las resueltas; no se demuestra el invariante completo en 50 resueltas','action':'Revisar perfil/recuperación y diseño transaccional con el equipo, repetir en entorno descrito tras corrección autorizada. No elevar retries ni serializar solicitudes para ocultar la prueba'},
 {'id':'DOC-CODE-01','nature':'Discrepancia de requisito e implementación','requirement':'AC-06/RNF-024 y HU 3.7','evidence':'Informe 6.3 y gamePolicy.ts:20; UT-VIC-01-C01..C09','reproduction':'Inspeccionar ratingChange y ejecutar casos de caracterización','expected':'El informe promete fórmula ELO con probabilidad esperada','observed':'Ajuste lineal, empate +1, topes propios; caracterización se reproduce','severity':'Alta para conformidad de regla','cause':'Algoritmo confirmado por lectura/ejecución; intención de negocio no confirmada','state':'Decisión de negocio pendiente, no corregida','action':'Equipo/docente deben decidir regla y documento vigentes; no implementar ELO por iniciativa del agente'},
 {'id':'CODE-OBS-02','nature':'Observación de llamadas redundantes reproducida con doble','requirement':'Diagnóstico HU 3.2/2.3 ante fallo de persistencia','evidence':'UT-PED-01-C09 y gameUseCases.ts catch anidados','reproduction':'games.complete lanza DB offline en harness de EvaluateGame','expected':'Una transición de error con causa preservada; propuesta técnica, no requisito explícito nuevo','observed':'Se llama fail dos veces; la segunda recibe mensaje genérico','severity':'Baja/Media: redundancia y posible pérdida de contexto; repositorio real protege por estado','cause':'Confirmada por doble: dos catch encadenados invocan fail','state':'Observación abierta, sin afirmar doble escritura real','action':'Revisar política de diagnóstico cuando se autoricen cambios de producto'},
 {'id':'DOC-01','nature':'Error documental confirmado','requirement':'HU 1.1','evidence':'contraste_fuentes_primarias.json, ASR E2:E3; catalogo_hu.json','reproduction':'Comparar D2 con E2:E3 en ASR','expected':'Criterios de registro con Google','observed':'Criterios de oración de ejemplo copiados de HU 1.6','severity':'Alta para trazabilidad','cause':'Copia de contenido confirmada; autor/intención no inferidos','state':'Reconciliación propuesta, no documento editado','action':'Validar propuesta S2 + ACCEPTANCE_REPORT y actualizar requisitos por su responsable'},
 {'id':'DOC-02','nature':'Inconsistencia de mensajes entre HU relacionadas','requirement':'HU 3.3 versus HU 3.4','evidence':'Informe 5.3, ASR E38:E39; GameViewModel.start; baseline de aceptación hu3_4_scenario2','reproduction':'Contrastar You don’t have enough Merit to enter frente a The ranked match cannot be started. Insufficient Merit','expected':'Contrato UX coherente aprobado','observed':'Backend y ViewModel siguen mensaje de HU 3.4; HU 3.3 pide otro texto','severity':'Media para aceptación/UI','cause':'Diferencia documental/capas confirmada; decisión de UX pendiente','state':'Observación; no se etiqueta fallo E2E de UI','action':'Conciliar por capa/caso de uso con responsable de requisitos; no borrar uno de los criterios'}]
defects.append({'id':'TRANS-01','nature':'Fallo transaccional intermitente observado','requirement':'HU 3.5 resolución a 48h','evidence':'final-node20-firestore.log caso BASE-INT-07; diagnostico-48h.log; baselines previos','reproduction':'R8 fallback waits exactly 48 hours… con match/recover concurrentes sobre mismo ID','expected':'Resolver una sola vez con promedio del jugador','observed':'En última suite completa: INVALID_ARGUMENT Transaction is invalid or closed. Diagnóstico aislado posterior: 1 aprobado, 16 omitidos por filtro; no se suma al total final ni borra el fallo','severity':'Media/Alta: impide acreditar estabilidad de recuperación bajo concurrencia','cause':'No confirmada: error del emulador/SDK o manejo de transacción; no se atribuye a producto sin aislar','state':'Abierto como fallo intermitente; diagnóstico aislado aprobado','action':'Conservar logs; aislar SDK/emulador antes de decidir una corrección de producto'})
js('Defectos.json',defects)
d='# Registro de defectos y discrepancias\n\nLos fallos de test, las observaciones estáticas y las brechas de producto se distinguen por naturaleza. Un test de caracterización aprobado puede documentar una brecha de conformidad. No se cambió lógica de negocio.\n\n'
for x in defects:
    d+='## '+x['id']+' '+x['nature']+'\n\n'+table(['Campo','Detalle'],[[k,x[k]] for k in ['requirement','evidence','reproduction','expected','observed','severity','cause','state','action']])+'\n'
write('Defectos.md',d)

guide='# Guías de sustentación\n\nEstas fichas preparan estudio previo. No se confirmó reparto ni duración; no describen aportes históricos ni autorizan asistencia de IA en la defensa. Antes de sustentar, cada integrante debe revisar y reproducir su ficha, explicar las aserciones y registrar su aporte real.\n\n'
for p in package_info:
    guide+=f'## {p["person"]}\n\nFuncionalidad propuesta: {p["purpose"]}. HU: '+', '.join(p['hu'])+'. Criterios y límites: ver [matriz](Matriz_Pruebas_y_Trazabilidad.md) y [ficha individual](paquetes/Paquete_'+p['key']+'.md).\n\n'
    guide+=f'Ruta breve: explicar el criterio; localizar `{p["cb"]}` en el commit; recorrer un caso válido y uno de rechazo; abrir [CFG {p["graph"]["id"]}](caja_blanca/{p["graph"]["id"]}.md); justificar V(G)={p["graph"]["V"]} y la independencia; distinguir el contrato interno CN `{p["cn"]}` de la UI; reproducir `{p["unit"]}` y contrastar sus {p["unit_count"]} casos.\n\n'
    guide+='Ruta ampliada: seguir HU → criterio → interfaz/caso de uso → repositorio/adaptador → aserciones → log. El diseño funcional del paquete se cruza con [las secuencias S2/S5](fuentes/uml/1W7ebqUynQu_ufuR_xnCQH24ipOrIzS4h.drawio), y la vista de clases debe leerse por Page-3 del [archivo de clases](fuentes/uml/1Qto-RwDQKev87DFfJQetes5yMznxEsPl.drawio). Los diagramas del paquete se revisaron semánticamente; no se certificó su geometría. No presentar funciones TypeScript como clases ni trasladar complejidad de Kotlin a TypeScript.\n\n'
    guide+='Comando de práctica desde backend ya compilado: `node --test --test-name-pattern=UT-'+p['key']+' functions/test/capitulo10.test.cjs`. Para toda la ficha, seguir README_Ejecucion.md. Mostrar el log real y el parche, no un diálogo “Demostrar Mensaje”. Explicar preparación–acción–aserción y qué efectos se prohíben.\n\n'
    guide+='Preguntas para estudiar: ¿de dónde sale cada esperado? ¿qué campos recibe realmente la CN? ¿qué camino nuevo añade cada fila? ¿qué diferencia hay entre branch coverage y path coverage? ¿qué no demuestra el doble/emulador? ¿qué parte del criterio exige pantalla o servicio real?\n\n'
    guide+='Resultado técnico: casos seleccionados aprobados; CN interna pendiente de validación docente. '+('No llamar ELO a la regla caracterizada. AC-03 de 50 solicitudes sigue parcial.' if p['key']=='VIC' else ('El adaptador usa SDK simulado; no demuestra IA externa.' if p['key'] in ['PED','JEA'] else 'La ficha no acredita por sí sola pantalla, sesión real ni contribución individual.'))+'\n\nRevisión humana, reproducción individual y aporte concreto: pendientes de registrar por el integrante.\n\n'
write('Guias_Sustentacion.md',guide)

pending=[
 {'id':'P-01','block':'CN interna y reparto','cause':'No hay confirmación docente de aceptación de contratos internos ni del reparto individual','action':'Presentar fichas con firma, cinco campos, particiones y resultados. Preguntar si se acepta esta frontera y compartir funcionalidad con aportes distintos','owner':'Wong y equipo','independent_work':'Se completaron diseño y ejecución de seis contratos; CB/UT no dependen de la respuesta'},
 {'id':'P-02','block':'Participación individual','cause':'Solo consta encargo centralizado de Marco; no constan revisiones/aportes/reproducciones de los seis','action':'Cada integrante registra revisión, cambio/aporte y reproducción con fecha','owner':'Seis integrantes','independent_work':'67 casos unitarios principales, seis fichas y guías preparados'},
 {'id':'P-03','block':'AC-01 y evaluación semántica real','cause':'No se proporcionó un entorno de prueba cloud/OpenAI ya autorizado; por instrucción se usa evaluador determinista sin facturación','action':'Con entorno autorizado medir desde envío aceptado hasta evaluación persistida/notificada, ≥90% ≤5s; guardar muestras, errores, calentamiento y denominador','owner':'Equipo','independent_work':'SDK simulado, timeout, malformación, 429 y 503 implementados; no se inventaron muestras cloud'},
 {'id':'P-04','block':'UI y extremo a extremo','cause':'Copia Android sin google-services.json de pruebas; no hay dispositivo/entorno de autenticación de prueba conectado. Tests JVM usan dobles y no renderizan pantallas','action':'Aportar configuración Firebase de prueba, dispositivo/emulador y cuentas de prueba; inducir fallos y capturar pantallas por caso','owner':'Responsable de cliente','independent_work':'Baseline, límites, mappers, ViewModels y cobertura JVM ejecutados'},
 {'id':'P-05','block':'AC-02 cuota/disponibilidad','cause':'CODE-01 reproducido: FAILED sin reintento programado','action':'Acordar y corregir política de recuperación; retestar 429/503 separados del timeout','owner':'Backend/equipo','independent_work':'Timeout persistente y recuperación a 5 min comprobados'},
 {'id':'P-06','block':'AC-03 perfil 50','cause':'LOAD-01: solapamiento 50 observado con transacciones abortadas por lock timeout en emulador','action':'Analizar contención/recuperación y retestar sin alterar silenciosamente el perfil ni elevar retries para maquillar la evidencia','owner':'Backend/equipo','independent_work':'Se preservan todos los intervalos, errores y estados; parejas resueltas contrastadas'},
 {'id':'P-07','block':'AC-06 ELO','cause':'Requisito y regla propia discrepan','action':'Decidir regla vigente; actualizar código o documento tras autorización específica','owner':'Equipo/docente','independent_work':'Nueve casos de caracterización y CFG de ratingChange'},
 {'id':'P-08','block':'Negativos de rating/resultado/variación','cause':'HU 3.6, 3.8 y 3.9 tienen comparaciones de constantes en la suite histórica, sin inducir operación fallida real','action':'Añadir fallos controlados de la operación del cliente y verificar estado/mensaje/pantalla','owner':'Cliente/equipo','independent_work':'Mappers con WIN/LOSS/DRAW, variación positiva/negativa/ausente y datos malformados ejecutados'},
 {'id':'P-09','block':'Fuente de HU 1.1 y mensajes 3.3/3.4','cause':'DOC-01 y DOC-02','action':'Validar reconciliación y criterios por capa','owner':'Responsable de requisitos','independent_work':'Filas propuestas completas, sin editar el compartido'},
 {'id':'P-10','block':'PPT específico unitarias','cause':'No incluido en fuentes accesibles del paquete','action':'Si el docente lo exige, incorporarlo y contrastar solo lo pertinente; no requiere contraseña para continuar','owner':'Marco','independent_work':'Se aplicó rúbrica y ejemplos locales fijados de Wong'},
 {'id':'P-11','block':'Mantenimiento de dependencias','cause':'npm ci de baseline informó 31 vulnerabilidades (1 baja,14 moderadas,13 altas,3 críticas)','action':'Revisar en tarea de mantenimiento; no ejecutar audit fix ni migrar dependencias dentro del encargo de pruebas','owner':'Equipo','independent_work':'Lockfile de producto conservado'}]
pending.append({'id':'P-12','block':'Estabilidad de recuperación 48h','cause':'TRANS-01 falló en suite completa y aprobó aisladamente','action':'Aislar error de transacción/SDK/emulador antes de concluir causa raíz; no borrar el fallo con una repetición','owner':'Backend/equipo','independent_work':'Baseline, ejecución fallida y diagnóstico aprobado con reloj controlado conservados'})
js('Pendientes.json',pending)
write('Registro_IA_y_Pendientes.md','# Registro factual de IA y pendientes\n\nHerramienta: Codex en la app de escritorio. Finalidad: ejecutar el prompt autorizado, inspeccionar fuentes/repositorios, preparar tests/fixtures mínimos, ejecutar runners, calcular CFG y redactar entregables. Material generado: dos parches, nuevos tests, configuración de cobertura, seis fichas, matrices, borradores y guías.\n\nValidación realizada por el agente: integridad SHA-256 (79/79), contraste de fuentes originales, baseline antes de cambios, pruebas reales Node/Firestore/JVM, reportes V8 y JaCoCo, rango de grafos y revisión de diff. No se afirma revisión humana. Marco solicitó y centralizó la preparación; no consta que él o los demás hayan reproducido o validado individualmente el material. No se inventan prompts históricos, porcentajes de intervención ni evaluaciones por pares. No hubo llamadas reales a OpenAI, publicación, despliegue ni edición del informe compartido.\n\nLa guía de IA del curso, apartados 2.5/2.7 y declaración crítica, se usó como fuente documental; la declaración final debe completarla cada estudiante con hechos propios. Preparar guías de estudio no implica asistencia de IA durante defensa.\n\n'+table(['ID','Pendiente / causa concreta','Acción y responsable','Trabajo independiente completado'],[[p['id'],p['block']+': '+p['cause'],p['action']+' — '+p['owner'],p['independent_work']] for p in pending]))

# Borrador académico que remite a evidencia verificable.
suite_table=table(['Suite final','Aprobados','Fallidos','Omitidos','Evidencia'],[[label,counts[label].get('Ejecutado aprobado',0),counts[label].get('Ejecutado fallido',0),counts[label].get('Omitido',0),f'[log](evidencias/{label}.log)'] for label in evidence_labels])
qsummary=f'{quality["completed"]}/50 operaciones sin error, {quality.get("matched",0)} partidas resueltas y {quality.get("verifiedPairs",0)} parejas recíprocas; pico observado {quality["peakActiveOperations"]}; {len(quality.get("violations",[]))} inconsistencias observadas en las parejas resueltas'
chapter=f'''# Capítulo 10 Pruebas de software

Borrador para revisión del Grupo 3. Corte de ejecución: 5 de noviembre de 2026 en Lima. Se completó el expediente local de pruebas y se mantienen los defectos/pendientes identificados. No certifica conformidad total del producto ni participación individual. Backend `{BACK}` (rama base Inkr8BackEnd); Android `{FRONT}` (main). Las dos copias aisladas usan la rama local pruebas/capitulo-10, sin commit publicado.

## 10.1 Estrategia de pruebas

Se priorizó la unión de 19 HU de 5.6/S2/S5 y se añadió HU 2.2 por el método de validación seleccionado. La identidad procede de 5.1; no se reconstruyeron IDs desde números Excel. Se conservaron las nueve filas de 5.3/5.6 y sus referencias a capítulo 9. La rúbrica Rubrica!D18 pide por integrante CB V(G)>4, CN más de cuatro entradas y unitaria con al menos cuatro casos. Se prepararon seis fichas con 18 aportes principales y 67 casos unitarios distinguibles, además de casos de CN, CB e integración. Compartir una ejecución entre técnicas o HU no suma ejecuciones.

Fuentes: informe local con modificación recuperada 2026-11-05T23:55:29.015Z; rúbrica/ASR originales; enunciado, guía IA, Semana 12 y referencias fijadas de Wong. Se rechazó ASR E2:E3 para Google y se preparó reconciliación S2/ACCEPTANCE_REPORT. El backend coincide con el commit del paquete. Su URL antigua redirige a Rnz5/Inkr8Backend; no se renombró el repositorio. El conector frontend siguió devolviendo 404, pero Git permitió clonar main después de repetir el enlace facilitado por Marco. No se usó turron como implementación activa.

Se adoptó de Wong preparación–acción–aserción, errores observables y comprobación de efectos prohibidos. Los ejemplos assertTrue(true), colecciones sin aserciones y las constantes de mensajes no se usaron como pruebas funcionales. En Android se localizaron los 60 métodos declarados: varios solo construyen DTO o comparan constantes; su ejecución no acredita 60 criterios completos.

Entorno: Windows, Node 20.19.0 y npm 10.8.2 para funciones, TypeScript del lockfile, Firebase CLI 14.22.0, emulador Firestore 1.19.8, proyecto demo-inkr8 y host loopback. Java inicial 8 se sustituyó para pruebas por JDK local 21.0.9; Gradle 9.1.0, SDK plataforma 36 y Build Tools 36.0.0. JaCoCo 0.8.14 se añadió como configuración mínima. No se cambió stack ni lógica de producto. Android se ejecutó offline tras preparar herramientas/caché. Las versiones/rutas efectivas finales quedan en JSON de comandos. La exploración inicial incluyó Java 25 y el CLI invocado por resolución de Windows; los cierres de backend fijan ruta absoluta Node 20. El npm de las ejecuciones iniciales resuelve la distribución Node 20 por PATH; no se usan ensayos exploratorios para mezclar cobertura.

Baseline: dominio backend 17/17; integración 16/17 (expectativa /insuficiente/); Android dominio 3/3 y app 68/70 (fixture de observación fijo). Se preservaron logs/XML originales. Se corrigieron únicamente esas dos causas de test y se añadieron las brechas necesarias.

{suite_table}
Los {len(cases)} casos distintos finales no suman repeticiones exploratorias. Los dos fallos de suite final son AC03-C01 y el escenario concurrente de recuperación a 48h (TRANS-01). El diagnóstico aislado se conserva por separado y no reemplaza la suite. Tasks Gradle SKIPPED de configuración/GoogleServices no son casos omitidos: los XML finales tienen cero tests skipped. [Casos y duraciones reales](Casos_ejecutados.json).

Calidad: AC-01 permanece pendiente sin IA real/entorno cloud autorizado. AC-02 timeout controlado se traduce y persiste para reintento, pero cuota/disponibilidad sigue CODE-01. AC-03 ensayó cola compartida y 50 solicitudes con timestamps monotónicos y solapamiento efectivo: {qsummary}. La prueba añade la expectativa de completar/resolver las 50, y falla; no se presenta cero errores de emparejamiento total. AC-04 acreditó una recompensa tras 10 cierres simultáneos y dos repetidos. AC-05 verificó 99/100/101 y diez partidas compitiendo por los mismos 100 Merit. AC-06 conserva la discrepancia de ELO. Semana 12 orientó selección, preparación fuera de ventana, muestras y denominadores; no se copiaron umbrales de TVendo.

## 10.2 Pruebas de caja blanca

Se eligieron seis flujos reales con complejidad superior a cuatro. Se cuentan if, ternarios y cortocircuitos del propio alcance, sin sumar callbacks desconectados ni predicados ocultos de bibliotecas. Los retornos/throws convergen en salida común. Cada grafo contrasta E−N+2 con 1+Σ(grado_salida−1); no se inventan regiones. La base de cada grafo se comprobó con rango GF(2) de vectores de aristas y entradas factibles. La correspondencia entrada/camino se deduce del control de flujo, sin afirmar un trazador de nodos instrumentado.

'''
chapter+=table(['Paquete','Método','N','E','V(G)','Caminos/rango','Detalle'],[[p['short'],p['cb'],p['graph']['N'],p['graph']['E'],p['graph']['V'],str(p['graph']['V'])+'/'+str(p['graph']['path_vector_rank_GF2']),f'[CFG](caja_blanca/{p["graph"]["id"]}.md)'] for p in package_info])
chapter+='''
Los 42 caminos de las bases tienen casos ejecutados aprobados. La rotación hacia backend evita forzar complejidad en ViewModels o añadir temporadas. Pedro usa validateWriting TypeScript con cortocircuitos y ambos ternarios (máximo y mensaje), V=6; no se atribuye V=6 a la función Kotlin. Renzo usa solo el flujo exterior conectado de dailyWord y excluye el callback de la transacción. El detalle contiene código fuente con nodos numerados, grafo, aristas, fórmula, base e independencia.

## 10.3 Pruebas de caja negra

Se definieron seis fronteras internas distintas antes de contar campos. Start recibe seis campos efectivos; season se sobrescribe y se excluye. Complete recibe campos de Game/Evaluation, no el saldo como argumento del callable. StructureEvaluation recibe contenido, modo, restricciones y detalle. El adaptador recibe seis campos que aparecen en JSON del SDK simulado. HasMetadata usa cinco propiedades de Word. MapUser recibe ID y propiedades opcionales del DTO. Cinco elementos de un array no cuentan como cinco entradas.

'''
chapter+=table(['Paquete','Operación','Campos reales contados','Resultado / límite'],[[p['short'],p['cn'],', '.join(p['cn_fields']),'Casos aprobados; aceptación docente de contrato interno pendiente'] for p in package_info])
chapter+='''
Las [seis fichas](paquetes/Seis_fichas.json) detallan tipo, partición válida/inválida o fuera de contrato, límites y efecto observable. En enums/booleanos no se inventan límites numéricos; en mappers no se exige validación ajena a su contrato. Los oráculos se enlazan al criterio, contrato o caracterización explícita. Los mensajes del backend y UX se mantienen como capas distintas, con DOC-02 pendiente. Consulta concreta a Wong: “¿Acepta contratos internos con cinco campos reales recibidos y particiones/límites aunque no haya cinco controles visuales? ¿Puede compartirse funcionalidad con escenarios/aportes individuales diferentes?”. Renzo prueba un helper privado compilado y debe mostrar especialmente esa frontera. No se declaran seis CN docentes conformes sin respuesta.

## 10.4 Pruebas unitarias y cobertura

'''
chapter+=table(['Paquete','Método unitario seleccionado','Casos distintos aprobados','Código'],[[p['short'],p['unit'],p['unit_count'],p['unit_file']] for p in package_info])
chapter+='''
Merit cubre tramos y límites, Ranked, bonus de palabras/tope y scores no finitos/fuera de rango. ValidateWriting adicional cubre STANDARD 49/50/150/151, ON_TOPIC 200/201 y 10 000/10 001 caracteres sin alterar el conteo de 50 palabras. EvaluateGame comprueba éxito, estado final, timeout, malformación, cuota y disponibilidad, con efectos prohibidos sobre completar/parear. Los SDK/servicios controlados no demuestran disponibilidad real ni atomicidad; Firestore se usa para esta última.

La cobertura de JS compilado se mapea a TS mediante los mapas verificados; no se extrapolan porcentajes a métodos sin denominador propio. [Reporte por archivo y módulo](evidencias/Cobertura.md), V8 bruto y JaCoCo XML/HTML están incluidos. No se suma cobertura de backend y Android ni se atribuye el total del runner, que incluye tests, al producto. Las duraciones del runner tampoco prueban AC-01. Las aserciones por caso están en código y enlazadas en Casos_ejecutados/Matriz. No hay tests omitidos contados como aprobados.

## 10.5 Defectos, acciones y cierre

'''
chapter+=table(['ID','Hallazgo','Estado','Evidencia'],[[x['id'],x['nature'],x['state'],x['evidence']] for x in defects])
chapter+='''
El [registro de defectos](Defectos.md) especifica requisito, reproducción, esperado/obtenido, severidad/impacto, causa confirmada o hipótesis, estado y acción. No se corrigió negocio para hacer pasar los tests. La interpretación docente CN, aporte individual, IA cloud, UI real, recuperación 429/503 y rating ELO siguen en [pendientes](Registro_IA_y_Pendientes.md).

Entrega preparada: seis paquetes técnicos con CB/CN/UT y cobertura disponible, dos parches revisables, evidencia de ejecución y filas para 5.3/5.6. Conformidad del producto: parcial, con carga fallida y decisiones abiertas. No se cierran de extremo a extremo las 19 HU; las seis previamente enlazadas al capítulo 10 mantienen evidencia acotada y pendientes visibles. El contenido está listo para revisión previa a la asesoría del 7 de noviembre, sin atribuir validaciones humanas ni cerrar pendientes por la fecha.
'''
write('Capitulo_10_Borrador.md',chapter)

# Fuente/autoridad y comandos reproducibles de los dos repositorios.
for name in ['00_LEEME_MARCO.md','Prompt_Inkr8_Capitulo_10.md','Preparacion_Pruebas_Inkr8_S2_S5.md','Protocolo_Evidencias_Inkr8.md','Referencia_Henry_Wong_Inkr8.md','Auditoria_Documental_Inkr8.md','catalogo_hu.json','fuentes.json','manifest_sha256.json']:
    dest=out/'fuentes'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(package/name,dest)
shutil.copytree(package/'referencias_locales/originales',out/'fuentes/originales',dirs_exist_ok=True)
shutil.copytree(package/'referencias_locales/uml',out/'fuentes/uml',dirs_exist_ok=True)
write('fuentes/LEEME_Fuentes.md','# Fuentes de la entrega\n\nSe adjuntan copias locales de los originales y metadatos, fuera de los parches de código. Se leyeron fuentes pertinentes a las decisiones, sin una nueva revisión indiscriminada de Drive. `contraste_fuentes_primarias.json` registra celdas/tablas y páginas de PDF consultadas. La geometría completa de Word/UML y todos los videos no se certificaron visualmente. Las instrucciones históricas/plantillas de estos archivos son contenido de referencia; el alcance ejecutado es el prompt operativo solicitado por Marco.\n')

readme='''# Reproducción del capítulo 10

Los ZIP base de codigo/ contienen exactamente las versiones fijadas, sin dependencias ni credenciales. Los parches añaden solo tests, fixtures y cobertura. Alternativamente clonar los repositorios indicados y checkout a los SHA. Trabajar en copias aisladas, sin mezclar cambios del equipo.

## Backend

Base: https://github.com/Rnz5/Inkr8-ISW2 , rama Inkr8BackEnd, SHA `'''+BACK+'''`. La URL actualmente redirige a Rnz5/Inkr8Backend. Node 20.19.0, npm 10.8.2; JDK 21.0.9 y Firebase CLI 14.22.0 para emulador. Extraer backend_base.zip o clonar; aplicar desde su raíz:

```powershell
git apply --check C:/ruta/entrega/codigo/backend.patch
git apply C:/ruta/entrega/codigo/backend.patch
npm --prefix functions ci
npm --prefix functions run build
npm --prefix functions test
npm --prefix functions run test:coverage
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"
```

La prueba AC03-C01 conserva un fallo de disponibilidad/resolución completa del perfil 50. No interpretar exit 1 como un error de instalación si el log identifica esa aserción. El perfil mide intervalos de operación de MatchRepository contra cola compartida; no es carga de callables públicos ni prueba cloud. Cada usuario tiene nombre y score únicos para reconstruir parejas sin cambiar esquema.

Para guardar JSON de transacciones/concurrencia, establecer `$env:CAP10_EVIDENCE_DIR` a una carpeta absoluta creada previamente. Sin esa variable, el test imprime los datos en el log. Para V8 bruto, establecer `$env:NODE_V8_COVERAGE` a otra carpeta absoluta; ejecutar desde functions `node --test --test-reporter=tap --experimental-test-coverage test/domain.test.cjs test/capitulo10.test.cjs test/adapter.capitulo10.test.cjs`. La medición final usa esta orden y las bibliotecas ya compiladas; el source map se verifica con `verificar_mapeo_cobertura.cjs` si se replica la estructura de trabajo o se adaptan rutas.

Firebase CLI puede instalarse en una carpeta de herramientas separada con versión fija; no se añadió a las dependencias de producto. Usar exclusivamente `demo-inkr8` y host 127.0.0.1/localhost. Las suites vacían fixtures del proyecto emulado y contienen guardas antes de conectarse. No apuntar a producción. El SDK OpenAI se sustituye en tests antes de importar el adaptador y nunca consume una clave real. `test:integration` ejecuta archivos en serie para evitar que dos hooks clearFirestore compartan proyecto en paralelo.

## Android

Base: https://github.com/Matonga-Matonag/Inkr8Android , main, SHA `'''+FRONT+'''`. Gradle wrapper 9.1.0, JDK 21, SDK platform android-36, Build Tools 36.0.0. Clonar/extraer frontend_base.zip; aplicar frontend.patch desde raíz. Configurar JAVA_HOME al JDK y ANDROID_HOME al SDK (o local.properties propio, sin commit).

```powershell
git apply --check C:/ruta/entrega/codigo/frontend.patch
git apply C:/ruta/entrega/codigo/frontend.patch
.\gradlew.bat :domain:test :app:testDebugUnitTest --offline --no-daemon --max-workers=2
.\gradlew.bat :domain:jacocoTestReport :app:jacocoDebugUnitTestReport --offline --no-daemon --max-workers=2
```

JaCoCo 0.8.14 se añadió con los plugins/tareas declarados en el patch. Si falta caché, repetir una vez sin --offline para descargar las dependencias y después volver al comando acordado. --offline no crea herramientas ni descarga librerías. En esta entrega el intento offline previo falló por agente JaCoCo no cacheado; se preparó caché y el cierre offline, con --rerun-tasks, ejecutó los 89 tests y los reportes. No se necesitan claves Firebase para tests JVM: GoogleServices se omite como permite la configuración del repo. Ello no convierte el test en login real.

## Evidencia y límites

La evidencia principal es final-node20-unit.log (116/116), final-node20-firestore.log (43/45) y android-final-offline.log/XML (89/89). Los baselines y ensayos se conservan y no se suman. El ensayo ac03-aislado repite solo el perfil de carga con otros tests omitidos por filtro; esas omisiones no cuentan como aprobaciones. El diagnóstico de 48h dio 1 aprobado y 16 omitidos por filtro, sin reemplazar el fallo de la suite completa. El JSON AC03 actualiza el último perfil de carga medido, y las carpetas primera/segunda/tercera-carga conservan intentos previos. Las ejecuciones de carga anteriores coincidieron con preparación/build Android; el aislado termina esa interferencia, sin inferir capacidad cloud.

No hay capturas de pantalla de la app como evidencia: no se renderizó un cliente conectado a un entorno de prueba. Los HTML/XML son reportes auténticos de runners. Abrirlos localmente para revisar resultados y cobertura. Los 60 métodos históricos de aceptación no equivalen a 60 operaciones probadas: varios solo comparan mensajes o DTO construidos por el propio test. La matriz señala esos límites.

Los generadores/verificadores de matrices, CFG y mapeo se entregan en herramientas/ porque forman parte de la evidencia solicitada. Las rutas efectivas y códigos de retorno están en JSON por comando. Los binarios descargados permanecen en work/tools del equipo de ejecución y no se empaquetan; fuentes/ conserva checksums/procedencia para preparar otro entorno. No se publicó, fusionó ni desplegó ningún cambio.
'''
write('README_Ejecucion.md',readme)

# README incorporado a los parches: solo instrucciones de test, ninguna fuente académica privada.
for repo in ['backend','frontend']:
    text='# Pruebas del capítulo 10\n\n'
    text+='Preparación técnica de Codex solicitada por Marco. El reparto por integrante es una propuesta para revisión; este archivo no acredita autoría ni reproducción humana.\n\n'
    if repo=='backend':text+='Node 20. `npm --prefix functions ci`; `npm --prefix functions test`; `npm --prefix functions run test:coverage`. Integración: `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"` con Firebase CLI 14.22.0 y Java 21. La suite funcional y la carga usan procesos de emulador separados: ejecutar también `firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:coverage"`. Run-Firestore.ps1 coordina ambas. La carga conserva 50 operaciones concurrentes y todas sus aserciones. Los archivos funcionales se ejecutan en serie y solo en loopback.\n\nCAP10_EVIDENCE_DIR opcional guarda JSON auténtico de AC-02/03/04/05. AC03-C01 mide 50 solicitudes contra cola compartida y comprueba la resolución completa además de invariantes; puede fallar por lock timeout bajo contención local. Conservar sus resultados y diagnosticar, sin reemplazar por cincuenta llamadas secuenciales.\n\nLos tests del adaptador sustituyen SDK OpenAI; no requieren ni utilizan credenciales reales. Las reglas de recompensa/rating se caracterizan; no se declara conformidad ELO.\n'
    else:text+='JDK 21, SDK 36/Build Tools 36.0.0. `gradlew.bat :domain:test :app:testDebugUnitTest --offline --no-daemon --max-workers=2`. Reportes configurados: `gradlew.bat :domain:jacocoTestReport :app:jacocoDebugUnitTestReport --offline --no-daemon --max-workers=2`. JaCoCo 0.8.14 necesita caché o una preparación online previa.\n\nLos tests son JVM y no renderizan pantallas. La suite histórica de 60 criterios contiene comparaciones de constantes/DTO que no prueban esos criterios completos. El fixture FakeGameRepo conserva ahora la partida devuelta por start para que observe no sustituya modo/restricciones.\n'
    (root/'work'/repo/'README_CAPITULO_10.md').write_text(text,encoding='utf-8')

code_meta=[]
for repo,base in [('backend',BACK),('frontend',FRONT)]:
    folder=root/'work'/repo
    status_before=subprocess.check_output(['git','status','--short'],cwd=folder).decode('utf-8')
    subprocess.run(['git','add','-N','.'],cwd=folder,check=True)
    subprocess.run(['git','diff','--check'],cwd=folder,check=True)
    patch=subprocess.check_output(['git','diff','--binary','--full-index','HEAD'],cwd=folder)
    (out/'codigo').mkdir(exist_ok=True);(out/'codigo'/(repo+'.patch')).write_bytes(patch)
    changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=folder).decode().splitlines()
    for name in changed:
        dest=out/'codigo'/repo/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(folder/name,dest)
    subprocess.run(['git','archive','--format=zip',f'--output={out/"codigo"/(repo+"_base.zip")}',base],cwd=folder,check=True)
    with zipfile.ZipFile(out/'codigo'/(repo+'_base.zip')) as archive:archive.extractall(out/'codigo'/repo)
    for name in changed:shutil.copy2(folder/name,out/'codigo'/repo/name)
    code_meta.append({'repo':repo,'base':base,'branch':'pruebas/capitulo-10','initial_state':'Copia aislada recién clonada; git status inicial vacío antes de editar','final_status':subprocess.check_output(['git','status','--short'],cwd=folder).decode(),'changed':changed,'patch_sha256':hashlib.sha256(patch).hexdigest(),'published':False,'business_source_modified':False})
js('codigo/Bases_y_parches.json',code_meta)
for name in ['run_logged.py','build_cfg.py','verify_coverage.cjs','inspect_sources.py']:
    dest=out/'herramientas'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'work'/name,dest)
# El verificador original usa rutas de work; preservar nombre documentado como alias descriptivo.
shutil.copy2(root/'work/verify_coverage.cjs',out/'herramientas/verificar_mapeo_cobertura.cjs')
for name in ['java21_download.json','android_downloads.json']:
    if (root/'work/tools'/name).exists():shutil.copy2(root/'work/tools'/name,ev/name)

summary={'date_lima':'2026-11-06','packages_technical_prepared':6,'packages_teaching_and_human_confirmed':0,'main_contributions':18,'main_unit_cases':67,'basic_paths':42,'priority_HU':19,'extra_HU':['HU 2.2'],'HU_with_related_evidence':19,'priority_HU_closed_end_to_end':0,'six_previously_linked_to_10_with_related_evidence':6,'six_closed_end_to_end':0,'unique_final_cases':len(cases),'suite_counts':counts,'AC03_latest':{k:quality.get(k) for k in ['wallStart','attempted','completed','peakActiveOperations','matched','verifiedPairs','violations']},'product_conformity':'Parcial; LOAD-01/CODE-01/DOC-CODE-01 y cliente/cloud/participación pendientes','patches':code_meta}
js('Resumen_resultados.json',summary)
main='# Entrega Inkr8 capítulo 10\n\nSe prepararon **6/6 paquetes técnicos** (CB, CN interna y unitaria), 18 aportes principales, 67 casos unitarios y 42 caminos básicos. **0/6** tienen conformidad docente/participación individual confirmada. El producto mantiene defectos y límites; no se marca “todo conforme”.\n\n'+suite_table+'\n'
main+='Son 250 casos distintos finales: 248 aprobados y 2 fallidos; no se suman repeticiones. AC-03 se repitió aislado: '+qsummary+'. El fallo conserva el perfil solicitado y la evidencia de bloqueo transaccional. El otro fallo es TRANS-01, recuperación concurrente a 48h con transacción inválida/cerrada; su diagnóstico aislado se conserva sin borrar la suite. AC-02 cuota/disponibilidad no programa reintento; AC-06 difiere de ELO. No se hicieron llamadas facturables ni capturas falsas.\n\n'
main+='Las 19 HU prioritarias tienen evidencia relacionada y límites por criterio; ninguna se cierra de extremo a extremo. El subtotal de las seis que ya apuntaban a capítulo 10 es 6 con evidencia acotada y 0 cerradas íntegramente. HU 2.2 se añade de forma justificada, sin extender pruebas nuevas al catálogo completo de 30. Los tres negativos 3.6/3.8/3.9 aún dependen de pruebas que solo comparan constantes.\n\n'
main+=table(['Entregable','Contenido'],[['[Capítulo 10](Capitulo_10_Borrador.md)','10.1–10.5 con ejecución, cobertura y defectos'],['[Matriz](Matriz_Pruebas_y_Trazabilidad.md)','CSV y JSON con HU/casos, fuentes, versión, resultado y límites'],['[Seis fichas](paquetes/Seis_fichas.json)','CB/CN/UT por responsable propuesto y revisión pendiente'],['[Filas 5.3/5.6](Filas_5_3_y_5_6.md)','Nueve originales conservadas + diez ausentes + HU 2.2 adicional'],['[Código y reproducción](README_Ejecucion.md)','Parches por repo, ZIP base, comandos y entorno'],['[Cobertura](evidencias/Cobertura.md)','Node por archivo, V8/mapas y JaCoCo XML/HTML'],['[Defectos](Defectos.md)','Reproducción, severidad, causa y acciones'],['[Guías](Guias_Sustentacion.md)','Seis rutas de estudio sin atribución ficticia'],['[IA y pendientes](Registro_IA_y_Pendientes.md)','Registro factual y acciones concretas']])
main+='\nLos tests y reportes proceden de herramientas reales. Las fuentes del curso permanecen fuera del parche. Ningún cambio se publicó ni se editó el informe compartido. `Validacion_Entrega.json` contrasta conteos, referencias, hashes de parches y aplicación sobre las bases.\n'
write('README_Entrega.md',main)
print(json.dumps(summary,ensure_ascii=True,indent=2)[:4000])
