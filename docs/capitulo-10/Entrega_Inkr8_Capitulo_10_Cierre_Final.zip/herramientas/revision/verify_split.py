import pathlib,json,hashlib
root=pathlib.Path(__file__).resolve().parents[2];p=root/'outputs/evidencias/revision/Separacion_carga.json';x=json.loads(p.read_text())
before=(root/'outputs/codigo/backend/functions/integration/capitulo10.firestore.test.cjs').read_text()
after=(root/'work/backend/functions/integration/capitulo10.concurrency.test.cjs').read_text()
marker="test('AC03-C01";before=marker+before.split(marker,1)[1];after=marker+after.split(marker,1)[1]
x.update(body_sha256_before=hashlib.sha256(before.encode()).hexdigest(),body_sha256_after=hashlib.sha256(after.encode()).hexdigest(),same_body=before==after)
assert x['same_body'];p.write_text(json.dumps(x,indent=2),encoding='utf-8');print(x)
