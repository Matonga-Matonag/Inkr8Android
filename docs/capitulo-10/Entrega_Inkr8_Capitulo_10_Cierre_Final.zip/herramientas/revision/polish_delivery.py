import csv,datetime,json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
# Solo prosa escrita en esta revisión; se preservan logs, código y fuentes originales.
replacements={
 'capítulo10':'capítulo 10','Capítulo10':'Capítulo 10','Revisión6de noviembre':'Revisión del 6 de noviembre',
 'Actualización6de noviembre':'Actualización del 6 de noviembre','del6de noviembre de2026':'del 6 de noviembre de 2026',
 'losSHAprobados':'los SHA probados','backend993':'backend 993','frontendd6':'frontend d6','la unión de19HU':'la unión de 19 HU',
 'HU2.2':'HU 2.2','usa5.1':'usa 5.1','conserva5.3/5.6':'conserva 5.3/5.6','al9':'al 9','del5nov':'del 5 de noviembre',
 'del6nov':'del 6 de noviembre','medición5nov':'medición del 5 de noviembre','medición89/89':'medición de 89/89',
 'de60métodos':'de 60 métodos','por≥4':'por ≥4','con≥4casos':'con ≥4 casos',
 'CB V≥5':'CB V ≥ 5','CN≥5entradas':'CN ≥ 5 entradas','Node20.19.0':'Node 20.19.0','npm10.8.2':'npm 10.8.2',
 'TypeScript5.9.3':'TypeScript 5.9.3','FirebaseCLI14.22.0':'Firebase CLI 14.22.0','emulador1.22.0':'emulador 1.22.0',
 'contra1.19.8':'contra 1.19.8','JDK21.0.9':'JDK 21.0.9','JaCoCo0.8.14':'JaCoCo 0.8.14',
 'conserva89/89':'conserva 89/89','las50operaciones':'las 50 operaciones','las50':'las 50','de50palabras':'de 50 palabras',
 'Hay257casos':'Hay 257 casos','Base:257casos':'Base: 257 casos','distintos,256aprobados y1fallido':'distintos, 256 aprobados y 1 fallido',
 'las3operaciones48h':'las 3 operaciones de recuperación a 48 h','las3operaciones':'las 3 operaciones',
 'exigir0rechazos/pico3':'exigir cero rechazos y pico de 3 operaciones','exige0rechazos':'exige cero rechazos',
 'exige0errores/pico3antes':'exige cero errores y pico de 3 antes','pico3/0rechazos':'pico de 3 y cero rechazos',
 'payload50palabras':'payload de 50 palabras','conserva50solicitudes':'conserva 50 solicitudes',
 'base9llamadas':'base 9 llamadas','completaron,10partidas':'completaron, 10 partidas','en5parejas':'en 5 parejas',
 'fue50':'fue 50','de50incrementos':'de 50 incrementos','por100Merit con99':'por 100 Merit con 99',
 'Semana12':'Semana 12','con1+':'con 1 +','igual aV':'igual a V','Los42casos':'Los 42 casos',
 'reciben6/10/7/6/5/7campos':'reciben 6/10/7/6/5/7 campos','seisCN':'seis CN',
 'tienen24/10/9/12/5/7casos':'tienen 24/10/9/12/5/7 casos','67en total':'67 en total','distingue49/50/150/151 y200/201palabras':'distingue 49/50/150/151 y 200/201 palabras',
 'y10000/10001caracteres':'y 10000/10001 caracteres','de50palabras':'de 50 palabras','a100%líneas/ramas/funciones':'a 100% de líneas/ramas/funciones',
 'de38+2criterios':'de 38 + 2 criterios','.19HU':'. 19 HU','al10':'al 10','a19o6HU':'a 19 o 6 HU',
 'negativos3.6/3.8/3.9':'negativos 3.6/3.8/3.9','Aprobó116/116unidad,51/51funcional y1/1carga50':'Aprobó 116/116 de unidad, 51/51 funcionales y 1/1 de carga de 50 solicitudes',
 'de50/50':'de 50/50','sus168casos':'sus 168 casos','ventana>100':'ventanas de más de 100',
 'histórico48h':'histórico de recuperación a 48 h','en25diagnósticos':'en 25 diagnósticos','cadaCN':'cada CN',
 'deUI':'de UI','paraAC-01':'para AC-01','recuperación429/503':'recuperación ante 429/503',
 'unarchivo':'un archivo','168/168backend':'168/168 backend','carga50/50con25parejas/pico50':'carga 50/50 con 25 parejas y pico de 50',
 'carga50':'carga de 50','caso48h':'caso de 48 h','67unitarias y42caminos':'67 unitarias y 42 caminos',
 '6paquetes,ejecución y10.5actualizado':'6 paquetes, ejecución y 10.5 actualizado','Criterios38+2':'Criterios 38 + 2',
 'cláusulas locales vs criterio integral;HUtrazada':'cláusulas locales frente a criterio integral; HU trazada',
 'Cláusulas locales vs criterio integral;HUtrazada':'Cláusulas locales frente a criterio integral; HU trazada',
 'CSV/JSONactualizados':'CSV/JSON actualizados','muchosamuchos':'muchos a muchos','Filas5.3/5.6':'Filas 5.3/5.6',
 '9originales+10ausentes+HU 2.2justificada':'9 originales + 10 ausentes + HU 2.2 justificada','Docente,ELO,UI/IAreal,participaciónindividual':'Docente, ELO, UI/IA real y participación individual',
 '19HU':'19 HU','cerradaE2E':'cerrada E2E','checkoutdelSHA':'checkout del SHA','Node20':'Node 20','JDK21':'JDK 21',
 'JAR1.22.0':'JAR 1.22.0','LaCLI14.22':'La CLI 14.22','losJSON':'los JSON',
 'nuevas:51casos funcionales y1carga':'nuevas: 51 casos funcionales y 1 de carga',
 'devuelve1si':'devuelve 1 si','conrutaabsolutaNode 20':'con la ruta absoluta de Node 20','conrutaalbinariofirebase.js':'con la ruta al binario firebase.js',
 'y50intervalos':'y 50 intervalos','existen50operaciones':'existen 50 operaciones','yJSON':'y JSON',
 'reejecutaron116unidad,51funcionales y1carga':'reejecutaron 116 de unidad, 51 funcionales y 1 de carga',
 'alSHA':'al SHA','Gradlewrapper9.1.0':'Gradle wrapper 9.1.0','SDK36/BuildTools36.0.0':'SDK 36/Build Tools 36.0.0',
 'ejecución89/89del5nov conXML/HTML':'ejecución de 89/89 del 5 de noviembre con XML/HTML','testsJVM':'tests JVM',
 'LosV8':'Los V8','yJaCoCo':'y JaCoCo','herramientas/permiten':'herramientas/ permiten','layoutdocumentado':'layout documentado','revision/contiene':'revision/ contiene','aOpenAI':'a OpenAI',
 'mantuvieron50solicitudes':'mantuvieron 50 solicitudes','Emulador1.22':'Emulador 1.22',';50solapadas':'; 50 solapadas',
 '50transacciones':'50 transacciones','50independientes':'50 independientes','50operaciones':'50 operaciones','sobre25pares':'sobre 25 pares',
 '50incrementos sobre1documento':'50 incrementos sobre 1 documento','11/50;39ABORTED':'11/50; 39 ABORTED',
 '45ABORTED; hasta5intentosSDK; hotspotm10':'45 ABORTED; hasta 5 intentos del SDK; mayor concentración en m10',
 '48haisladamente,10porversión1.22/1.19.8':'48 h de forma aislada, 10 por versión 1.22/1.19.8','20/20aprobados':'20/20 aprobados',
 'luego5recuperaciones48h':'luego 5 recuperaciones a 48 h','5/5recuperacionesaprobadas':'5/5 recuperaciones aprobadas',
 'desempate,3repeticiones':'desempate, 3 repeticiones','25parejas/pico50/0violaciones':'25 parejas, pico de 50 y cero violaciones',
 '51funcionales+116unidad+1carga=168/168backend':'51 funcionales + 116 de unidad + 1 de carga = 168/168 backend',
 'competir50transacciones':'competir 50 transacciones','errorhistórico':'error histórico','de48h':'de 48 h','error3':'error 3',
 'Pico50':'Pico de 50','completed50/matched50/25parejas/0violaciones':'50 llamadas completas, 50 partidas MATCHED, 25 parejas y cero violaciones',
 'Recuperación48h':'Recuperación a 48 h','mide pico3':'mide pico de 3','conserva48h−1/48h':'conserva 48 h − 1 ms / 48 h',
 '51/51funcionales':'51/51 funcionales','con2palabras':'con 2 palabras','texto50palabras':'texto de 50 palabras',
 'fixtureSTANDARD coherente con4palabras':'fixture STANDARD coherente con 4 palabras','116/116unidad/adaptador y51/51emulador':'116/116 de unidad/adaptador y 51/51 de emulador',
 'delta31/30':'delta 31/30','prioridadtimestamp':'prioridad del timestamp','mismoautor':'mismo autor','promediohistórico70de60/80':'promedio histórico de 70 calculado de 60/80',
 'siendo50operaciones':'siendo 50 operaciones','de257casos':'de 257 casos',
 'Validación:51/51funcionales,116/116unidad/adaptador y1/1carga con50/50operaciones,50partidas,25parejas,pico50ycero violaciones':'Validación: 51/51 funcionales, 116/116 de unidad/adaptador y 1/1 de carga con 50/50 operaciones, 50 partidas, 25 parejas, pico de 50 y cero violaciones',
 'de100':'de 100','de429/503':'de 429/503','paraUI':'para UI','de3operaciones':'de 3 operaciones',
 '6de noviembre':'6 de noviembre','pico50':'pico de 50','pico3':'pico de 3','50MATCHED':'50 MATCHED',
 '25parejas':'25 parejas','0violaciones':'0 violaciones','50/50,50':'50/50, 50','50/50,25':'50/50, 25',
 'falló11/50':'falló 11/50','aprobaron50/50':'aprobaron 50/50','con3operaciones':'con 3 operaciones','y0rechazos':'y 0 rechazos','de0errores':'de 0 errores',
}
files=[*out.glob('*.md'),out/'revision/Investigacion_Firestore.md',out/'propuesta_producto/README.md']
def polish(s):
    # Código, enlaces y hashes no son prosa y deben permanecer literales.
    chunks=re.split(r'(```[\s\S]*?```|`[^`\n]*`|\]\([^\n)]*\))',s)
    for i in range(0,len(chunks),2):
        for a,b in replacements.items():chunks[i]=chunks[i].replace(a,b)
        chunks[i]=re.sub(r'(?<=[\wáéíóúñ]),(?=[A-Za-zÁÉÍÓÚÑáéíóúñ])',', ',chunks[i])
    return ''.join(chunks)
for p in files:p.write_text(polish(p.read_text(encoding='utf-8-sig')),encoding='utf-8')
p=out/'Matriz_Pruebas_y_Trazabilidad.md';s=p.read_text(encoding='utf-8')
s=re.sub(r'^\| HU 3\.5 Emparejamiento.*$', '| HU 3.5 Emparejamiento con otro jugador | Parejas pequeñas comprobadas; la carga de 50 solicitudes sigue fallando en la base. | Recuperación a 48 h aprobada en el cierre funcional: tres operaciones, cero rechazos, promedio histórico de 70 sobre 60/80. Se conserva el error transaccional histórico con causa exacta abierta. | Falta aceptar y validar de forma ampliada la propuesta de desempate. UI/cloud y causa histórica de TRANS-01 siguen pendientes. |',s,flags=re.M)
p.write_text(s,encoding='utf-8')
p=out/'evidencias/Cobertura.md';s=p.read_text(encoding='utf-8').replace('[Node Firestore](final-node20-firestore.json)','[Firestore funcional](final-firestore-functional.json), [Firestore carga](final-firestore-concurrency.json)')
s+='\nRevisión del 6 de noviembre: las tablas Node corresponden a los cierres actuales de unidad, funcional y carga. Android conserva la medición del 5 de noviembre, sin cambios de fuente ni nueva ejecución. La cobertura del perfil de carga se conserva aunque ese caso falle.\n';p.write_text(s,encoding='utf-8')
for name in ['Resumen_resultados.json','Defectos.json','Pendientes.json','Criterios_y_limites.json','Filas_5_6.json']:
    p=out/name;obj=json.loads(p.read_text(encoding='utf-8-sig'))
    def recur(v):
        if isinstance(v,str):return polish(v)
        if isinstance(v,list):return [recur(x) for x in v]
        if isinstance(v,dict):return {k:recur(x) for k,x in v.items()}
        return v
    p.write_text(json.dumps(recur(obj),ensure_ascii=False,indent=2),encoding='utf-8')
# Conservar la fecha histórica del inventario y registrar aparte el entorno de la revisión.
p=out/'evidencias/Entorno.json';env=json.loads(p.read_text(encoding='utf-8'))
env['revision_2026_11_06']={'firestore_emulator':'1.22.0','jar_sha256':'9b6498b7f62714d67f48f59b3818883cd682dbcd46b9f59511de81c97bb5166c','node':'20.19.0','jdk':'21.0.9','firebase_cli':'14.22.0','metadata':['final-node20-unit.json','final-firestore-functional.json','final-firestore-concurrency.json'],'android':'Medición previa del 5 de noviembre conservada; sin cambios de código ni ejecución nueva','previous_emulator_comparison':'1.19.8, controles r08/r09','isolation':'Instancias nuevas para funcional/carga, loopback y demo-inkr8; no builds Android en paralelo. No mide capacidad cloud.'}
p.write_text(json.dumps(env,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['validate_delivery.py','build_delivery.py','build_cfg.py','run_logged.py']:shutil.copy2(root/'work'/name,out/'herramientas'/name)
shutil.copy2(pathlib.Path(__file__),out/'herramientas/revision/polish_delivery.py')
print('Prosa, resumen, entorno y herramientas actualizados; logs y fuentes preservados.')
