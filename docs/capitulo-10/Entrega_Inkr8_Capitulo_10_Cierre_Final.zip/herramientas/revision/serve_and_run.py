import argparse,datetime,hashlib,json,os,pathlib,shutil,socket,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
p=argparse.ArgumentParser();p.add_argument('--jar',required=True);p.add_argument('--repo',default='work/backend');p.add_argument('--mode');p.add_argument('--repeat',type=int,default=1);p.add_argument('label');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[2];repo=root/a.repo;folder=root/'outputs/evidencias/revision'/a.label;folder.mkdir(parents=True,exist_ok=True)
node=root/'work/tools/node-v20.19.0-win-x64/node.exe';java=root/'work/tools/jdk-21.0.9+10/bin/java.exe';jar=pathlib.Path(a.jar).resolve()
with socket.socket() as s:
    if s.connect_ex(('127.0.0.1',8080))==0:raise RuntimeError('Port 8080 busy: do not share emulator experiments')
server_cmd=[str(java),'-Dgoogle.cloud_firestore.debug_log_level=FINE','-Duser.language=en','-jar',str(jar),'--host','127.0.0.1','--port','8080','--project_id','demo-inkr8','--single_project_mode','--rules',str(repo/'firestore.rules')]
env=os.environ.copy();env.update(PATH=str(node.parent)+os.pathsep+env['PATH'],FIRESTORE_EMULATOR_HOST='127.0.0.1:8080',GCLOUD_PROJECT='demo-inkr8',CAP10_EVIDENCE_DIR=str(folder),CI='true',NO_COLOR='1')
if a.mode:env['CAP10_CONTROL_MODE']=a.mode
command=a.command[1:] if a.command and a.command[0]=='--' else a.command
if command[0]=='node':command[0]=str(node)
meta={'label':a.label,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'server_command':server_cmd,'test_command':command,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'mode':a.mode,'repeat':a.repeat,'cwd':str(repo),'results':[]}
with (folder/'emulator.log').open('w',encoding='utf-8') as serverlog:
    server=subprocess.Popen(server_cmd,cwd=repo,env=env,stdout=serverlog,stderr=subprocess.STDOUT)
    try:
        ready=False
        for _ in range(600):
            if server.poll() is not None:raise RuntimeError('Emulator exited during start')
            with socket.socket() as s:
                if s.connect_ex(('127.0.0.1',8080))==0:ready=True;break
            time.sleep(.1)
        if not ready:raise RuntimeError('Emulator did not open local port')
        for i in range(a.repeat):
            t=time.perf_counter();filename=f'run-{i+1:02d}.log'
            with (folder/filename).open('w',encoding='utf-8') as log:
                result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
            meta['results'].append({'run':i+1,'exit_code':result.returncode,'duration_seconds':time.perf_counter()-t,'log':filename})
            for pattern in ['AC03_50_solicitudes.json','control-*.json','trace.json']:
                for file in folder.glob(pattern):shutil.copy2(file,folder/(f'run-{i+1:02d}-'+file.name))
            print(meta['results'][-1],flush=True)
    finally:
        server.terminate()
        try:server.wait(timeout=8)
        except subprocess.TimeoutExpired:server.kill();server.wait()
meta['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(folder/'experiment.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps(meta,indent=2));sys.exit(max(r['exit_code'] for r in meta['results']))
