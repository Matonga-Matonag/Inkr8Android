import collections,csv,datetime,hashlib,json,pathlib,re,shutil,subprocess,zipfile
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs';ev=out/'evidencias';review=out/'revision';review.mkdir(exist_ok=True)
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def save(p,x):(out/p).parent.mkdir(parents=True,exist_ok=True);(out/p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def write(p,s):(out/p).write_text(s,encoding='utf-8')
def table(h,rs):
    clean=lambda v:str(v).replace('|','&#124;').replace('\n','<br>')
    return '| '+' | '.join(h)+' |\n|'+'|'.join('---' for _ in h)+'|\n'+'\n'.join('| '+' | '.join(clean(v) for v in r)+' |' for r in rs)+'\n'
def countlog(p):
    text=(out/p).read_text(encoding='utf-8');return {k:int(re.search(r'^# '+k+r' (\d+)$',text,re.M)[1]) for k in ['tests','pass','fail','skipped']}
cases=load(pathlib.Path('Casos_ejecutados.json'));s=load(pathlib.Path('Resumen_resultados.json'));q=load(pathlib.Path('evidencias/AC03_50_solicitudes.json'));remote=load(pathlib.Path('evidencias/revision/Remotos_y_ramas.json'))
assert len(cases)==257 and collections.Counter(c['result'] for c in cases)=={'Ejecutado aprobado':256,'Ejecutado fallido':1}
assert all(r['new_local_branch']=='pruebas/capitulo-10' and not r['remote_changed_since_tested_base'] for r in remote['rows'])
assert countlog(pathlib.Path('evidencias/revision/p05-propuesta-functional/run-01.log'))['pass']==51
assert countlog(pathlib.Path('evidencias/revision/p06/p06-propuesta-unit.log'))['pass']==116
assert countlog(pathlib.Path('evidencias/revision/p07-propuesta-final-load/run-01.log'))['pass']==1
proposal_folder=out/'propuesta_producto';proposal_folder.mkdir(exist_ok=True)
repo=root/'work/propuesta_backend';patch=subprocess.check_output(['git','diff','--binary','--full-index','HEAD','--','functions/src/data/repository/matchmaker.ts'],cwd=repo)
(proposal_folder/'contencion_empates.patch').write_bytes(patch)
shutil.copy2(repo/'functions/src/data/repository/matchmaker.ts',proposal_folder/'matchmaker.ts')
pq=load(pathlib.Path('evidencias/revision/p07-propuesta-final-load/AC03_50_solicitudes.json'))
pm={'base':s['patches'][0]['base'],'applied_to_main':False,'published':False,'source_changed':['functions/src/data/repository/matchmaker.ts'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'policy_change':'Preferir vecino adyacente solamente dentro del timestamp mínimo empatado; mantener orden entre timestamps y todas las guardas transaccionales','validation':{'unit':116,'functional':51,'concurrency_cases':1,'backend_cases_passed':168,'final_load':{k:pq[k] for k in ['attempted','completed','matched','verifiedPairs','peakActiveOperations','violations']},'previous_repetitions':'p04: tres perfiles aprobados de 50 operaciones, separados del total final'},'decision_missing':'Equipo debe aceptar política de desempate; validar producción/cloud y cargas heterogéneas antes de declarar garantía general'}
save(pathlib.Path('propuesta_producto/Metadatos.json'),pm)
with zipfile.ZipFile(out/'Entrega_Inkr8_Capitulo_10.zip') as z:
    before=z.read('codigo/backend/functions/integration/capitulo10.firestore.test.cjs').decode('utf-8').replace('\r\n','\n')
after=(root/'work/backend/functions/integration/capitulo10.concurrency.test.cjs').read_text(encoding='utf-8');marker="test('AC03-C01";before=marker+before.split(marker,1)[1];after=marker+after.split(marker,1)[1]
assert before==after
split=load(pathlib.Path('evidencias/revision/Separacion_carga.json'));split.update(body_sha256_before=hashlib.sha256(before.encode()).hexdigest(),body_sha256_after=hashlib.sha256(after.encode()).hexdigest(),same_body=True,normalization='UTF-8 y LF; cuerpo completo de AC03 sin cabecera compartida de fixtures',original_source='ZIP de entrega anterior conservado');save(pathlib.Path('evidencias/revision/Separacion_carga.json'),split)
s.update(date_lima='2026-11-06',product_conformity='Base parcial: carga falla; propuesta de desempate validada aparte, pendiente decisión. AC-02 cuota/disponibilidad, ELO y UI/IA real siguen abiertos.',proposal=pm,remote_check=remote,final_passed=256,final_failed=1,android_reexecution='No repetida: fuentes/patch sin cambios; se conserva medición89/89 del5nov',technical_review='Revisión cerrada como expediente; no certificación docente ni conformidad integral del producto')
save(pathlib.Path('Resumen_resultados.json'),s)

# Actualizar hallazgos; mantener el histórico del fallo sin sustituirlo por el diagnóstico aprobado.
defects=load(pathlib.Path('Defectos.json'))
for d in defects:
    if d['id']=='LOAD-01':
        d.update(evidence='evidencias/final-firestore-concurrency.log; evidencias/AC03_50_solicitudes.json; revisión r01..r06 y propuesta p04/p05/p07',observed=f'Base final: {q["completed"]}/50 llamadas aprobadas, {q["matched"]} partidas MATCHED, {q["verifiedPairs"]} parejas, pico50, cero violaciones en resueltas. Propuesta aparte:50/50,50MATCHED,25parejas,0violaciones.',cause='Contención confirmada en el emulador: control mínimo sin Inkr8 shared-counter falló11/50; independientes, parejas y shared-season aprobaron50/50. Traza real concentra lecturas en m10. El recorrido de candidatos amplifica contención; no se atribuye causa exclusiva al emulador ni se extrapola a cloud.',state='Abierto en base. Mitigación de producto candidata validada en copia aislada; no aplicada.',action='Revisar y aceptar política de desempate de propuesta_producto/contencion_empates.patch; validar cloud autorizado y tráfico heterogéneo. Mantener perfil50 y todas las aserciones.')
    if d['id']=='TRANS-01':
        d.update(evidence='Fallo histórico en entrega_anterior/final-node20-firestore.log; r07/r08:20repeticiones limpias; r09:5trascarga; final-firestore-functional.log y recuperacion_48h.json',observed='Histórico: INVALID_ARGUMENT Transaction is invalid or closed.25diagnósticos posteriores aprobados antes del ajuste; cierre funcional51/51 aprobado con3operaciones solapadas y0rechazos. Se añadió promediohistórico70de60/80.',cause='Origen observado: servidor/SDK transaccional. Causa exacta del error3 no reproducida ni demostrada. Problema de fixture confirmado: Promise.all rechazaba sin esperar las otras operaciones y permitía limpieza prematura; se cambió a allSettled con exigencia de0errores. La carga se aisló en otra instancia.',state='Mitigación de pruebas verificada; causa exacta histórica sigue abierta, no se declara eliminación universal.',action='Conservar error histórico. Si reaparece, guardar trazas de las tres solicitudes y servidor; aislar SDK/emulador. No reintentar indiscriminadamente todo INVALID_ARGUMENT ni cambiar negocio sin evidencia.')
save(pathlib.Path('Defectos.json'),defects)
dm='# Registro de defectos y acciones\n\nActualización6de noviembre. Los resultados de base y propuesta se mantienen separados. Un diagnóstico aprobado no borra un fallo anterior.\n\n'
for d in defects:dm+='## '+d['id']+' '+d['nature']+'\n\n'+table(['Campo','Detalle'],[[k,d[k]] for k in ['requirement','evidence','reproduction','expected','observed','severity','cause','state','action']])+'\n'
write(pathlib.Path('Defectos.md'),dm)

fixes=[['Separación de carga','El cuerpo de AC03 se movió intacto a capitulo10.concurrency.test.cjs; SHA del cuerpo coincide con la entrega previa. Instancia nueva para funcional y carga.','Pico50 y aserciones completed50/matched50/25parejas/0violaciones conservadas.'],['Recuperación48h','Promise.allSettled espera las3operaciones; se exige0rechazos y se mide pico3. Se conserva48h−1/48h, resultado y rating único; se añadió Merit inalterado.','51/51funcionales; errorhistórico no borrado.'],['Datos CN','ON_TOPIC con2palabras; partida expirada creada realmente antes del cambio de temporada; Game/Word completos en Pedro/Jean; texto50palabras y fixtureSTANDARD coherente con4palabras.','116/116unidad/adaptador y51/51emulador.'],['Regresiones de propuesta','Siete casos nuevos: delta31/30, prioridadtimestamp antiguo, mismoautor, modo incompatible, perfil cerrado, promediohistórico70de60/80.','Aprobados en base y copia con propuesta.']]
experiment_rows=[['r01','Emulador1.22, producto original','6/50 llamadas sin error;50solapadas; falla'],['r02','50transacciones independientes, sin Inkr8','50/50'],['r03','50independientes con escritura compartida seasons/s0','50/50; no basta por sí sola para atribuir el fallo'],['r04','50operaciones sobre25pares independientes','50/50'],['r05','50incrementos sobre1documento, sin Inkr8','11/50;39ABORTED, sin bajar concurrencia'],['r06','Traza SDK del producto original','45ABORTED; hasta5intentosSDK; hotspotm10'],['r07/r08','48haisladamente,10porversión1.22/1.19.8','20/20aprobados'],['r09','Carga original y luego5recuperaciones48h','Carga falla;5/5recuperacionesaprobadas'],['p04','Solo desempate,3repeticiones carga original','3×50/50;25parejas/pico50/0violaciones cada vez'],['p05/p06/p07','Cierre propuesta, sin sumar a base','51funcionales+116unidad+1carga=168/168backend']]
invest='# Investigación de Firestore\n\nSe mantuvieron50solicitudes, datos válidos con timestamps empatados, solapamiento medido y las aserciones originales. Se contrastaron dos versiones del emulador, controles mínimos y una copia aislada del producto.\n\n'+table(['Ensayo','Variable / operación','Resultado'],experiment_rows)+'\n## Causa y alcance\n\nLa carga falla por contención transaccional observada en este entorno. El control mínimo sin Inkr8 también falla al competir50transacciones por un documento; los controles independientes y por parejas aprueban. La traza del recorrido original concentra lecturas en pocos candidatos. La mejora con un único cambio de orden de desempate demuestra que ese recorrido contribuye al problema en este perfil. No demuestra que todo error sea del producto ni que toda contención sea exclusiva del emulador. Los datos empatados son válidos y permanecieron iguales.\n\nFirebase documenta diferencias transaccionales del emulador y demoras de liberación de bloqueos bajo escrituras concurrentes. Sus SDK reintentan un número finito de veces ante contención. Estas limitaciones apoyan el diagnóstico, sin sustituir los controles ejecutados. [Emulador](https://firebase.google.com/docs/emulator-suite/connect_firestore#transactions), [contención](https://firebase.google.com/docs/firestore/transaction-data-contention).\n\nEl errorhistórico de48h procede de una operación transaccional que el servidor reportó inválida/cerrada. No se encontró un cálculo incorrecto del reloj ni un cambio indebido de temporada. Su causa exacta no se reprodujo en25diagnósticos posteriores ni en la suite funcional final. El ajuste de fixture evita abandonar operaciones en curso cuando una falla y evita compartir la instancia de carga; no es prueba de eliminación universal del error3.\n\n## Correcciones de prueba y datos\n\n'+table(['Cambio','Qué se hizo','Verificación'],fixes)+'\n## Reproducción de controles\n\nDesde la carpeta de trabajo de esta entrega, por ejemplo:\n\n```powershell\npython work/revision/serve_and_run.py --jar work/revision/cloud-firestore-emulator-v1.22.0.jar --mode shared-counter control -- node --test functions/integration/revision.controls.test.cjs\n```\n\nEl helper abre exclusivamente loopback/demo-inkr8, conserva comando, hash del JAR, log de servidor y resultado. Cambiar mode por independent/shared-season/pairs reproduce los otros controles; siguen siendo50operaciones. Los comandos originales de cada experimento están en `evidencias/revision/<ensayo>/experiment.json`. No forman parte del denominador final de257casos ni de la aportación individual.\n'
write(pathlib.Path('revision/Investigacion_Firestore.md'),invest)
write(pathlib.Path('propuesta_producto/README.md'),'# Propuesta de producto separada\n\n**No aplicada a la base ni publicada.** Base backend `'+pm['base']+'`, rama local pruebas/capitulo-10. El parche solo modifica matchmaker.ts: da preferencia a vecinos adyacentes dentro del grupo del timestamp mínimo empatado. Conserva prioridad entre timestamps y guardas de autor, modo, perfil, temporada y delta≤30. El experimento que eliminaba escrituras de temporada se descartó; no está en el parche.\n\nValidación:51/51funcionales,116/116unidad/adaptador y1/1carga con50/50operaciones,50partidas,25parejas,pico50ycero violaciones; tres repeticiones anteriores del mismo perfil también aprobaron. Los tests y aserciones son los mismos que en la base. No se suman estos resultados a los de la base.\n\nDecisión pendiente: aceptar la nueva política de desempate. La paridad puede cambiar entre snapshots, hay fallback para candidatos incompatibles y se conserva la ventana de100; no es una reserva de pareja predeterminada. Faltan cargas heterogéneas/>100 y entorno cloud autorizado para prometer comportamiento general. [Revisión independiente](../revision/Revision_Propuesta.md).\n\nDesde una copia de backend con el parche de pruebas ya aplicado:\n\n```powershell\ngit apply --check C:/ruta/entrega/propuesta_producto/contencion_empates.patch\ngit apply C:/ruta/entrega/propuesta_producto/contencion_empates.patch\nnpm --prefix functions test\n# Ejecutar Run-Firestore.ps1 como indica README_Ejecucion.md, con emulador nuevo por suite.\n```\n\nEl archivo matchmaker.ts adjunto facilita revisión; aplicar el patch mantiene una comparación verificable. No se incluyen cambios ELO ni recuperación de429/503.\n')

# Causas/estados actuales en matrices y filas, sin mover identidades ni referencias anteriores.
limits='Carga original aún falla; propuesta separada pendiente de aceptación. Recuperación48h aprobó en cierre funcional; causa exacta del fallo histórico sigue abierta. UI/cloud no acreditados.'
for filename in ['Matriz_Pruebas_y_Trazabilidad.json','Criterios_y_limites.json']:
    rows=load(pathlib.Path(filename))
    for r in rows:
        if r.get('HU')=='HU 3.5':
            if 'limite' in r:r['limite']=limits
            if 'fallo_comprobado_o_carencia' in r:r['fallo_comprobado_o_carencia']='48h−1/48h y promedio70de60/80 comprobados en emulador; pico3/0rechazos en recuperación. Histórico transaccional permanece registrado.';r['pendiente_para_cierre']=limits
    save(pathlib.Path(filename),rows)
    if filename.startswith('Matriz_'):
        with (out/'Matriz_Pruebas_y_Trazabilidad.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for name in ['Matriz_Pruebas_y_Trazabilidad.md','Filas_5_3_y_5_6.md','Guias_Sustentacion.md']:
    p=out/name;text=p.read_text(encoding='utf-8');text=text.replace('La resolución de 48h de HU 3.5 aprobó en baseline y diagnóstico aislado, pero falló en la última suite completa: TRANS-01 sigue abierto.','La recuperación48h aprobó en la suite funcional final. Se conserva el fallo histórico y su causa exacta continúa abierta; la carga se documenta por separado.')
    text+='\nRevisión6de noviembre: [criterios desglosados](revision/Criterios_Demostrados.md), [auditoría de seis paquetes](revision/Auditoria_Rubrica.md) e [investigación](revision/Investigacion_Firestore.md). HU trazada no equivale a criterio integral demostrado. La base conserva el fallo de carga; la propuesta está separada.\n';p.write_text(text,encoding='utf-8')

pending=load(pathlib.Path('Pendientes.json'))
for p in pending:
    if p['id']=='P-01':p['action']='Wong debe aceptar o rechazar cada frontera concreta de CN con sus campos/particiones, incluyendo expresamente el helper privado hasMetadata de Renzo; confirmar reparto sin atribuir trabajo pasado.'
    if p['id']=='P-06':p.update(cause='Contención reproducida en base y en control mínimo; propuesta de desempate pasa perfil homogéneo.',action='Equipo decide la política de desempate de la propuesta separada; después validar cargas heterogéneas y cloud autorizado. No se cambia base para ocultar el fallo.')
    if p['id']=='P-12':p.update(cause='Fallo histórico de error3 no repetido en25diagnósticos y cierre funcional; fixture espera todas las operaciones.',action='Si reaparece conservar traza completa de3operaciones y servidor/SDK. La causa histórica no se cierra por no reproducirse; no reintentar ciegamente todo INVALID_ARGUMENT.')
save(pathlib.Path('Pendientes.json'),pending)
write(pathlib.Path('Registro_IA_y_Pendientes.md'),'# Registro de IA y pendientes\n\nCodex preparó/revisó tests, datos, CFG, matrices y documentos, ejecutó herramientas reales y contrastó logs. Esta revisión añadió tres auditorías de agentes Codex; no son revisiones humanas ni aportes de compañeros. La preparación sigue centralizada a solicitud de Marco. No constan confirmación docente, revisión humana ni reproducción/aporte individual. No se inventan porcentajes, firmas o evaluaciones por pares. La propuesta de producto se validó en una copia; no se aplicó a la base ni se publicó.\n\n'+table(['ID','Qué falta','Evidencia o decisión concreta / responsable'],[[p['id'],p['block']+': '+p['cause'],p['action']+' — '+p['owner']] for p in pending])+'\nEvidencias faltantes principales: autorización/criterio del docente por cadaCN; regla rating acordada y parámetros ELO; configuración/cuentas/dispositivo de prueba paraUI; muestras de evaluación real desde envío hasta persistencia/notificación paraAC-01; registro individual fechado de revisión, aporte y reproducción.\n')
suite=table(['Base final','Aprobados','Fallidos','Evidencia'],[['Dominio/adaptador',116,0,'[log](evidencias/final-node20-unit.log)'],['Firestore funcional',51,0,'[log](evidencias/final-firestore-functional.log)'],['Firestore carga50',0,1,'[log](evidencias/final-firestore-concurrency.log)'],['Android JVM (sin cambios; medición5nov)',89,0,'[XML/HTML](evidencias/android-app-tests-html/index.html)']])
chapter='''# Capítulo 10 Pruebas de software

Revisión técnica del6de noviembre de2026, Lima. Entrega local revisable con fallos y pendientes visibles. Las dos ramas locales son `pruebas/capitulo-10`; la comprobación de remotos no encontró commits nuevos respecto de backend993c6b0641a4a60603d87e251c90f51783460007 y frontendd6e8a432b5ad678cbe5db72d7ed1cbd7987f542c. No se publicó ni editó el informe compartido. La propuesta de producto se presenta aparte.

## 10.1 Estrategia, entorno y ejecución

Se mantiene la unión de19HU prioritarias y HU2.2 adicional justificada por validación de escritura. Se usa5.1 como identidad canónica, se conserva5.3/5.6 y sus referencias al9, y se rechaza ASR E2:E3 para Google. La rúbrica D18 exige por integrante CB V≥5, CN≥5entradas y un método unitario con≥4casos, además de participación real. El informe fuente sigue siendo la copia del5nov; no se mezcló una versión nueva.

Los patrones de Wong se aplican como preparación–acción–aserción, errores concretos y efectos prohibidos. La comparación de una constante o constructor DTO en la suite histórica de60métodos no se trata como prueba funcional del criterio. Se distinguen HU trazada, cláusula local comprobada y criterio integral con UI/servicio real.

Entorno de cierre backend: Windows, Node20.19.0/npm10.8.2, TypeScript5.9.3, FirebaseCLI14.22.0, Firestore emulador1.22.0 fijado por hash y JDK21.0.9. Se conservan comparaciones contra1.19.8. Proyecto exclusivo demo-inkr8, host loopback. La funcional y la carga se ejecutan en procesos de emulador diferentes; --test-concurrency=1 ordena archivos funcionales y no reduce las50operaciones del perfil. Android conserva89/89 y JaCoCo0.8.14 de la ejecución offline del5nov porque su código/patch no cambió; no se presenta como una nueva ejecución del6nov.

'''+suite+'''
Hay257casos distintos en la base final:256aprobados y1fallido, sin sumar diagnósticos ni la propuesta. La corrección de fixtures incluyó esperar las3operaciones48h con allSettled y exigir0rechazos/pico3, separar instancias, usar una partida genuina de temporada anterior, Game/Word completos y payload50palabras. Se incorporaron siete regresiones de elegibilidad, prioridad e historial. [Investigación y resultados](revision/Investigacion_Firestore.md).

AC-03 conserva50solicitudes contra cola compartida y todas las aserciones: en la base9llamadas completaron,10partidas quedaron emparejadas en5parejas y no se observaron inconsistencias en las resueltas; el pico fue50. Se mantiene el fallo porque no se resolvieron las50. Una llamada puede resolver dos partidas, por lo que llamadas completadas y partidas emparejadas tienen denominadores distintos. El control mínimo de50incrementos sin Inkr8 también falla por contención; la traza muestra concentración de candidatos en el producto. No se concluye causa exclusiva ni capacidad cloud.

AC-04/05 mantienen evidencia de recompensa única y competencia por100Merit con99/100/101. AC-02 demuestra timeout controlado y persistencia/reintento, pero cuota/disponibilidad siguen sin reintento programado. AC-01 sigue pendiente sin IA real/entorno autorizado. AC-06 conserva discrepancia de ELO. Las duraciones de runners no sustituyen latencia de evaluación completa. Semana12 se usa como método, sin copiar umbrales de otro proyecto.

## 10.2 Caja blanca

Los seis CFG mantienen una convención coherente de if, ternarios y cortocircuitos; llamadas de biblioteca atómicas y callbacks desconectados excluidos. Cada grafo contrasta E−N+2 con1+Σ(grado_salida−1), normaliza salidas y presenta una base factible de rango GF(2) igual aV. Las aristas ahora rotulan T/F y el extracto dailyWord incluye su cierre. No se inventa conteo de regiones ni se equipara cobertura de líneas con caminos.

'''
g=load(pathlib.Path('caja_blanca/grafos_y_caminos.json'));chapter+=table(['Paquete','Método','N','E','V/base/rango','Evidencia'],[[x['person'],x['symbol'],x['N'],x['E'],str(x['V']),f'[CFG](caja_blanca/{x["id"]}.md)'] for x in g])
chapter+='''
Los42casos de las bases aparecen aprobados en logs finales de unidad o funcional. La correspondencia entrada/camino se demuestra por código y datos, sin afirmar un trazador dinámico de nodos. [Auditoría independiente](revision/Auditoria_Rubrica.md).

## 10.3 Caja negra

Las seis fronteras reciben6/10/7/6/5/7campos efectivos: start, structureEvaluation, complete, adaptadorR8, hasMetadata y mapUser. Se excluye season sobrescrito, saldo persistido como supuesto argumento público y elementos de un mismo array como campos distintos. Las fichas documentan particiones, límites aplicables y expectativas de contrato/caracterización; no se exige a mappers validar reglas que no prometen. Las precondiciones de datos se corrigieron y ejecutaron.

La validación docente sigue pendiente para contratos internos. La consulta debe identificar cada frontera y mencionar expresamente que Renzo prueba un helper privado. No se declaran seisCN conformes a rúbrica por tener cinco propiedades. Los oráculos de recompensa/rating se rotulan como caracterización cuando el requisito no fija su tabla; ELO no se aprueba por coincidir con código.

## 10.4 Unitarias, cobertura y trazabilidad efectiva

Los métodos principales tienen24/10/9/12/5/7casos distinguibles:67en total. Se verifican datos, errores y efectos permitidos/prohibidos. ValidateWriting adicional distingue49/50/150/151 y200/201palabras, y10000/10001caracteres sin alterar el conteo de50palabras. El adaptador verifica SDK simulado, request y errores sin facturación; el archivo llega a100%líneas/ramas/funciones en la última unidad. Eso no demuestra OpenAI real.

[Cobertura](evidencias/Cobertura.md) conserva denominadores por archivo/módulo. Node instrumenta JS compilado y sus mapas se verifican contra TS y hashes; no se inventa porcentaje por método donde solo existe archivo. JaCoCo distingue bytecode y código generado. Los totales del runner que incluyen tests no se llaman cobertura de producto. Los módulos Android completos conservan cobertura baja aunque los métodos elegidos estén ejercitados.

La [matriz](Matriz_Pruebas_y_Trazabilidad.md) y el [desglose de38+2criterios](revision/Criterios_Demostrados.md) separan evidencia local de criterio integral.19HU trazadas y seis históricamente enlazadas al10 no equivalen a19o6HU integralmente comprobadas. No se acredita E2E de UI/IA. Los negativos3.6/3.8/3.9 que solo comparan constantes permanecen explícitamente no demostrados funcionalmente. Las fichas no atribuyen autoría/reproducción humana inexistente.

## 10.5 Defectos, propuesta y cierre

'''+table(['Hallazgo','Estado final'],[[d['id'],d['state']] for d in defects])+'''
La carga sigue fallando en la base; la propuesta separada solo cambia la preferencia dentro del timestamp mínimo empatado. Aprobó116/116unidad,51/51funcional y1/1carga50, además de tres perfiles anteriores de50/50. No está aplicada ni publicada y sus168casos backend no se suman a la base. Cambia una política de desempate: el equipo debe aceptarla. No promete toda cola heterogénea, ventana>100 ni cloud. [Parche y justificación](propuesta_producto/README.md).

El error histórico48h no reapareció en25diagnósticos y la suite funcional actual; se corrigió el ciclo de espera/aislamiento de pruebas. Su causa exacta transaccional permanece abierta y no se etiqueta producto corregido por una repetición aprobada. [Defectos completos](Defectos.md).

Pendientes concretos: aceptación docente de cadaCN y reparto; regla ELO acordada; configuración/cuentas/dispositivo y fallos inducidos deUI; muestras reales de evaluación completa paraAC-01; política de recuperación429/503; aceptación/validación ampliada de la propuesta; revisión, aportes y reproducción individual fechados. [Registro](Registro_IA_y_Pendientes.md). El expediente técnico se entrega revisado; el producto y la rúbrica no se certifican íntegramente conformes.
'''
write(pathlib.Path('Capitulo_10_Borrador.md'),chapter)

repro='''# Reproducción de la revisión técnica

Bases y parches están en codigo/. Backend993c6b0641a4a60603d87e251c90f51783460007; frontendd6e8a432b5ad678cbe5db72d7ed1cbd7987f542c. Ambas ramas locales pruebas/capitulo-10. Los remotos fueron comprobados sin cambios; fuentes de negocio de la base permanecen intactas. El parche de producto está separado.

## Backend base

Preparar Node20.19.0/npm10.8.2, JDK21 y FirebaseCLI14.22.0. Aplicar codigo/backend.patch a una copia del ZIP base o checkoutdelSHA; npm ci usa el lockfile conservado.

```powershell
git apply --check C:/ruta/entrega/codigo/backend.patch
git apply C:/ruta/entrega/codigo/backend.patch
npm --prefix functions ci
npm --prefix functions test
npm --prefix functions run test:coverage
```

Fijar el JAR1.22.0 con SHA256 `9b6498b7f62714d67f48f59b3818883cd682dbcd46b9f59511de81c97bb5166c`, desde [descarga oficial](https://storage.googleapis.com/firebase-preview-drop/emulator/cloud-firestore-emulator-v1.22.0.jar). Su procedencia está registrada en evidencias/revision/emulator122.json. LaCLI14.22 admite FIRESTORE_EMULATOR_BINARY_PATH. Alternativamente seguir los comandos exactos de losJSON de ejecución.

```powershell
$env:FIRESTORE_EMULATOR_BINARY_PATH = 'C:/herramientas/cloud-firestore-emulator-v1.22.0.jar'
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:coverage"
```

Son dos instancias nuevas:51casos funcionales y1carga. No omitir el segundo comando. Run-Firestore.ps1 coordina ambas y devuelve1si cualquiera falla. Puede recibir -Node conrutaabsolutaNode20, -FirebaseCli conrutaalbinariofirebase.js, -EmulatorBinary y -EvidenceDirectory. El cierre base espera un fallo de carga; no es un error de instalación. Todos los efectos/errores y50intervalos se guardan al establecer CAP10_EVIDENCE_DIR. Las guardas solo permiten loopback y proyecto demo-inkr8; las suites limpian sus fixtures emulados.

Los archivos funcionales corren en serie para no limpiar datos de otro test. Dentro del perfil siguen existiendo50operaciones solapadas. El caso48h ahora espera las3operaciones y exige0errores/pico3antes de pasar. Los controles y trazas diagnósticos tienen comandos en revision/Investigacion_Firestore.md yJSON por experimento; no se suman al total final.

## Propuesta aparte

Aplicar únicamente en otra copia después del parche de pruebas. Ver propuesta_producto/README.md. Se reejecutaron116unidad,51funcionales y1carga:168/168backend en copia de propuesta. Los hashes del cuerpo de AC03 coinciden con la base/entrega anterior. No usar sus aprobaciones para reemplazar el fallo de la base.

## Android y cobertura

Aplicar codigo/frontend.patch alSHA indicado. JDK21, Gradlewrapper9.1.0, SDK36/BuildTools36.0.0; configurar JAVA_HOME/ANDROID_HOME. Ejecutar:

```powershell
.\gradlew.bat :domain:test :app:testDebugUnitTest --offline --no-daemon --max-workers=2
.\gradlew.bat :domain:jacocoTestReport :app:jacocoDebugUnitTestReport --offline --no-daemon --max-workers=2
```

Si falta caché, preparar dependencias sin --offline y repetirlo. Android no cambió en esta revisión y se conserva la ejecución89/89del5nov conXML/HTML auténticos; no se la fecha como nueva. No requiere claves para testsJVM: no equivale a login Google real ni pantallas renderizadas.

LosV8 actuales están en evidencias/node20-v8-cierre y su mapa en verificacion_mapeo_cobertura.json. Los reportes por archivo yJaCoCo están en evidencias/Cobertura.md. Los archivos herramientas/permiten verificar y reconstruir con el layoutdocumentado; revision/contiene auditorías y controles. No hubo publicación, despliegue ni llamadas facturables aOpenAI. La participación individual y validación docente siguen pendientes.
'''
write(pathlib.Path('README_Ejecucion.md'),repro)
main='# Entrega revisada Inkr8 capítulo10\n\nRevisión6de noviembre; ramas locales pruebas/capitulo-10. Remotos sin cambios respecto de losSHAprobados. Se preservó el ZIP anterior y se entrega una revisión con nombre distinto.\n\n'+suite+'\nBase:257casos distintos,256aprobados y1fallido. La carga sigue fallando; el caso48h aprobó en la suite funcional, con fallo histórico y causa exacta aún registrados. Seis paquetes preparados,67unitarias y42caminos, sin confirmar conformidad docente ni aportes individuales.\n\nPropuesta separada:unarchivo de producto,168/168backend, carga50/50con25parejas/pico50; no aplicada a la base. Requiere aceptación del desempate y validación ampliada.\n\n'+table(['Documento','Contenido'],[['[Capítulo10](Capitulo_10_Borrador.md)','Estrategia,6paquetes,ejecución y10.5actualizado'],['[Investigación Firestore](revision/Investigacion_Firestore.md)','Causas,controles,correcciones de fixtures y resultados'],['[Propuesta aparte](propuesta_producto/README.md)','Parche de un archivo y justificación, sin mezclar resultados'],['[Rúbrica](revision/Auditoria_Rubrica.md)','CB/CN/UT, límites y validación docente pendiente'],['[Criterios38+2](revision/Criterios_Demostrados.md)','Cláusulas locales vs criterio integral;HUtrazada no equivale a demostrada'],['[Matriz](Matriz_Pruebas_y_Trazabilidad.md)','CSV/JSONactualizados y relaciones muchosamuchos'],['[Filas5.3/5.6](Filas_5_3_y_5_6.md)','9originales+10ausentes+HU2.2justificada'],['[Reproducción](README_Ejecucion.md)','Comandos exactos, bases, parches y entorno'],['[Defectos](Defectos.md)','Abiertos, corregidos de test y causa histórica no confirmada'],['[IA y pendientes](Registro_IA_y_Pendientes.md)','Docente,ELO,UI/IAreal,participaciónindividual']])+'\n19HU prioritarias tienen traza relacionada; ninguna está cerradaE2E. Las seis previamente enlazadas al10tienen evidencia local y pendientes. Los reportes/validadores no sustituyen revisión humana. No se publicó nada.\n'
write(pathlib.Path('README_Entrega.md'),main)
# Procedencia del JAR y herramientas de esta revisión; fuera del parche de producto.
shutil.copy2(root/'work/revision/emulator122.json',ev/'revision/emulator122.json')
for name in ['serve_and_run.py','run_sequence.cjs','verify_split.py','refresh_review.py']:
    dest=out/'herramientas/revision';dest.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'work/revision'/name,dest/name)
print('Revisión documental actualizada; base257(256/1), propuesta168/168 separada')
