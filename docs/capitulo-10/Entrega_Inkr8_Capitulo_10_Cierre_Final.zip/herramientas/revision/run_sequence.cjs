const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const out=process.env.CAP10_EVIDENCE_DIR,steps=[['load',['--test','--test-name-pattern=AC03-C01','functions/integration/capitulo10.firestore.test.cjs']],...Array.from({length:5},(_,i)=>['48h-after-load-'+(i+1),['--test','--test-name-pattern=R8','functions/integration/firestore.test.cjs']])];
const result=[];
for(const [name,args] of steps){
  const start=new Date().toISOString(),log=path.join(out,name+'.log'),fd=fs.openSync(log,'w'),p=spawnSync(process.execPath,args,{env:process.env,stdio:['ignore',fd,fd]});fs.closeSync(fd);
  result.push({name,args,start_utc:start,exit_code:p.status,log:path.basename(log)});console.log(JSON.stringify(result.at(-1)));
}
fs.writeFileSync(path.join(out,'sequence.json'),JSON.stringify(result,null,2));process.exitCode=result.some(r=>r.exit_code!==0)?1:0;
