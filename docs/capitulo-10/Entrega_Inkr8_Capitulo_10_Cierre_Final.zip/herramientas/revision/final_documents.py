import csv,json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def save(p,o):(out/p).write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def table(headers,rows):
    clean=lambda v:str(v).replace('|','&#124;').replace('\n','<br>')
    return '| '+' | '.join(headers)+' |\n|'+'|'.join('---' for _ in headers)+'|\n'+'\n'.join('| '+' | '.join(map(clean,r))+' |' for r in rows)+'\n'
old='AC-03 a escala y estabilidad de recuperación 48h no cerrados; estudiar errores transaccionales y repetir tras diagnóstico/corrección acordados.'
new='La carga de 50 solicitudes sigue fallando en la base. Recuperación a 48 h aprobada en el cierre funcional; causa exacta del fallo histórico abierta. Propuesta de desempate separada y pendiente de aceptación/validación ampliada. UI/cloud no acreditados.'
p=out/'Filas_5_3_y_5_6.md';p.write_text(p.read_text(encoding='utf-8').replace(old,new),encoding='utf-8')
rows=load('Filas_5_6.json')
for r in rows:
    if r['Requisito / HU']=='HU 3.5':r['Resultado / estado']=r['Resultado / estado'].replace(old,new)
save('Filas_5_6.json',rows)
rows=load('Criterios_y_limites.json')
for r in rows:
    if r['HU']=='HU 3.5':r['fallo_comprobado_o_carencia']='Límite de 48 h − 1 ms / 48 h e idempotencia comprobados en emulador; tres operaciones y cero rechazos. REV-MATCH-07 confirma promedio histórico 70 calculado de 60/80. Se conserva el error transaccional histórico con causa exacta abierta.'
save('Criterios_y_limites.json',rows)
pending=load('Pendientes.json')
for p in pending:
    if p['id']=='P-02':p['action']='Cada uno de los seis integrantes debe aportar registro fechado de revisión de su ficha/código, cambio o aporte identificable (archivo/diff) y reproducción propia (comando, entorno, salida y resultado); confirmar el reparto. La ejecución del agente no acredita ese aporte.'
    if p['id']=='P-07':p['action']='Equipo/docente deben decidir si rige ELO con probabilidad esperada o el ajuste lineal actual. Si rige ELO, fijar K, fórmula, redondeo, empate y topes, con ejemplos de resultados esperados; si se conserva la regla propia, aprobar su tabla y corregir AC-06/RNF-024. Registrar decisión y después alinear código/documento y pruebas.'
save('Pendientes.json',pending)
p=out/'Registro_IA_y_Pendientes.md';intro=p.read_text(encoding='utf-8').split('| ID |',1)[0]
p.write_text(intro+table(['ID','Qué falta','Evidencia o decisión concreta / responsable'],[[r['id'],r['block']+': '+r['cause'],r['action']+' — '+r['owner']] for r in pending])+'\nEl desglose por criterio identifica las capturas, estados y operaciones que aún faltan: [38 criterios prioritarios y 2 adicionales](revision/Criterios_Demostrados.md). La aceptación docente debe referirse a cada frontera CN de las seis fichas, incluido el helper privado de Renzo.\n',encoding='utf-8')
defects=load('Defectos.json')
for d in defects:
    if d['id']=='TRANS-01':
        d['evidence']='evidencias/revision/entrega_anterior/final-node20-firestore.log; r07/r08: 20 repeticiones limpias; r09: 5 recuperaciones tras carga; evidencias/final-firestore-functional.log y evidencias/recuperacion_48h.json'
        d['observed']='Histórico: INVALID_ARGUMENT Transaction is invalid or closed. Los 25 diagnósticos posteriores aprobaron antes del ajuste; cierre funcional 51/51 aprobado con tres operaciones solapadas y cero rechazos. Se añadió REV-MATCH-07 con promedio histórico 70 calculado de 60/80.'
    if d['id']=='LOAD-01':
        d['observed']='Base final: 9/50 llamadas completas, 10 partidas MATCHED, 5 parejas, pico de 50 y cero violaciones observadas en las parejas resueltas. Propuesta aparte: 50/50 llamadas, 50 partidas MATCHED y 25 parejas, pico de 50 y cero violaciones.'
save('Defectos.json',defects)
labels={'requirement':'Requisito','evidence':'Evidencia','reproduction':'Reproducción','expected':'Esperado','observed':'Observado','severity':'Severidad','cause':'Causa','state':'Estado','action':'Acción'}
dm='# Registro de defectos y acciones\n\nActualización del 6 de noviembre. Los resultados de base y propuesta se mantienen separados. Un diagnóstico aprobado no borra un fallo anterior.\n\n'
for d in defects:dm+='## '+d['id']+' '+d['nature']+'\n\n'+table(['Campo','Detalle'],[[label,d[k]] for k,label in labels.items()])+'\n'
(out/'Defectos.md').write_text(dm,encoding='utf-8')
p=out/'revision/Investigacion_Firestore.md';s=p.read_text(encoding='utf-8')
for a,b in {'falla;5/5':'falla; 5/5','3×50/50;25':'3 × 50/50; 25','51funcionales+116unidad+1carga=168/168 backend':'51 funcionales + 116 de unidad + 1 de carga = 168/168 backend','competir50 transacciones':'competir 50 transacciones','siendo50 operaciones':'siendo 50 operaciones'}.items():s=s.replace(a,b)
s+='''
## Clasificación del origen

| Origen | Carga de 50 | Recuperación de 48 h |
|---|---|---|
| Producto | El recorrido original concentra candidatos; cambiar solo el desempate permite completar este perfil. Corrección candidata aparte. | No se ha demostrado un defecto de cálculo ni una corrección de producto para el error histórico. |
| Prueba | Se aisló la carga en otra instancia; su cuerpo y todas las aserciones permanecen iguales. | `Promise.all` podía dejar solicitudes activas tras un rechazo y permitir limpieza prematura. `allSettled` espera las tres y exige cero errores; no se acredita eliminación universal. |
| Datos | Los timestamps empatados son válidos y se conservaron. | No se encontró un error de reloj; los fixtures de temporada usados en CN se corrigieron de forma independiente. |
| Entorno | El control sin Inkr8 también agota reintentos por lock timeout. El comportamiento no certifica capacidad cloud. | El servidor/SDK informó transacción inválida/cerrada; la causa exacta sigue sin reproducirse. |

Evidencia principal: [carga base](../evidencias/AC03_50_solicitudes.json), [48 h y tres solicitudes](../evidencias/recuperacion_48h.json), [control mínimo](../evidencias/revision/r05-control-shared-counter/experiment.json), [traza del producto](../evidencias/revision/r06-product-trace/experiment.json), [propuesta final](../evidencias/revision/p07-propuesta-final-load/experiment.json). El índice de [evidencias de revisión](../evidencias/revision/LEEME.md) distingue ensayos exploratorios y resultados finales.
''';p.write_text(s,encoding='utf-8')
# Actualizar el índice procesable sin alterar grafos ni identidades personales.
fichas=load('paquetes/Seis_fichas.json');audit=load('revision/Auditoria_Rubrica.json')
for f,a in zip(fichas,audit['paquetes']):
    f['revision_tecnica']={'fecha_lima':'2026-11-06','rama':'pruebas/capitulo-10','campos_efectivos':len(f['cn_fields']),'auditoria':'revision/Auditoria_Rubrica.json','detalle_CN_final':a['CN'],'conformidad_docente_confirmada':False,'participacion_individual_acreditada':False}
save('paquetes/Seis_fichas.json',fichas)
criteria=load('revision/Criterios_Demostrados.json')['criterios']
with (out/'revision/Criterios_Demostrados.csv').open('w',encoding='utf-8-sig',newline='') as f:
    keys=list(criteria[0]);writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader()
    for c in criteria:writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in c.items()})
p=out/'revision/Criterios_Demostrados.md';s=p.read_text(encoding='utf-8');s+='\nVersiones procesables: [JSON](Criterios_Demostrados.json) y [CSV](Criterios_Demostrados.csv).\n';p.write_text(s,encoding='utf-8')
(out/'evidencias/revision/LEEME.md').write_text('''# Índice de evidencia de revisión

La base final se cuenta solo desde [unidad](../final-node20-unit.log), [funcional](../final-firestore-functional.log) y [carga](../final-firestore-concurrency.log), más Android previamente ejecutado. Total único 257: 256 aprobados y uno fallido. Las fechas/órdenes exactas están en los JSON compañeros de cada log.

La propuesta final se cuenta por separado: [p05 funcional](p05-propuesta-functional/run-01.log), [p06 unidad](p06/p06-propuesta-unit.log) y [p07 carga](p07-propuesta-final-load/run-01.log): 168/168, sin omitidos. p04 son tres repeticiones anteriores del mismo cambio mínimo; no crean más casos únicos.

r01..r06 contrastan entorno, transacciones mínimas y hotspots. r07/r08 son 20 ejecuciones aisladas de 48 h en dos versiones del emulador; r09 añade cinco recuperaciones después de carga. Estas 25 ejecuciones aprobadas preceden al ajuste de espera y no demuestran que ese ajuste elimine la causa histórica.

p01, p02 y p03 contienen ensayos intermedios de propuesta. El cambio experimental de seasonWrites fue restaurado y no forma parte del parche final. entrega_anterior preserva resultados reemplazados por los cierres actuales; no se suman al total nuevo. [Investigación y límites](../../revision/Investigacion_Firestore.md).
''',encoding='utf-8')
p=out/'herramientas/LEEME.md';s=p.read_text(encoding='utf-8');s+='\nLa revisión añade scripts bajo revision/. Deben ubicarse bajo work/revision/ en el layout indicado. Los generadores conservan la preparación de la entrega; las auditorías y el pulido final contienen revisión editorial adicional. Para reproducir resultados de pruebas, seguir README_Ejecucion.md; para verificar integridad, ejecutar validate_delivery.py. No es necesario regenerar documentos para ejecutar las suites.\n';p.write_text(s,encoding='utf-8')
shutil.copy2(root/'work/validate_delivery.py',out/'herramientas/validate_delivery.py')
shutil.copy2(pathlib.Path(__file__),out/'herramientas/revision/final_documents.py')
print('Índices y pendientes finales actualizados; CSV de 40 criterios exportado.')
