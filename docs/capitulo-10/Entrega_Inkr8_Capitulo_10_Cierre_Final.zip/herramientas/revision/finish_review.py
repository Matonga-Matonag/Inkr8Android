import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
validation=json.loads((out/'Validacion_Entrega.json').read_text(encoding='utf-8'))
assert validation['all_checks_passed']
shutil.copy2(pathlib.Path(__file__),out/'herramientas/revision/finish_review.py')
archive=out/'Entrega_Inkr8_Capitulo_10_Revision_Tecnica.zip'
excluded=lambda p:p.parent==out and (p.suffix=='.zip' or p.name.endswith('.sha256.txt') or p.name=='MANIFEST_SHA256.json')
manifest=[]
for p in sorted(out.rglob('*')):
    if p.is_file() and not excluded(p):manifest.append({'path':p.relative_to(out).as_posix(),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'MANIFEST_SHA256.json').write_text(json.dumps({'algorithm':'SHA-256','delivery':'Revision tecnica 2026-11-06','files':manifest},ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for item in manifest:z.write(out/item['path'],item['path'])
    z.write(out/'MANIFEST_SHA256.json','MANIFEST_SHA256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(manifest)+1
    for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(out/(archive.stem+'.sha256.txt')).write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
result={'archive':str(archive),'size_bytes':archive.stat().st_size,'files':len(manifest)+1,'sha256':sha,'zip_crc_and_all_manifest_hashes_verified':True,'validation_checks':len(validation['checks']),'original_zip_preserved':(out/'Entrega_Inkr8_Capitulo_10.zip').is_file()}
(root/'work/revision/empaquetado.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
