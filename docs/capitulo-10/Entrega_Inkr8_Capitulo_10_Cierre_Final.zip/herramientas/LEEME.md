# Herramientas del cierre final de Inkr8

El procedimiento vigente es README_Ejecucion.md. El validador actual es cierre/validate_final.py. Copiar herramientas/cierre a work/cierre dentro del layout documentado (outputs/ como hermana de work/); allí están los runners de Android, SDK y Firestore, la secuencia de cargas y los generadores del cierre. Los árboles de código/patches se usan como se indica en reproducción.

Los scripts build_delivery.py, build_cfg.py y los de revision/ conservan preparación de fases anteriores. No sustituir el modelo final ni ejecutar los empaquetadores antiguos para regenerar el cierre. Los documentos incluyen revisión editorial además de generación; el validador comprueba contenido/evidencia y parches sin ejecutar otra vez ni aprobar los tests rojos.

La preparación y revisión se entregan bajo responsabilidad del grupo, con apoyo IA declarado. Las herramientas y sus resultados no prueban participación individual.
