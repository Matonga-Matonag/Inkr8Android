import collections,copy,csv,hashlib,json,pathlib,re,shutil,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs';saved=root/'work/cierre/insumo'
def load(p,origin=out):return json.loads((origin/p).read_text(encoding='utf-8-sig'))
def save(p,v):(out/p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def csvout(p,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (out/p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})
oldcases=load('Casos_ejecutados.json',saved);oldnames={(c['repository'],c['name']):c for c in oldcases};byold={c['id']:c for c in oldcases}
BACK='993c6b0641a4a60603d87e251c90f51783460007';FRONT='d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c'
func='cierre/matchmaking/evidencias/base-functional-final/run-01.log';unit='evidencias/cierre/backend/base-unit-final.log';conf='cierre/matchmaking/evidencias/base-ac02-conformidad/run-01.log';loadlog='cierre/matchmaking/evidencias/base-50-final/run-01.log'
idregex=r'((?:UT|CB|CN)-[A-Z]{3}-\d{2}-C\d+|AC\d{2}-C\d+|ADAPT-\d+|REV-MATCH-\d+|CIERRE-CN-REN-C\d+|CIERRE-AC02-\d+-(?:ACTUAL|MANUAL|CONFORMIDAD)|MM-FUNC-(?:ODD\d+|\d+))'
def newcase(name,repo):
    source='';hu=[];tech='regresión';symbol='Ver fuente';person='Grupo';scope='Comprobación local; no certifica el criterio integral ni cloud'
    if name.startswith('CIERRE-CN-REN'):
        source='functions/integration/cierre.cn-renzo.test.cjs';hu=['HU 1.5'];tech='caja negra funcional sobre catálogo persistido';symbol='GetDailyHome.execute → FirebaseContentRepository.dailyWord';person='Renzo';scope='Cinco campos reales de catálogo y salida Home/caché; aceptación docente de esa frontera pendiente'
    elif name.startswith('CIERRE-AC02'):
        source='functions/integration/cierre.ac02.test.cjs';hu=['HU 2.3','HU 3.2'];tech='integración local / conformidad' if 'CONFORMIDAD' in name else 'integración local / caracterización';symbol='EvaluateGame.execute / recoverEvaluations / retry';person='Pedro';scope='Evaluador externo controlado; caracterización/manual no aprueban recuperación automática AC-02'
    elif name.startswith('MM-FUNC'):
        source='functions/integration/cierre.matchmaking.test.cjs';hu=['HU 3.5','HU 3.7'];tech='integración local / guardas';symbol='Matchmaker.pairCandidates / pair';person='Víctor';scope='Guardas y ventana real de100; los casos18/20 caracterizan una limitación preexistente'
    elif name.startswith('REV-MATCH'):
        source='functions/integration/revision.regression.test.cjs';hu=['HU 3.5','HU 3.7'];tech='integración local / regresión';symbol='FirebaseMatchRepository.match';person='Víctor';scope='Guardas, datos y recuperación local; no certifica ELO ni cloud'
    elif name.startswith(('CLI_HU','UI_HU','INT_HU')):
        n=re.search(r'HU(\d)(\d)',name);hu=[f'HU {n[1]}.{n[2]}'];person='Matías' if n[2]=='6' else 'Jean Carlo'
        if name.startswith('CLI_'):source='app/src/test/java/com/inkr8/presentation/ClienteNegativeFlowTest.kt';tech='JVM / fallo inducido';scope='Casos de uso/mapper/ViewModel reales con repositorios controlados; no pantalla ni servicio remoto'
        elif name.startswith('UI_'):source='app/src/androidTest/java/com/inkr8/presentation/Capitulo10VisualTest.kt';tech='UI instrumentada local';scope='Compose y ViewModel reales en AVD; repositorios controlados explícitos'
        else:source='app/src/androidTest/java/com/inkr8/presentation/Capitulo10LocalFirestoreTest.kt';tech='SDK Android / Firestore local / UI';scope='SDK, repositorio, reglas y emulador reales; inicialización/sesión controladas. Sin Google/OpenAI real'
        symbol='SessionViewModel.refresh / Inkr8Root' if n[2]=='6' else 'GameDto.toDomain / GameViewModel / GameScreen'
    return {'hu':hu,'techniques':tech,'symbol':symbol,'package':person,'environment':'Node20 y Firestore1.22 local' if repo=='backend' else scope,'evidence_role':'comportamiento','criterion_scope':scope,'test_source':'codigo/'+repo+'/'+source,'inputs':'Fixture y estímulo identificados en el nombre y en la fuente del caso; datos persistidos/simulados declarados en la evidencia','expected':'Aserciones literales de estado, mensaje, efectos y límites en la fuente; no se usa la salida del producto para calcular el esperado','forbidden_effects':'Los efectos prohibidos se comprueban en las aserciones: no repetir envío/cobro/recompensa ni inventar rating; consultar alcance concreto del caso'}
def finish(c,name,repo,suite,evidence,line,result,duration=None):
    c=copy.deepcopy(c) if c else newcase(name,repo)
    c.update(name=name,repository=repo,suite=suite,evidence=evidence,evidence_line=line,result=result,duration_ms=duration,commit=BACK if repo=='backend' else FRONT,branch_local='pruebas/capitulo-10',product_copy='base')
    source=c.get('test_source','');file=out/source
    if file.is_file():
        matches=[i for i,s in enumerate(file.read_text(encoding='utf-8-sig').splitlines(),1) if name in s]
        c['test_source_line']=matches[0] if matches else None
    if c['id'].startswith('CN-REN-01'):c.update(evidence_role='auxiliar_legacy',techniques='regresión auxiliar del helper privado; CN principal sustituida por Home observable')
    return c
def tap(path,suite,only_new_conformance=False):
    lines=(out/path).read_text(encoding='utf-8').splitlines();rows=[]
    for i,line in enumerate(lines):
        m=re.match(r'^(not ok|ok) \d+ - (.+)$',line)
        if not m:continue
        name=m[2]
        if only_new_conformance and 'CONFORMIDAD' not in name:continue
        old=oldnames.get(('backend',name));match=re.match(idregex,name);id=old['id'] if old else match[1] if match else None
        assert id,(name,path)
        c=copy.deepcopy(old) if old else newcase(name,'backend');c['id']=id
        dur=next((float(t[1]) for s in lines[i+1:i+8] if (t:=re.search(r'duration_ms: ([\d.]+)',s))),None)
        c=finish(c,name,'backend',suite,path,i+1,'Ejecutado fallido' if m[1]=='not ok' else 'Ejecutado aprobado',dur)
        c['command_metadata']='cierre/matchmaking/evidencias/'+path.split('/')[-2]+'/experiment.json' if '/evidencias/' in path and path.startswith('cierre/') else 'evidencias/cierre/backend/base-unit-final.json'
        rows.append(c)
    return rows
cases=tap(unit,'backend-unidad')+tap(func,'firestore-funcional')+tap(conf,'ac02-conformidad',True)+tap(loadlog,'firestore-carga50')
for file in sorted((out/'cierre/cliente/base-all-coverage-xml').glob('TEST*.xml')):
    doc=ET.parse(file).getroot()
    for t in doc.findall('testcase'):
        name=t.attrib['name'];old=oldnames.get(('frontend',name));m=re.match(r'(CLI_HU\d+_C\d+)',name)
        assert old or m,name
        c=copy.deepcopy(old) if old else newcase(name,'frontend');c['id']=old['id'] if old else m[1]
        c=finish(c,name,'frontend','android-jvm',file.relative_to(out).as_posix(),None,'Ejecutado fallido' if t.find('failure') is not None or t.find('error') is not None else 'Omitido' if t.find('skipped') is not None else 'Ejecutado aprobado',float(t.attrib.get('time',0))*1000)
        c['class']=t.attrib.get('classname');c['command_metadata']='cierre/cliente/base-all-coverage.json';cases.append(c)
for suite in ['visual','sdk']:
    data=load('cierre/ui/base-'+suite+'/resultado-directo.json')
    for row in data['cases']:
        name=row['name'];id=re.match(r'((?:UI|INT)_HU\d+_C\d+)',name)[1];c=newcase(name,'frontend');c['id']=id
        c=finish(c,name,'frontend','android-'+suite,row['evidence'],row['evidence_line'],'Ejecutado aprobado' if row['result']=='passed' else 'Ejecutado fallido')
        c['class']=row['class'];c['command_metadata']='cierre/ui/base-'+suite+'/resultado-directo.json';cases.append(c)
bycase={c['id']:c for c in cases};assert len(cases)==len(bycase)==323,(len(cases),collections.Counter(c['result'] for c in cases))
assert collections.Counter(c['result'] for c in cases)=={'Ejecutado aprobado':313,'Ejecutado fallido':10}
save('Casos_ejecutados.json',cases);csvout('Casos_ejecutados.csv',cases)
catalog=load('fuentes/catalogo_hu.json');allowed={h['id'] for h in catalog if h['in_priority_union']}|{'HU 2.2'};hmap={h['id']:h for h in catalog}
oldtrace=load('Matriz_Pruebas_y_Trazabilidad.json',saved);rows=[];seen=set()
for r in oldtrace:
    if r['caso'] not in bycase:continue
    c=bycase[r['caso']];r=copy.deepcopy(r);r.update(resultado=c['result'],evidencia=c['evidence']+((':'+str(c['evidence_line'])) if c['evidence_line'] else ''),fuente_test=c['test_source']+((':'+str(c['test_source_line'])) if c.get('test_source_line') else ''),entorno=c['environment'],rol_evidencia=c['evidence_role'])
    if r['caso'].startswith('CN-REN-01'):r.update(tecnica=c['techniques'],limite='Evidencia auxiliar del helper privado. CN principal: CIERRE-CN-REN-C01..C25, Home observable; aceptación docente pendiente.')
    rows.append(r);seen.add((r['HU'],r['caso']))
for c in cases:
    for hu in c.get('hu',[]):
        if hu not in allowed or (hu,c['id']) in seen:continue
        template=next(r for r in oldtrace if r['HU']==hu);r=copy.deepcopy(template)
        r.update(caso=c['id'],diseño='cierre/caja_negra/CN_Renzo_Observable.md' if c['id'].startswith('CIERRE-CN-REN') else 'cierre/cliente/Reporte_Cliente.md' if c['id'].startswith(('CLI_','UI_','INT_')) else 'cierre/decisiones/Decisiones_Pendientes.md' if c['id'].startswith('CIERRE-AC02') else 'cierre/matchmaking/Validacion_Final.md',simbolo=c['symbol'],paquete=c['package'],tecnica=c['techniques'],datos=c['inputs'],esperado=c['expected'],fuente_test=c['test_source']+((':'+str(c['test_source_line'])) if c.get('test_source_line') else ''),entorno=c['environment'],resultado=c['result'],evidencia=c['evidence']+((':'+str(c['evidence_line'])) if c['evidence_line'] else ''),limite=c['criterion_scope'],rol_evidencia=c['evidence_role'],criterio_alcance_del_caso=c['criterion_scope'])
        rows.append(r);seen.add((hu,c['id']))
assert {r['HU'] for r in rows}==allowed
save('Matriz_Pruebas_y_Trazabilidad.json',rows);csvout('Matriz_Pruebas_y_Trazabilidad.csv',rows)
# Current measured coverage: production file rows only, not runner totals including tests.
cov=[]
for label,path in [('base-unidad',unit),('base-funcional',func),('base-carga50',loadlog),('propuesta-unidad','evidencias/cierre/backend/propuesta-unit-final.log'),('propuesta-funcional','cierre/matchmaking/evidencias/propuesta-functional-final/run-01.log')]:
    for line in (out/path).read_text(encoding='utf-8').splitlines():
        parts=[s.strip() for s in line.removeprefix('#').split('|')]
        if len(parts)<5:continue
        scope=parts[0].replace('\\','/').removeprefix('functions/')
        if not scope.startswith('src/'):continue
        try:row={'report':label,'scope':scope,'line_pct':float(parts[1]),'branch_pct':float(parts[2]),'function_pct':float(parts[3]),'uncovered_lines':parts[4],'evidence':path,'tool':'Node20 native coverage / V8 and source maps','commit':BACK}
        except ValueError:continue
        cov.append(row)
save('evidencias/Cobertura_archivos.json',cov);csvout('evidencias/Cobertura_archivos.csv',cov)
androidcov=[]
for copyname in ['base','proposal']:
    for module in ['domain','app']:
        files=list((out/f'cierre/cliente/{copyname}-all-coverage-jacoco/{module}').glob('*.xml'));assert len(files)==1
        doc=ET.parse(files[0]).getroot()
        targets=[('módulo completo',doc)]+[(cl.attrib['name'],cl) for cl in doc.iter('class') if cl.attrib['name'] in ['com/inkr8/domain/policy/GamePolicy','com/inkr8/presentation/viewmodel/SessionViewModel','com/inkr8/presentation/viewmodel/GameViewModel','com/inkr8/data/mapper/DomainMappersKt']]
        for scope,node in targets:
            counts={}
            for counter in node.findall('counter'):
                yes,no=int(counter.attrib['covered']),int(counter.attrib['missed']);counts[counter.attrib['type']]={'covered':yes,'missed':no,'pct':round(100*yes/(yes+no),2) if yes+no else None}
            androidcov.append({'copy':copyname,'module':module,'scope':scope,'counters':counts,'evidence':files[0].relative_to(out).as_posix(),'measurement':'JVM JaCoCo, no UI instrumentation coverage'})
save('evidencias/Cobertura_Android.json',androidcov)
summary={'date_lima':'2026-11-06','scope':'19 HU prioritarias + HU 2.2 justificada','review_responsibility':'Grupo, con asistencia IA académica; participación y reproducción individual no confirmadas','branches':['pruebas/capitulo-10']*4,'primary_business_source_modified':False,'published':False,'priority_HU':19,'extra_HU':['HU 2.2'],'HU_with_related_evidence':19,'priority_HU_closed_end_to_end':0,'packages_technical_prepared':6,'packages_teaching_and_human_confirmed':0,'technical_artifacts':18,'main_unit_cases':67,'basic_paths':42,'unique_final_cases':323,'final_passed':313,'final_failed':10,'suite_counts':{s:dict(collections.Counter(c['result'] for c in cases if c['suite']==s)) for s in dict.fromkeys(c['suite'] for c in cases)},'counting_note':'Counts are test executions/cases, never work-completion percentage. Repetitions and proposal results are separate. The 4 AC02 ACTUAL/MANUAL cases also appear in the conformance run and are counted once.','patches':load('codigo/Bases_y_parches.json'),'proposals':load('propuesta_producto/Propuestas.json'),'input':load('cierre/Entrada_Revision.json')}
save('Resumen_resultados.json',summary)
# Preserve exact criteria source text; replace only obsolete evidence and scoped conclusions.
criteria=load('revision/Criterios_Demostrados.json',saved)
replace={'HU 3.6-F':['CLI_HU36_C01','UI_HU36_C01','INT_HU36_C02'],'HU 3.8-F':['CLI_HU38_C01','CLI_HU38_C03','CLI_HU38_C04','UI_HU38_C01','UI_HU38_C02','UI_HU38_C03'],'HU 3.9-F':['CLI_HU39_C01','UI_HU39_C01','UI_HU39_C02']}
for c in criteria['criterios']:
    refs=[r for r in c['casos_y_evidencias'] if r['caso'] in bycase]
    ids=replace.get(c['id_criterio'])
    if ids:refs=[]
    for id in ids or []:
        case=bycase[id];refs.append({'caso':id,'nombre_test':case['name'],'resultado':'aprobado' if case['result']=='Ejecutado aprobado' else 'fallido','evidencia':case['evidence'],'linea':case['evidence_line'],'nivel':case['environment']})
    for r in refs:
        case=bycase[r['caso']];r.update(evidencia=case['evidence'],resultado='aprobado' if case['result']=='Ejecutado aprobado' else 'fallido',linea=case['evidence_line'])
    c['casos_y_evidencias']=refs;c['criterio_integral_E2E_demostrado']=False
    if c['id_criterio'] in ['HU 3.6-F','HU 3.8-F']:
        c.update(estado='B: defecto de mensaje reproducido en base; corrección separada verificada',clausulas_demostradas_en_frontera_local=['Fallo real inducido en dependencia; estado, mensaje observado y efectos comprobados en ViewModel y pantalla. La base no satisface el literal requerido.'],evidencia_auxiliar_no_equivale_al_criterio='La propuesta cliente pasa estos escenarios; no se atribuye su aprobación a la base. No hay Google/Firebase cloud real.')
    if c['id_criterio']=='HU 3.9-F':c.update(estado='A: cláusula local de fallo y mensaje demostrada en mapper, ViewModel y UI',clausulas_demostradas_en_frontera_local=['Dato ratingChange inválido se conserva como null; UI real muestra Server failure y no inventa cero; reconexión restaura −6 sin nuevo envío.'],evidencia_auxiliar_no_equivale_al_criterio='Repositorios controlados. No se certifica regla ELO ni servicio remoto.')
    if c['hu']=='HU 3.5':c['limite_actualizado']='Guardas y ventana100 verificadas en base/propuesta; base50 falla; propuesta3×50 y51 pasa, con decisión de desempate pendiente. Fallo histórico48h conserva causa exacta abierta.'
criteria['nota_android']='96 JVM reejecutadas con --rerun, más6 UI y2 SDK local; base y propuesta separadas.'
criteria['responsable_revision']='Grupo, con apoyo de IA declarado; participación individual no confirmada';criteria['ejecucion_base_final']=summary['suite_counts']
save('revision/Criterios_Demostrados.json',criteria);csvout('revision/Criterios_Demostrados.csv',criteria['criterios'])
save('cierre/Modelo_Final.json',{'summary':summary,'files':{'unit':unit,'functional':func,'conformance':conf,'load':loadlog},'coverage_rows':len(cov),'android_coverage_rows':len(androidcov)})
print(json.dumps({'cases':len(cases),'results':collections.Counter(c['result'] for c in cases),'trace_rows':len(rows),'coverage_rows':len(cov)},ensure_ascii=False))
