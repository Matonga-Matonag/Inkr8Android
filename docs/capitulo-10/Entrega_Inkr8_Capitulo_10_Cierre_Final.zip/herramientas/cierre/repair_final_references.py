import csv,json,os,pathlib,re
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def save(p,x):(out/p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def csvout(p,rows):
    with (out/p).open('w',encoding='utf-8-sig',newline='') as f:
        keys=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})
cases=load('Casos_ejecutados.json')
for c in cases:
    if c['id'] in ['REV-MATCH-02','REV-MATCH-07']:
        c.update(test_source='codigo/backend/functions/integration/revision.regression.test.cjs',hu=['HU 3.5','HU 3.7'],package='Víctor',techniques='integración local / regresión',symbol='FirebaseMatchRepository.match',environment='Node20 / Firestore1.22 local')
        lines=(out/c['test_source']).read_text(encoding='utf-8-sig').splitlines();c['test_source_line']=next((i for i,s in enumerate(lines,1) if c['id'] in s),None)
save('Casos_ejecutados.json',cases);csvout('Casos_ejecutados.csv',cases)
bycase={c['id']:c for c in cases};rows=load('Matriz_Pruebas_y_Trazabilidad.json')
for r in rows:
    if r['caso'] in ['REV-MATCH-02','REV-MATCH-07']:
        c=bycase[r['caso']];r['fuente_test']=c['test_source']+(':'+str(c['test_source_line']) if c['test_source_line'] else '');r['simbolo']=c['symbol'];r['paquete']=c['package']
save('Matriz_Pruebas_y_Trazabilidad.json',rows);csvout('Matriz_Pruebas_y_Trazabilidad.csv',rows)
# Restore literal identifiers that generic typography may have spaced.
authored=[*out.glob('*.md'),*out.glob('paquetes/*.md'),*out.glob('revision/*.md'),*out.glob('cierre/**/*.md'),out/'evidencias/Cobertura.md']
for file in authored:
    text=file.read_text(encoding='utf-8-sig').replace('Inkr 8','Inkr8')
    for c in cases:
        id=c['id'];wrong=re.sub(r'([A-Za-zÁÉÍÓÚÑáéíóúñ])(?=\d)',r'\1 ',id);wrong=re.sub(r'(\d)(?=[A-Za-zÁÉÍÓÚÑáéíóúñ])',r'\1 ',wrong)
        if wrong!=id:text=text.replace(wrong,id)
    # A table reused below the root must point back to the delivery root.
    def link(m):
        target=m[1] or m[2]
        if re.match(r'^(https?://|#|codex:)',target) or (file.parent/target).is_file():return m[0]
        if (out/target).is_file():return '](<'+os.path.relpath(out/target,file.parent).replace('\\','/')+'>)'
        return m[0]
    text=re.sub(r'\]\((?:<([^>]+)>|([^\s)]+))\)',link,text)
    file.write_text(text,encoding='utf-8')
# Replace detailed-catalog broken directory links with the actual test source.
file=out/'Casos_Detallados.md';s=file.read_text(encoding='utf-8');s=s.replace('[código](<codigo/backend/>)','[código](<codigo/backend/functions/integration/revision.regression.test.cjs>)');file.write_text(s,encoding='utf-8')
audit=load('revision/Auditoria_Rubrica.json')
for key in list(audit):
    if isinstance(audit[key],dict) and 'firestore_funcional' in audit[key]:audit['antecedente_'+key]=audit.pop(key)
audit['ejecuciones_actuales']={'backend_unidad':{'pass':116,'fail':0,'evidence':'evidencias/cierre/backend/base-unit-final.log'},'firestore_funcional':{'pass':100,'fail':0,'evidence':'cierre/matchmaking/evidencias/base-functional-final/run-01.log'},'Renzo_CN_observable':{'pass':25,'fail':0,'within_functional_100':True},'client_JVM':{'pass':93,'fail':3,'proposal_pass':96},'UI':{'pass':3,'fail':3,'proposal_pass':6},'SDK_local':{'pass':1,'fail':1,'proposal_pass':2}}
save('revision/Auditoria_Rubrica.json',audit)
print('Literal project/identifiers, two source mappings and relative evidence links corrected.')
