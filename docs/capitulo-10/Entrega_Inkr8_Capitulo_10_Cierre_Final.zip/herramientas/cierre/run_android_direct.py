import argparse,datetime,hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--project',choices=['base','proposal'],default='base');p.add_argument('--suite',choices=['visual','sdk'],default='visual');a=p.parse_args()
repo=root/'work'/('frontend' if a.project=='base' else 'propuesta_frontend');out=root/'outputs/cierre/ui'/(a.project+'-'+a.suite);out.mkdir(parents=True,exist_ok=True)
adb=str(root/'work/tools/android-sdk/platform-tools/adb.exe');common=[adb,'-s','emulator-5556'];name='Capitulo10VisualTest' if a.suite=='visual' else 'Capitulo10LocalFirestoreTest'
apks=[repo/'app/build/outputs/apk/debug/app-debug.apk',repo/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']
meta={'project':a.project,'suite':a.suite,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'Direct AndroidJUnitRunner; no AGP uninstall at teardown; screenshots copied byte-for-byte','serial':'emulator-5556','commands':[],'apks':[],'source_sha256':{str(f.relative_to(repo)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((repo/'app/src/androidTest').rglob('*.kt'))}}
for apk in apks:
    assert apk.is_file(),f'Build :app:assembleDebug :app:assembleDebugAndroidTest first: {apk}'
    meta['apks'].append({'path':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest()})
    cmd=common+['install','-r','-t',str(apk)];meta['commands'].append(cmd)
    result=subprocess.run(cmd,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
prefix='UI-' if a.suite=='visual' else 'INT-'
# This fresh dedicated AVD contains only this test app. Clear only previously
# exported evidence filenames so a failed capture cannot reuse another run.
old=subprocess.run(common+['exec-out','run-as','com.inkr8','ls','-1','files/capitulo10-evidencias'],capture_output=True).stdout.decode(errors='replace').splitlines()
for filename in old:
    if filename.startswith(prefix) and re.fullmatch(r'[A-Z0-9a-z-]+\.(png|txt)',filename):
        subprocess.run(common+['shell','run-as','com.inkr8','rm','files/capitulo10-evidencias/'+filename],check=True,capture_output=True)
cmd=common+['shell','am','instrument','-w','-r','-e','class','com.inkr8.presentation.'+name]
if a.suite=='sdk':cmd+=['-e','localFirestore','true']
cmd+=['com.inkr8.test/androidx.test.runner.AndroidJUnitRunner'];meta['commands'].append(cmd)
start=time.monotonic()
with (out/'instrumentation.log').open('w',encoding='utf-8') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,text=True)
lines=(out/'instrumentation.log').read_text(encoding='utf-8').splitlines();block={};cases=[]
for i,line in enumerate(lines,1):
    m=re.match(r'INSTRUMENTATION_STATUS: (\w+)=(.*)',line)
    if m:block[m[1]]=m[2]
    m=re.match(r'INSTRUMENTATION_STATUS_CODE: (-?\d+)',line)
    if m:
        status=int(m[1])
        if block.get('test') and status in [0,-1,-2,-3,-4]:cases.append({'name':block['test'],'class':block.get('class'),'result':'passed' if status==0 else 'skipped' if status in [-3,-4] else 'failed','evidence':(out/'instrumentation.log').relative_to(root/'outputs').as_posix(),'evidence_line':i,'status_code':status})
        block={}
assert cases,'No completed JUnit case statuses found; inspect instrumentation.log'
meta.update(adb_exit_code=result.returncode,cases=cases,counts={k:sum(c['result']==k for c in cases) for k in ['passed','failed','skipped']},duration_seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
cmd=common+['exec-out','run-as','com.inkr8','ls','-1','files/capitulo10-evidencias'];listing=subprocess.run(cmd,capture_output=True)
(out/'capture-list.log').write_bytes(listing.stdout+listing.stderr)
for filename in listing.stdout.decode(errors='replace').splitlines():
    if not filename.startswith(prefix) or not re.fullmatch(r'[A-Z0-9a-z-]+\.(png|txt)',filename):continue
    data=subprocess.check_output(common+['exec-out','run-as','com.inkr8','cat','files/capitulo10-evidencias/'+filename]);dest=out/'capturas'/filename;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
    meta.setdefault('captures',[]).append({'file':dest.relative_to(root/'outputs').as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
meta['exit_code']=1 if meta['counts']['failed'] or meta['counts']['skipped'] else 0
(out/'Capturas_manifest.json').write_text(json.dumps(meta.get('captures',[]),ensure_ascii=False,indent=2),encoding='utf-8')
(out/'resultado-directo.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:meta[k] for k in ['project','suite','exit_code','counts','duration_seconds']}));print('Captured',len(meta.get('captures',[])),'files');sys.exit(meta['exit_code'])
