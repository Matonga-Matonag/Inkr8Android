import hashlib,json,pathlib,shutil
root=pathlib.Path(__file__).resolve().parents[2];prop=root/'work/propuesta_backend/functions/integration';base=root/'work/backend/functions/integration'
source=prop/'cierre.matchmaking.test.cjs';text=source.read_text(encoding='utf-8');marker="test('MM-LOAD-51"
if marker in text:
    functional,body=text.split(marker,1);body=marker+body
    source.write_text(functional.rstrip()+'\n',encoding='utf-8')
    odd=prop/'cierre.matchmaking.odd-load.test.cjs'
    odd.write_text("const {test}=require('node:test');\nconst {assert,matches,season,seed,observe,wave,pairs,record}=require('./cierre.matchmaking.fixture.cjs');\n"+body,encoding='utf-8')
    out=root/'outputs/cierre/matchmaking/Separacion_impar.json';out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'case':'MM-LOAD-51','body_sha256_before':hashlib.sha256(body.encode()).hexdigest(),'body_sha256_after':hashlib.sha256(odd.read_text().split(marker,1)[1].join([marker,'']).encode()).hexdigest(),'same_body':odd.read_text().endswith(body),'concurrency':51,'reason':'Dedicated fresh emulator for load; functional guards execute without filtered/skipped load'},indent=2),encoding='utf-8')
# All tests are delivered in the test patch. Only matchmaker is a product proposal.
for file in prop.glob('cierre.matchmaking*.cjs'):shutil.copy2(file,base/file.name)
for repo in [root/'work/backend',root/'work/propuesta_backend']:
    ac=repo/'functions/integration/cierre.ac02.test.cjs';s=ac.read_text(encoding='utf-8')
    s=s.replace('  test(`CIERRE-AC02-${status}-CONFORMIDAD scheduler debe recuperar automaticamente error transitorio`, {skip: !enforceAutomatic}, async () => {','  if (enforceAutomatic) test(`CIERRE-AC02-${status}-CONFORMIDAD scheduler debe recuperar automaticamente error transitorio`, async () => {')
    ac.write_text(s,encoding='utf-8')
    (repo/'functions/integration/cierre.ac02.conformidad.cjs').write_text("// Explicit requirement enforcement. Existing characterizations do not approve AC-02.\nprocess.env.CIERRE_EXIGIR_AC02='1';\nrequire('./cierre.ac02.test.cjs');\n",encoding='utf-8')
    package=repo/'functions/package.json';obj=json.loads(package.read_text())
    files='integration/firestore.test.cjs integration/capitulo10.firestore.test.cjs integration/revision.regression.test.cjs integration/cierre.cn-renzo.test.cjs integration/cierre.ac02.test.cjs integration/cierre.matchmaking.test.cjs'
    obj['scripts']['test:integration']='npm run build && node --test --test-concurrency=1 '+files
    obj['scripts']['test:integration:coverage']='npm run build && node --test --test-concurrency=1 --experimental-test-coverage '+files
    obj['scripts']['test:conformance:ac02']='npm run build && node --test --experimental-test-coverage integration/cierre.ac02.conformidad.cjs'
    obj['scripts']['test:matching:policy']='npm run build && node --test integration/cierre.matchmaking-policy.test.cjs'
    obj['scripts']['test:concurrency:odd']='npm run build && node --test --experimental-test-coverage integration/cierre.matchmaking.odd-load.test.cjs'
    package.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Functional tests separated from unchanged odd load; requirement checks stay explicit and executable.')
