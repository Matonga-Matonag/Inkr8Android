import datetime,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs/cierre/matchmaking';rows=[]
running=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'qemu-system|^java.exe$' } | Select-Object -ExpandProperty Name"],text=True).strip()
assert not running,'Stop Android/Gradle/other Firestore processes before the load profiles: '+running
matrix=[('base','base-50-final','integration/capitulo10.concurrency.test.cjs')]
matrix += [('propuesta',f'propuesta-50-final-r{i}','integration/capitulo10.concurrency.test.cjs') for i in [1,2,3]]
matrix += [('propuesta','propuesta-51-final','integration/cierre.matchmaking.odd-load.test.cjs'),('propuesta','propuesta-politica-final','integration/cierre.matchmaking-policy.test.cjs')]
meta={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight':'No qemu/Java/Gradle process detected; Android emulator stopped; no builds during profiles','each_profile_fresh_emulator':True,'results':rows}
for target,label,file in matrix:
    cmd=[sys.executable,str(root/'work/cierre/matchmaking/run.py'),'--target',target,label,'--','node','--test','--experimental-test-coverage',file]
    r=subprocess.run(cmd,cwd=root);rows.append({'target':target,'label':label,'command':cmd,'exit_code':r.returncode})
    (out/'Secuencia_Cargas_Final.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
meta['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'Secuencia_Cargas_Final.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');print(json.dumps(rows,indent=2))
sys.exit(1 if any(r['exit_code'] for r in rows if r['target']=='propuesta') else 0)
