"""Private isolated runner: each experiment owns a fresh local Firestore process."""
import argparse, datetime, hashlib, json, os, pathlib, socket, subprocess, sys, time
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
p=argparse.ArgumentParser()
p.add_argument('--target',choices=['base','propuesta'],required=True)
p.add_argument('--repeat',type=int,default=1)
p.add_argument('label')
p.add_argument('command',nargs=argparse.REMAINDER)
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[3]
repo=root/'work'/('backend' if a.target=='base' else 'propuesta_backend')
folder=root/'outputs/cierre/matchmaking/evidencias'/a.label
folder.mkdir(parents=True,exist_ok=True)
node=root/'work/tools/node-v20.19.0-win-x64/node.exe'
java=root/'work/tools/jdk-21.0.9+10/bin/java.exe'
jar=root/'work/revision/cloud-firestore-emulator-v1.22.0.jar'
with socket.socket() as s:
    if s.connect_ex(('127.0.0.1',8080))==0:raise RuntimeError('Port 8080 occupied; experiments must not share an emulator')
server_cmd=[str(java),'-Duser.language=en','-jar',str(jar),'--host','127.0.0.1','--port','8080','--project_id','demo-inkr8','--single_project_mode','--rules',str(repo/'firestore.rules')]
env=os.environ.copy()
env.update(PATH=str(node.parent)+os.pathsep+env['PATH'],FIRESTORE_EMULATOR_HOST='127.0.0.1:8080',GCLOUD_PROJECT='demo-inkr8',CAP10_TARGET_FUNCTIONS=str(repo/'functions'),CI='true',NO_COLOR='1')
command=a.command[1:] if a.command and a.command[0]=='--' else a.command
if not command:raise RuntimeError('Test command required')
if command[0]=='node':command[0]=str(node)
command=[x.replace('{newtests}',str(root/'work/propuesta_backend/functions/integration')) for x in command]
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def sha(file):return hashlib.sha256(file.read_bytes()).hexdigest()
meta={'label':a.label,'target':a.target,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'server_command':server_cmd,'test_command':command,'cwd':str(repo/'functions'),'repeat':a.repeat,'commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'jar_sha256':sha(jar),'source_sha256':{},'results':[]}
for file in sorted((repo/'functions/src').rglob('*.ts')):meta['source_sha256'][str(file.relative_to(repo))]=sha(file)
for file in sorted((root/'work/propuesta_backend/functions/integration').glob('cierre.matchmaking*.cjs')):meta.setdefault('new_tests_sha256',{})[file.name]=sha(file)
with (folder/'emulator.log').open('w',encoding='utf-8') as serverlog:
    server=subprocess.Popen(server_cmd,cwd=repo,env=env,stdout=serverlog,stderr=subprocess.STDOUT)
    try:
        for _ in range(600):
            if server.poll() is not None:raise RuntimeError('Emulator exited during startup')
            with socket.socket() as s:
                if s.connect_ex(('127.0.0.1',8080))==0:break
            time.sleep(.1)
        else:raise RuntimeError('Emulator startup timeout')
        for i in range(a.repeat):
            evidence=folder/f'run-{i+1:02d}';evidence.mkdir(exist_ok=True)
            env['CAP10_EVIDENCE_DIR']=str(evidence)
            start=time.perf_counter();logname=f'run-{i+1:02d}.log'
            with (folder/logname).open('w',encoding='utf-8') as log:
                result=subprocess.run(command,cwd=repo/'functions',env=env,stdout=log,stderr=subprocess.STDOUT)
            entry={'run':i+1,'exit_code':result.returncode,'duration_seconds':time.perf_counter()-start,'log':logname,'evidence_directory':str(evidence.relative_to(root))}
            meta['results'].append(entry)
            (folder/'experiment.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
            print(json.dumps(entry),flush=True)
    finally:
        server.terminate()
        try:server.wait(timeout=8)
        except subprocess.TimeoutExpired:server.kill();server.wait()
meta['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(folder/'experiment.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps({'label':a.label,'target':a.target,'results':meta['results']},indent=2))
sys.exit(max(r['exit_code'] for r in meta['results']))
