import datetime,json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2];sdk=root/'work/tools/android-sdk';folder=root/'work/cierre/android';folder.mkdir(parents=True,exist_ok=True)
evidence=root/'outputs/cierre/ui';evidence.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update(JAVA_HOME=str(root/'work/tools/jdk-21.0.9+10'),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),ANDROID_AVD_HOME=str(folder/'avd'))
pathlib.Path(env['ANDROID_AVD_HOME']).mkdir(exist_ok=True)
cmd=[str(sdk/'cmdline-tools/latest/bin/avdmanager.bat'),'create','avd','--name','Inkr8_Capitulo10','--package','system-images;android-36;default;x86_64','--path',str(folder/'Inkr8_Capitulo10.avd')]
if not (folder/'Inkr8_Capitulo10.avd/config.ini').exists():
    run=subprocess.run(cmd,env=env,input='no\n',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (evidence/'avd-create.log').write_text(run.stdout,encoding='utf-8')
    assert run.returncode==0,run.stdout
config=folder/'Inkr8_Capitulo10.avd/config.ini';s=config.read_text()
entries=dict(line.split('=',1) for line in s.splitlines() if '=' in line)
entries.update({'hw.ramSize':'1536','hw.cpu.ncore':'2','hw.lcd.width':'720','hw.lcd.height':'1280','hw.lcd.density':'240','hw.keyboard':'yes','hw.gpu.enabled':'yes','hw.gpu.mode':'swiftshader','showDeviceFrame':'no'})
config.write_text('\n'.join(k+'='+v for k,v in entries.items())+'\n',encoding='utf-8')
(evidence/'Android_Entorno.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'avd':'Inkr8_Capitulo10','isolated_avd_home':env['ANDROID_AVD_HOME'],'sdk':str(sdk),'command_create':cmd,'system_image':'android-36/default/x86_64 revision2','hardware_acceleration':'WHPX installed and usable','data':'Fresh dedicated AVD; no user accounts or unrelated AVD data used','network':'Only emulator loopback services and controlled UI doubles; no Google or OpenAI account'},indent=2),encoding='utf-8')
if '--start' in sys.argv:
    cmd=[str(sdk/'emulator/emulator.exe'),'-avd','Inkr8_Capitulo10','-port','5556','-no-window','-no-audio','-no-snapshot','-gpu','swiftshader','-no-boot-anim']
    log=(evidence/'android-emulator.log').open('w',encoding='utf-8')
    proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    (folder/'process.json').write_text(json.dumps({'pid':proc.pid,'command':cmd,'serial':'emulator-5556'},indent=2))
    print('Started isolated Android emulator PID',proc.pid)
else:print('Prepared isolated AVD')
