import json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def save(p,x):(out/p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def table(h,rows):
    clean=lambda x:str(x).replace('|','&#124;').replace('\n','<br>')
    return '| '+' | '.join(h)+' |\n|'+'|'.join('---' for _ in h)+'|\n'+'\n'.join('| '+' | '.join(map(clean,r))+' |' for r in rows)+'\n'
cases=load('Casos_ejecutados.json');fichas=load('paquetes/Seis_fichas.json');coverage=load('evidencias/Cobertura_archivos.json')
unitfiles={'MAR':'gamePolicy.ts','PED':'gameUseCases.ts','VIC':'gamePolicy.ts','JEA':'userPolicy.ts','REN':'contentUseCases.ts','MAT':'userDto.ts'}
for f in fichas:
    p=out/f'paquetes/Paquete_{f["key"]}.md';s=p.read_text(encoding='utf-8')
    s=re.sub(r'^\*\*Responsable propuesto:.*$', '**Responsabilidad de revisión y entrega:** el grupo, con asistencia de IA declarada. Referencia nominal para organizar la sustentación: '+f['person']+'. La revisión y reproducción individual requieren evidencia propia (EXT-02).',s,flags=re.M)
    s=s.replace('Revisión humana del CFG','Reproducción/aporte individual (EXT-02)')
    if f['key']=='REN':
        start=s.index('## Caja negra');end=s.index('## Casos, resultados y reproducción')
        cn='## Caja negra principal: Home observable\n\nSe ejecuta `GetDailyHome.execute → FirebaseContentRepository.dailyWord → Firestore` y se observa Home, caché y errores. Cinco entradas reales del catálogo persistido; **no** son cinco argumentos públicos: getHome recibe cero y dailyWord recibe day. No se llama al helper privado hasMetadata en estos25casos. La evidencia anterior del helper sigue como regresión auxiliar, sin sustituir la aceptación docente de esta frontera.\n\n'
        cn+=table(['Campo persistido','Salida','Particiones ejecutadas','Límite aplicable','Efecto'],[[a,b,'Dos valores no vacíos; vacío, espacios y ausente','Vacío después de trim/no vacío; no hay máximo lingüístico prometido','Home/caché exactos o error preciso; fuente intacta'] for a,b in [('word','word.text'),('definition','word.definition'),('phonetic','word.phonetic'),('partOfSpeech','word.partOfSpeech'),('rarity','word.rarity')]])
        cn+='\n25/25 casos:6de preservación/variación,15negativos por campo y4de caché/inactividad. Ver [contrato, opciones y pregunta exacta para Wong](../cierre/caja_negra/CN_Renzo_Observable.md). Solo EXT-01 puede confirmar aceptación docente; no se inventan campos ni se cuenta sentence/isActive/day para alcanzar cinco.\n\n'
        s=s[:start]+cn+s[end:]
        s=re.sub(r'## CN principal actualizada: Home observable[\s\S]*?(?=## Estado de cierre)', '',s)
    # Rebuild every case row from final evidence; do not reuse old log-line numbers/durations.
    selected=[c for c in cases if any(c['id'].startswith(t+'-'+f['key']+'-') for t in ['UT','CB','CN'])]
    if f['key']=='REN':selected=[c for c in selected if not c['id'].startswith('CN-REN-01')]+[c for c in cases if c['id'].startswith('CIERRE-CN-REN')]
    rows=[]
    for c in selected:
        target='../'+c['evidence'];label='línea '+str(c['evidence_line']) if c['evidence_line'] else 'JUnit'
        rows.append([c['id'],c['name'],c['result'],c['duration_ms'],f'[{label}](<{target}>)'])
    section='## Casos, resultados y reproducción\n\n'+table(['Caso','Escenario/fixture','Resultado base','Duración ms','Evidencia final'],rows)+'\n'
    start=s.index('## Casos, resultados y reproducción');end=s.index('Los arrays de datos',start)
    s=s[:start]+section+s[end:]
    if f['key']=='REN':s=s.replace('CB/CN de esta ficha en Firestore, tras compilar:', 'CB auxiliar de esta ficha en Firestore, tras compilar:')+'\nCN principal sin filtros ni omitidos: `firebase emulators:exec --project demo-inkr8 --only firestore "node --test functions/integration/cierre.cn-renzo.test.cjs"`. Preparar Node20/JDK21/JAR como indica README_Ejecucion.\n'
    row=next(r for r in coverage if r['report']=='base-unidad' and r['scope'].endswith('/'+unitfiles[f['key']]))
    s=re.sub(r'Cobertura medida, líneas / ramas / funciones \(%\):.*?(?=\n\n)',f'Cobertura medida del archivo unitario `{row["scope"]}`: {row["line_pct"]}% líneas, {row["branch_pct"]}% ramas y {row["function_pct"]}% funciones. La medición es por archivo, no por método ni HU. [Datos actuales](../evidencias/Cobertura.md). No acredita integración externa ni participación individual.',s,flags=re.S)
    p.write_text(s,encoding='utf-8')
# Update the viability matrix's old helper label and actual source.
v=load('Matriz_Viabilidad.json')
for r in v:
    r['existente']='Diseño, código y logs finales contrastados; base116unidad y100funcionales. Ver cierre y límites de producto por separado.'
    if r['paquete']=='Renzo' and r['tecnica']=='CN':r.update(metodo_frontera='GetDailyHome.execute → FirebaseContentRepository.dailyWord',criterio_rubrica='Rubrica!D18:5campos reales de catálogo persistido; frontera docente pendiente',brecha='EXT-01: confirmar entradas persistidas frente a payload público;25casos observables aprobados')
save('Matriz_Viabilidad.json',v)
import csv
with (out/'Matriz_Viabilidad.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(v[0]));w.writeheader();w.writerows(v)
# Original 5.6 text remains as antecedent; the current evidence is explicit.
rows=load('Filas_5_6.json')
for r in rows:
    h=r['Requisito / HU'];related=[c['id'] for c in cases if h in c.get('hu',[])]
    r['Evidencia']='Antecedente documental: '+r['Evidencia']+' | Evidencia actual: '+', '.join(related[:16])+'; relación completa y resultados en la matriz final.'
    if h in ['HU 3.6','HU 3.8','HU 3.9']:r['Evidencia']+=' Capturas locales auténticas disponibles; integración externa aún pendiente.'
    r['Implementación contrastada en cierre']={'HU 3.6':'SessionViewModel.refresh / ObserveUser / FirebaseUserRepository.observeUser / ProfileScreen','HU 3.8':'GameViewModel.watch / GameDto.toDomain / GameScreen','HU 3.9':'GameDto.toDomain / GameViewModel / GameScreen'}.get(h,r['Elemento de diseño / implementación'])
save('Filas_5_6.json',rows)
p=out/'Filas_5_3_y_5_6.md';s=p.read_text(encoding='utf-8');a=s.index('## Filas') if '## Filas' in s else s.index('## Filas5.6');s=s[:a]+'## Filas5.6\n\n'+table(list(rows[0]),[[r[k] for k in rows[0]] for r in rows])+'\n[JSON](Filas_5_6.json), [criterios](revision/Criterios_Demostrados.md), [matriz](Matriz_Pruebas_y_Trazabilidad.md).\n';p.write_text(s,encoding='utf-8')
repro=r'''# Reproducción del cierre técnico de Inkr8

Backend base: `993c6b0641a4a60603d87e251c90f51783460007`. Cliente base: `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Mantener rama `pruebas/capitulo-10`. No se necesitan credenciales reales para las pruebas locales documentadas.

Hay dos formas de preparar código: usar los árboles `codigo/backend` y `codigo/frontend`, que ya contienen pruebas, o extraer los ZIP `*_base.zip` y aplicar el patch correspondiente. No aplicar dos veces el parche. En otra copia, aplicar después el parche mínimo de producto que se quiera revisar.

```powershell
git apply --check C:/entrega/codigo/backend.patch
git apply C:/entrega/codigo/backend.patch
# En la copia del cliente: codigo/frontend.patch
```

Preparar Node20.19.0/npm10.8.2, JDK21.0.9 y FirebaseCLI14.22.0. Ajustar rutas locales:

```powershell
$env:JAVA_HOME = 'C:/herramientas/jdk-21.0.9+10'
$env:PATH = 'C:/herramientas/node-v20.19.0-win-x64;' + $env:JAVA_HOME + '/bin;' + $env:PATH
$env:FIRESTORE_EMULATOR_BINARY_PATH = 'C:/herramientas/cloud-firestore-emulator-v1.22.0.jar'
$env:CAP10_EVIDENCE_DIR = 'C:/evidencias-nuevas'
node --version
java -version
```

JAR1.22.0: [descarga oficial](https://storage.googleapis.com/firebase-preview-drop/emulator/cloud-firestore-emulator-v1.22.0.jar), SHA256 `9b6498b7f62714d67f48f59b3818883cd682dbcd46b9f59511de81c97bb5166c`. El override se conserva en metadatos. Usar exclusivamente proyecto `demo-inkr8` y loopback; no apuntar a producción.

## Backend base y propuesta

Desde la raíz backend:

```powershell
npm --prefix functions ci
npm --prefix functions run test:coverage
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:conformance:ac02"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:coverage"
```

Resultados base esperados:116/116 unidad,100/100 funcional; conformidad AC-02:6casos,4PASS/2FAIL; carga50:1FAIL. Los cuatro ACTUAL/MANUAL ya están en la funcional y no se cuentan de nuevo. Cada comando usa una instancia nueva. No omitir la carga ni sustituirla por llamadas secuenciales. `Run-Firestore.ps1` coordina funcional y50 y devuelve1si alguna falla.

En la copia separada:

```powershell
git apply --check C:/entrega/propuesta_producto/backend/contencion_empates.patch
git apply C:/entrega/propuesta_producto/backend/contencion_empates.patch
# Reejecutar unidad, funcional y carga originales de arriba.
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:matching:policy"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:odd"
```

Para repetir el perfil50 ejecutar su comando tres veces, cada vez con una instancia nueva y carpeta de evidencia distinta. Mantener50operaciones, completadas50, MATCHED50,25parejas,pico50 y cero violaciones. En51:51completadas,50MATCHED,25parejas,1pendiente,pico51. No ejecutar builds/AVD en paralelo a esas cargas. AC-02 conserva sus dos fallos incluso con el parche de matchmaking.

## Cliente JVM, UI y SDK local

JDK21, Gradlewrapper9.1.0, SDK36/BuildTools36.0.0. Configurar ANDROID_HOME/ANDROID_SDK_ROOT. Desde la raíz del cliente:

```powershell
.\gradlew.bat :app:testDebugUnitTest --rerun :domain:test --rerun --continue --no-daemon --max-workers=2
# Conservar exit1 de la base antes de generar informes, sin reejecutar los tests:
.\gradlew.bat :app:jacocoDebugUnitTestReport :domain:jacocoTestReport -x :app:testDebugUnitTest -x :domain:test --no-daemon --max-workers=2
.\gradlew.bat :app:assembleDebug :app:assembleDebugAndroidTest --no-daemon --max-workers=2
```

Base JVM:96casos,93PASS/3FAIL. En otra copia aplicar `propuesta_producto/cliente/mensajes_cliente.patch` después del parche de pruebas; repetir:96/96. Las dependencias Gradle están fijadas por el proyecto; si no hay caché se necesita acceso a sus repositorios de descarga.

Instrumentadas: AVD nuevo API36 default x86_64, WHPX,720×1280, serial usado emulator-5556. Herramientas oficiales: platform-tools37.0.1, emulator37.2.13 y system-image android-36/default/x86_64 r02. No usar un AVD con datos personales. Instalar los APK de debug y androidTest construidos:

```powershell
adb -s emulator-5556 install -r -t app/build/outputs/apk/debug/app-debug.apk
adb -s emulator-5556 install -r -t app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
adb -s emulator-5556 shell am instrument -w -r -e class com.inkr8.presentation.Capitulo10VisualTest com.inkr8.test/androidx.test.runner.AndroidJUnitRunner
```

Base UI:6casos,3PASS/3FAIL; propuesta6/6. Interpretar los códigos/status JUnit, no solo el exitcode de adb: AndroidJUnitRunner puede imprimir FAILURES con adb exit0. Las capturas se guardan en files/capitulo10-evidencias del target; copiar byte por byte antes de desinstalar. `ls -1` evita interpretar una salida multicolumna como un nombre. Los repositorios visuales son controlados y la pantalla/VM/mapper son reales.

Para los dos casos SDK iniciar una instancia local de Firestore con reglas productivas sin cambio, proyecto demo-inkr8, host127.0.0.1, puerto8080. Conectar desde el AVD por10.0.2.2:8080; no requiere Firebase cloud ni Google real:

```powershell
adb -s emulator-5556 shell am instrument -w -r -e class com.inkr8.presentation.Capitulo10LocalFirestoreTest -e localFirestore true com.inkr8.test/androidx.test.runner.AndroidJUnitRunner
```

Base:1PASS/1FAIL; propuesta2/2. El servidor debe devolver PERMISSION_DENIED por lectura sin identidad Firebase, no un error de red. Inicio/sesión del perfil son fixtures; observeUser atraviesa SDK/repositorio/reglas reales. Functions no se invoca. Estos tests no prueban login Google ni funciones desplegadas.

## Herramientas y decisiones preparadas

Se incluyen bajo herramientas/cierre los runners y generadores usados. Para reproducir su layout sin modificar rutas: crear una carpeta con outputs/ y work/; colocar repos en work/backend, work/frontend y copias propuestas en work/propuesta_backend, work/propuesta_frontend; copiar herramientas/cierre a work/cierre y runtimes a work/tools. Los comandos directos anteriores no necesitan ese layout auxiliar. Metadatos registran órdenes exactas, hashes de fuente/JAR/APK, fechas UTC y resultados.

ELO: `node outputs/cierre/decisiones/verificar_rating_decidido.cjs --backend work/backend --decision ruta/decision_aprobada.json` requiere decisión y esperados literales aprobados; sin ellos termina2y no simula conformidad. Para caracterizar se usa --caracterizar, que nunca aprueba ELO.

No hay permiso para llamadas facturables OpenAI. Configuración/cuentas Google/Firebase y decisiones pendientes: [inventario único](Pendientes_Externos.md). [Capturas y dependencias](cierre/ui/Indice_Capturas.md), [código/parches](codigo/Bases_y_parches.json), [propuestas](propuesta_producto/Propuestas.json).
'''
repro=repro.replace('\\"','"')
(out/'README_Ejecucion.md').write_text(repro,encoding='utf-8')
# Copy all current supporting tools; no old generator is advertised as the final validator.
dest=out/'herramientas/cierre';dest.mkdir(parents=True,exist_ok=True)
for file in (root/'work/cierre').rglob('*.py'):
    if any(x in file.parts for x in ['exportacion','insumo','android']):continue
    target=dest/file.relative_to(root/'work/cierre');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,target)
print('Six current evidence tables, Renzo contract and direct reproduction commands finalized.')
