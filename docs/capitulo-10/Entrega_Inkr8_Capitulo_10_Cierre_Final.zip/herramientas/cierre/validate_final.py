import collections,hashlib,json,pathlib,re,subprocess,sys,uuid,zipfile,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs';checks=[]
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def add(name,ok,detail=None):checks.append({'check':name,'ok':bool(ok),'detail':detail})
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normal(p):return p.read_bytes().replace(b'\r\n',b'\n')
cases=load('Casos_ejecutados.json');bycase={c['id']:c for c in cases}
add('323 casos únicos,313PASS/10FAIL; no porcentaje de trabajo',len(cases)==len(bycase)==323 and collections.Counter(c['result'] for c in cases)=={'Ejecutado aprobado':313,'Ejecutado fallido':10})
for c in cases:
    add(c['id']+' fuente,metadatos,evidencia existentes',all((out/c[k]).is_file() for k in ['test_source','command_metadata','evidence']))
    text=(out/c['evidence']).read_text(encoding='utf-8-sig')
    if c['evidence_line']:
        line=text.splitlines()[c['evidence_line']-1]
        if c['id'].startswith(('UI_','INT_')):
            ok='INSTRUMENTATION_STATUS_CODE:' in line and c['name'] in '\n'.join(text.splitlines()[max(0,c['evidence_line']-12):c['evidence_line']])
            ok=ok and (line.endswith(': 0') if c['result']=='Ejecutado aprobado' else bool(re.search(r': -[12]$',line)))
        else:ok=c['name'] in line and line.startswith('ok ' if c['result']=='Ejecutado aprobado' else 'not ok ')
        add(c['id']+' estado coincide con línea del runner',ok)
    else:
        records=[t for t in ET.fromstring(text).iter('testcase') if t.attrib.get('name')==c['name']]
        add(c['id']+' JUnit coincide',len(records)==1 and (records[0].find('failure') is not None or records[0].find('error') is not None)==(c['result']=='Ejecutado fallido'))
graphs=load('caja_blanca/grafos_y_caminos.json')
def rank(vectors):
    pivots={}
    for x in vectors:
        while x:
            bit=x.bit_length()-1
            if bit not in pivots:pivots[bit]=x;break
            x^=pivots[bit]
    return len(pivots)
for g in graphs:
    edges=[tuple(e) for e in g['edges']];degrees=collections.Counter(a for a,b in edges);vectors=[];valid=True
    for p in g['paths']:
        vector=0
        for edge in zip(p['nodes'],p['nodes'][1:]):
            if edge not in edges:valid=False;continue
            vector^=1<<edges.index(edge)
        vectors.append(vector);valid=valid and p['case'] in bycase and bycase[p['case']]['result']=='Ejecutado aprobado'
    add(g['id']+' CFG y base recalculados',valid and g['N']==len(g['nodes']) and g['E']==len(edges) and g['V']>=5 and g['V']==g['E']-g['N']+2==1+sum(d-1 for d in degrees.values() if d>1)==rank(vectors)==len(g['paths']))
fichas=load('paquetes/Seis_fichas.json');add('6paquetes:67UT>=4/método,42caminos',len(fichas)==6 and sum(f['unit_count'] for f in fichas)==67 and sum(g['V'] for g in graphs)==42 and all(f['unit_count']>=4 and len(f['cn_fields'])>=5 for f in fichas))
for f in fichas:
    unit=[c for c in cases if c['id'].startswith('UT-'+f['key']+'-01-C')]
    add(f['key']+' unitarias distinguibles y aprobadas',len(unit)==f['unit_count'] and all(c['result']=='Ejecutado aprobado' for c in unit))
add('CN Home observable25casos, sin invocación directa del helper',len([c for c in cases if c['id'].startswith('CIERRE-CN-REN') and c['result']=='Ejecutado aprobado'])==25 and '.hasMetadata(' not in (out/'codigo/backend/functions/integration/cierre.cn-renzo.test.cjs').read_text())
catalog=load('fuentes/catalogo_hu.json');allowed={h['id'] for h in catalog if h['in_priority_union']}|{'HU 2.2'};trace=load('Matriz_Pruebas_y_Trazabilidad.json')
add('396relaciones solo19HU+2.2 y referencias reales',len(trace)==396 and {r['HU'] for r in trace}==allowed and all(r['caso'] in bycase and (out/r['diseño']).is_file() and r['resultado']==bycase[r['caso']]['result'] for r in trace))
criteria=load('revision/Criterios_Demostrados.json')['criterios'];add('40criterios,38prioritarios; traza no certificaE2E',len(criteria)==40 and sum(c['prioritario'] for c in criteria)==38 and all(not c['criterio_integral_E2E_demostrado'] for c in criteria))
for c in criteria:add(c['id_criterio']+' casos actuales',all(r['caso'] in bycase and (out/r['evidencia']).is_file() for r in c['casos_y_evidencias']))
rows=load('Filas_5_6.json');rowmap={r['Requisito / HU']:r for r in rows};add('20filas5.6 conservan identidad',len(rows)==20 and set(rowmap)==allowed)
for h in catalog:
    if h.get('in_5_6'):
        old=h['report_5_6'];new=rowmap[h['id']]
        add('5.6 conserva fuente '+h['id'],all(new[k]==old[k] for k in ['Requisito / HU','Release','Sprint','Elemento de diseño / implementación']) and old['Evidencia'] in new['Evidencia'] and old['Ubicación'] in new['Ubicación'])
def counts(path):
    text=(out/path).read_text(encoding='utf-8');return {k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped) (\d+)\s*$',text,re.M)}
for copyname in ['base','propuesta']:
    add(copyname+' funcional100sinomitidos',counts(f'cierre/matchmaking/evidencias/{copyname}-functional-final/run-01.log')=={'tests':100,'pass':100,'fail':0,'skipped':0})
    add(copyname+' AC02conserva2rojos',counts(f'cierre/matchmaking/evidencias/{copyname}-ac02-conformidad/run-01.log')=={'tests':6,'pass':4,'fail':2,'skipped':0})
for i in [1,2,3]:
    p=f'cierre/matchmaking/evidencias/propuesta-50-final-r{i}';d=load(p+'/run-01/AC03_50_solicitudes.json')
    add('50propuesta repetición'+str(i),all(d[k]==v for k,v in {'attempted':50,'completed':50,'matched':50,'verifiedPairs':25,'peakActiveOperations':50,'violations':[]}.items()) and counts(p+'/run-01.log')=={'tests':1,'pass':1,'fail':0,'skipped':0})
odd=load('cierre/matchmaking/evidencias/propuesta-51-final/run-01/MM-LOAD-51.json');add('51impar conserva25parejas+1pendiente',odd['requests']['attempted']==odd['requests']['fulfilled']==odd['requests']['peak']==51 and odd['invariants']=={'matched':50,'pairs':25,'pending':1,'violations':[]})
q=load('cierre/matchmaking/evidencias/base-50-final/run-01/AC03_50_solicitudes.json');add('Base50mantiene fallo26/50',q['attempted']==q['peakActiveOperations']==50 and q['completed']==q['matched']==26 and q['verifiedPairs']==13 and q['violations']==[] and counts('cierre/matchmaking/evidencias/base-50-final/run-01.log')['fail']==1)
with zipfile.ZipFile(out/'Entrega_Inkr8_Capitulo_10_Revision_Tecnica.zip') as z:
    old=z.read('codigo/backend/functions/integration/capitulo10.concurrency.test.cjs').decode('utf-8').replace('\r\n','\n')
marker="test('AC03-C01";body=marker+old.split(marker,1)[1]
for repo in ['backend','propuesta_backend']:
    current=(root/'work'/repo/'functions/integration/capitulo10.concurrency.test.cjs').read_text(encoding='utf-8').replace('\r\n','\n')
    add(repo+' cuerpo50idénticoalZIPentrada',body==marker+current.split(marker,1)[1])
pngs=[]
for copyname in ['base','proposal']:
    meta=load(f'cierre/cliente/{copyname}-all-coverage.json');add(copyname+' JVMforzada y reporte noocultaexit',meta['command'].count('--rerun')==2 and meta['coverage_exit_code']==0 and meta['tests_exit_code']==(1 if copyname=='base' else 0))
    for suite in ['visual','sdk']:
        m=load(f'cierre/ui/{copyname}-{suite}/resultado-directo.json');expected={'passed':3,'failed':3,'skipped':0} if copyname=='base' and suite=='visual' else {'passed':1,'failed':1,'skipped':0} if copyname=='base' else {'passed':6 if suite=='visual' else 2,'failed':0,'skipped':0}
        add(copyname+' '+suite+' runnerstatus reales',m['counts']==expected and len(m['cases'])==sum(expected.values()))
        for entry in m['captures']:
            f=out/entry['file'];add(entry['file']+' bytes/hash',f.is_file() and digest(f)==entry['sha256'])
            if f.suffix=='.png':pngs.append(f)
        for p,h in m['source_sha256'].items():add(copyname+' UI fuentehash '+pathlib.Path(p).name,digest(root/'work'/('frontend' if copyname=='base' else 'propuesta_frontend')/p)==h)
pngs.append(out/'cierre/ui/configuracion/UI-CONFIG-01.png')
add('17capturasPNG auténticas no vacías',len(pngs)==17 and all(p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n') and p.stat().st_size>15000 for p in pngs))
add('Cobertura91filasproductoyJaCoCo',len(load('evidencias/Cobertura_archivos.json'))==91 and all(r['scope'].startswith('src/') for r in load('evidencias/Cobertura_archivos.json')) and len(load('evidencias/Cobertura_Android.json'))>=8)
for m in load('codigo/Bases_y_parches.json'):
    repo=m['repo'];p=out/'codigo'/(repo+'.patch');add(repo+' parchehash ynegociointacto',digest(p)==m['patch_sha256'] and not m['business_source_modified'] and m['branch']=='pruebas/capitulo-10')
    scopes=['functions/src'] if repo=='backend' else ['app/src/main','domain/src/main'];r=subprocess.run(['git','diff','HEAD','--',*scopes],cwd=root/'work'/repo,capture_output=True);add(repo+' gitnegociosin cambios',r.returncode==0 and not r.stdout)
    temp=root/'work/cierre/validacion_final'/uuid.uuid4().hex[:8]/repo;temp.mkdir(parents=True)
    with zipfile.ZipFile(out/'codigo'/(repo+'_base.zip')) as z:z.extractall(temp)
    r=subprocess.run(['git','apply',str(p)],cwd=temp,capture_output=True,text=True);add(repo+' parche aplicadoabase',r.returncode==0,r.stderr)
    if r.returncode==0:
        add(repo+' cambiosentregadosigualbase+patch',all(normal(temp/f)==normal(out/'codigo'/repo/f) for f in m['changed']))
        prop=next(x for x in load('propuesta_producto/Propuestas.json') if x['repo']==('backend' if repo=='backend' else 'cliente'));pp=out/prop['patch']
        add(repo+' productopropuestosóloscope/hash',digest(pp)==prop['patch_sha256'] and len(prop['source_changed'])==(1 if repo=='backend' else 2) and not prop['applied_to_main'] and not prop['published'])
        r=subprocess.run(['git','apply',str(pp)],cwd=temp,capture_output=True,text=True);add(repo+' productopropuestoaplicabase+pruebas',r.returncode==0,r.stderr)
        if r.returncode==0:add(repo+' productopropuesto fuenteexacta',all(normal(temp/f)==normal(pp.parent/'fuentes'/f) for f in prop['source_changed']))
pending=load('Pendientes_Externos.json');add('Una listacanónica9Cconresponsable/evidencia',len(pending)==9 and len({r['id'] for r in pending})==9 and all(r['clasificacion']=='C' and r['responsable'] and r['decision_o_evidencia_necesaria'] for r in pending) and pending==load('Pendientes.json'))
add('IA y grupo sinfabricarconfirmaciones','grupo' in (out/'Registro_IA_y_Pendientes.md').read_text().lower() and 'IA' in (out/'Registro_IA_y_Pendientes.md').read_text() and load('Resumen_resultados.json')['packages_teaching_and_human_confirmed']==0)
broken=[]
for file in out.rglob('*.md'):
    relative=file.relative_to(out)
    if relative.parts[0] in ['codigo','fuentes'] or 'entrega_anterior' in relative.parts:continue
    text=file.read_text(encoding='utf-8-sig')
    for m in re.finditer(r'\[[^\]]*\]\((?:<([^>]+)>|([^\s)]+))\)',text):
        target=m[1] or m[2]
        if re.match(r'^(?:https?://|#|codex:)',target):continue
        target=target.split('#')[0]
        if target and not (file.parent/target).is_file():broken.append({'file':relative.as_posix(),'target':target})
add('Enlaceslocalesactuales',not broken,broken)
report={'all_checks_passed':all(c['ok'] for c in checks),'checks':checks,'scope':'Integridad, fuente/runner, CFG/casos, parches aplicados y capturas. No transforma fallos de producto en aprobaciones ni certifica docente/participación/E2E.'}
(out/'Validacion_Entrega.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('checks',len(checks),'passed',sum(c['ok'] for c in checks));print(json.dumps([c for c in checks if not c['ok']],ensure_ascii=False,indent=2));sys.exit(0 if report['all_checks_passed'] else 1)
