import datetime,json,pathlib,socket,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs/cierre/ui';out.mkdir(parents=True,exist_ok=True)
with socket.socket() as s:
    assert s.connect_ex(('127.0.0.1',8080))!=0,'Port 8080 is owned by another run'
cmd=[str(root/'work/tools/jdk-21.0.9+10/bin/java.exe'),'-Duser.language=en','-jar',str(root/'work/revision/cloud-firestore-emulator-v1.22.0.jar'),'--host','127.0.0.1','--port','8080','--project_id','demo-inkr8','--single_project_mode','--rules',str(root/'work/backend/firestore.rules')]
meta={'server_command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'project':'demo-inkr8','rules':'Unchanged production Firestore rules','results':[]}
with (out/'sdk-emulator.log').open('w',encoding='utf-8') as log:
    server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        for _ in range(600):
            if server.poll() is not None:raise RuntimeError('Local emulator failed')
            with socket.socket() as s:
                if s.connect_ex(('127.0.0.1',8080))==0:break
            time.sleep(.1)
        else:raise RuntimeError('Local emulator not ready')
        for project in sys.argv[1:] or ['base','proposal']:
            run=[sys.executable,str(root/'work/cierre/run_android_direct.py'),'--project',project,'--suite','sdk']
            result=subprocess.run(run,cwd=root);meta['results'].append({'project':project,'command':run,'exit_code':result.returncode})
    finally:
        server.terminate()
        try:server.wait(8)
        except subprocess.TimeoutExpired:server.kill();server.wait()
meta['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'sdk-experiment.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps(meta,indent=2));sys.exit(max(r['exit_code'] for r in meta['results']))
