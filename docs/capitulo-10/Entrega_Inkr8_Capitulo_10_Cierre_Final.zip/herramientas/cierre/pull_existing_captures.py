import hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs/cierre/ui'/sys.argv[1];meta=json.loads((out/'resultado-directo.json').read_text())
adb=str(root/'work/tools/android-sdk/platform-tools/adb.exe');common=[adb,'-s','emulator-5556'];files=subprocess.check_output(common+['exec-out','run-as','com.inkr8','ls','-1','files/capitulo10-evidencias']).decode().splitlines();rows=[]
for name in files:
    if not re.fullmatch(r'(UI|INT)-[A-Za-z0-9-]+\.(png|txt)',name):continue
    data=subprocess.check_output(common+['exec-out','run-as','com.inkr8','cat','files/capitulo10-evidencias/'+name]);dest=out/'capturas'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data);rows.append({'file':dest.relative_to(root/'outputs').as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
meta['captures']=rows;(out/'resultado-directo.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');(out/'Capturas_manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print('Captured authentic files:',len(rows))
