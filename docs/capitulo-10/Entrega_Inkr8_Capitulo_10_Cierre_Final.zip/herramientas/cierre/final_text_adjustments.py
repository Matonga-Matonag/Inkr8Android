import json,pathlib,re
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
paths=[*out.glob('*.md'),*out.glob('paquetes/*.md'),*out.glob('revision/*.md'),*out.glob('cierre/**/*.md'),out/'evidencias/Cobertura.md']
for p in paths:
    s=p.read_text(encoding='utf-8').replace('demo-inkr 8','demo-inkr8').replace('Inkr 8','Inkr8')
    s=re.sub(r'\bC (\d{2})\b',r'C\1',s)
    s=re.sub(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):\s+(\d{2,5})',r'\1:\2',s)
    p.write_text(s,encoding='utf-8')
p=out/'cierre/caja_negra/CN_Renzo_Observable.md';s=p.read_text(encoding='utf-8').replace('El nuevo archivo se invoca expresamente: no cambia `package.json`, las suites anteriores ni código de producto.','El nuevo archivo está incluido expresamente en test:integration y sus25casos forman parte de los100funcionales finales. El código de producto de la base no cambió.').replace('Las HU 1.5/1.6 están trazadas; esta CN demuestra','La ficha traza HU1.5/1.6; esta CN corresponde a HU1.5 y la unitaria GetWordExample aporta evidencia a HU1.6. Esta CN demuestra');p.write_text(s,encoding='utf-8')
p=out/'cierre/decisiones/Decisiones_Pendientes.md';s=p.read_text(encoding='utf-8');s=re.sub(r'Los diez casos[^\n]+\n', 'Los diez casos CLI_HU36_C01..C03, CLI_HU38_C01..C05 y CLI_HU39_C01..C02 se ejecutaron dentro del cierre JVM forzado. Base:96casos,93PASS/3FAIL; propuesta:96PASS. No son comparaciones de constantes. [Resultados actuales](../cliente/Reporte_Cliente.md).\n',s);p.write_text(s,encoding='utf-8')
p=out/'cierre/decisiones/Matriz_Conformidad.json';d=json.loads(p.read_text(encoding='utf-8'))
for r in d['decisiones']:
    if r['id']=='DEC-AC02-429503':r['ejecucion']='A:cuatro ACTUAL/MANUAL aprobados; B:dos CONFORMIDAD ejecutados y fallidos en base y propuesta. C:EXT-04 decide política; sin intervalo nuevo elegido.'
d['cierre_actual']='Ver Resumen_Cierre_Final.md y la lista canónica Pendientes_Externos.md';p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
print('Final wording checked; project name and endpoints preserved.')
