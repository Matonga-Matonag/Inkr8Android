import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs';validation=json.loads((out/'Validacion_Entrega.json').read_text(encoding='utf-8'));assert validation['all_checks_passed']
tools=out/'herramientas/cierre';tools.mkdir(exist_ok=True)
for file in (root/'work/cierre').glob('*.py'):shutil.copy2(file,tools/file.name)
dest=tools/'matchmaking';dest.mkdir(exist_ok=True);shutil.copy2(root/'work/cierre/matchmaking/run.py',dest/'run.py')
shutil.copy2(root/'work/cierre/validate_final.py',out/'herramientas/validate_delivery.py')
manifest=[]
for file in sorted(out.rglob('*')):
    if not file.is_file():continue
    if file.parent==out and (file.suffix=='.zip' or file.name.endswith('.sha256.txt') or file.name=='MANIFEST_SHA256.json'):continue
    manifest.append({'path':file.relative_to(out).as_posix(),'size_bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(out/'MANIFEST_SHA256.json').write_text(json.dumps({'algorithm':'SHA-256','delivery':'Inkr8 Cierre Final,2026-11-06 Lima','files':manifest},ensure_ascii=False,indent=2),encoding='utf-8')
archive=out/'Entrega_Inkr8_Capitulo_10_Cierre_Final.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for item in manifest:z.write(out/item['path'],item['path'])
    z.write(out/'MANIFEST_SHA256.json','MANIFEST_SHA256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(manifest)+1
    for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(out/(archive.stem+'.sha256.txt')).write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
result={'archive':str(archive),'size_bytes':archive.stat().st_size,'files':len(manifest)+1,'sha256':sha,'verified':'CRC + every manifest hash','artifact_integrity_checks':len(validation['checks']),'input_revision_zip_preserved':(out/'Entrega_Inkr8_Capitulo_10_Revision_Tecnica.zip').is_file()}
(root/'work/cierre/Empaquetado_Final.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
