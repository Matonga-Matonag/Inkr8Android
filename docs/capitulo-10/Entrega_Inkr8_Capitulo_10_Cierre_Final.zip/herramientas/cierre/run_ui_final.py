import datetime,hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs/cierre/ui';results=[]
for project in ['base','proposal']:
    cmd=[sys.executable,str(root/'work/cierre/run_android_direct.py'),'--project',project,'--suite','visual']
    r=subprocess.run(cmd,cwd=root);results.append({'command':cmd,'exit_code':r.returncode})
cmd=[sys.executable,str(root/'work/cierre/run_local_sdk.py'),'base','proposal'];r=subprocess.run(cmd,cwd=root);results.append({'command':cmd,'exit_code':r.returncode})
folder=out/'configuracion';folder.mkdir(exist_ok=True);adb=str(root/'work/tools/android-sdk/platform-tools/adb.exe');common=[adb,'-s','emulator-5556']
cmd=common+['shell','am','start','-n','com.inkr8/.MainActivity'];launched=subprocess.run(cmd,capture_output=True,text=True)
time.sleep(2)
subprocess.run(common+['shell','uiautomator','dump','/sdcard/inkr8-capitulo10-config.xml'],capture_output=True,check=True)
xml=subprocess.check_output(common+['exec-out','cat','/sdcard/inkr8-capitulo10-config.xml']);png=subprocess.check_output(common+['exec-out','screencap','-p'])
(folder/'UI-CONFIG-01.xml').write_bytes(xml);(folder/'UI-CONFIG-01.png').write_bytes(png)
(folder/'resultado.json').write_text(json.dumps({'case':'UI-CONFIG-01','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'launch_command':cmd,'launch_output':launched.stdout,'firebase_configuration_missing':b'Firebase' in xml,'google_services_json_present':(root/'work/frontend/app/google-services.json').is_file(),'google_account':'Not configured; no login attempted','system_image':'API36 default x86_64, no Google Play services','png_sha256':hashlib.sha256(png).hexdigest(),'scope':'Diagnostic setup screen, not Google sign-in acceptance'},indent=2),encoding='utf-8')
(out/'Secuencia_UI_Final.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print('UI final sequence finished, including preserved base failures.');sys.exit(max(r['exit_code'] for r in results))
