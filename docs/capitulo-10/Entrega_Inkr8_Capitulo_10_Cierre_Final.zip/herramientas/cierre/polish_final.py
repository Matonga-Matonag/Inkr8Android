import hashlib,json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs'
def load(p):return json.loads((out/p).read_text(encoding='utf-8-sig'))
def save(p,x):(out/p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
S=load('Resumen_resultados.json');c=load('cierre/cliente/resultado_cliente.json')
newcases=[x for x in load('Casos_ejecutados.json') if x['id'].startswith('CLI_')]
c.update(casos=newcases,propuesta=load('propuesta_producto/cliente/Metadatos.json'),pendientes=['EXT-02','EXT-07','EXT-09'],estado_global_base='B: dos defectos reproducidos en tres JVM, tres UI y un SDK local',estados_cierre={'A':'10 negativos,96 JVM,6 UI y2 SDK ejecutados; propuesta separada verificada','B':'Base preserva defectos de mensaje de HU3.6 y3.8','C':'EXT-02/07/09; sin participación individual inventada ni integración externa autorizada'})
save('cierre/cliente/resultado_cliente.json',c)
mmroot='cierre/matchmaking/evidencias/'
rows=[]
for label in ['base-50-final','propuesta-50-final-r1','propuesta-50-final-r2','propuesta-50-final-r3']:
    d=load(mmroot+label+'/run-01/AC03_50_solicitudes.json');rows.append({'label':label,**{k:d[k] for k in ['attempted','completed','matched','verifiedPairs','peakActiveOperations','violations']},'evidence':mmroot+label+'/run-01/AC03_50_solicitudes.json'})
review={'responsabilidad':'Grupo, con asistencia IA declarada; sin revisión ni reproducción individual inventada','base_business_unchanged':True,'proposal':load('propuesta_producto/backend/Metadatos.json'),'functional_cases_including_20_extended':{'base':100,'proposal':100,'failed':0},'unit':116,'tie_policy':{'passed':1,'accepted_by_business':False},'load50':rows,'load51':load(mmroot+'propuesta-51-final/run-01/MM-LOAD-51.json')['invariants'],'window_limit':'100 preexistente, reproducido en base y propuesta con100/101/102','guards':['author','RANKED mode','writingMode','season own/opponent/current worker','profile existing/open','evaluation','delta30/31','status'],'recommendation':'Favorable a incorporar el parche mínimo tras aceptar el desempate y revisar el diff; no promete ausencia de inanición ni capacidad cloud. EXT-09.','unrelated_failures':'AC02 conformidad429/503 permanece con2fallos en ambas copias'}
save('revision/Revision_Propuesta.json',review)
(out/'revision/Revision_Propuesta.md').write_text('# Revisión actual de la propuesta de Inkr8\n\nEl grupo es responsable de la revisión y entrega, con asistencia de IA declarada. La recomendación técnica es favorable a incorporar el parche mínimo después de aceptar la política de desempate y revisar el diff. La base no se modificó.\n\nLa validación ampliada actual está en [Validacion_Final.md](../cierre/matchmaking/Validacion_Final.md): guardas, impares, timestamps, ventana100/101/102, tres perfiles50 y uno51. [Datos y resultados](Revision_Propuesta.json). Los resultados anteriores de51funcionales quedan como antecedentes en sus logs y en el ZIP de entrada; el cierre actual tiene100funcionales y no incorpora ninguna corrección429/503 ni ELO.\n',encoding='utf-8')
p=out/'revision/Investigacion_Firestore.md';s=p.read_text(encoding='utf-8');s=s.replace('# Investigación de Firestore','# Investigación de Firestore — antecedentes y cierre',1)
s=s.replace('\n\nSe mantuvieron','\n\nCierre actual: base26/50llamadas,26MATCHED/13parejas,pico50; propuesta3×50/50 y51/51. Los ensayos que siguen son antecedentes y no se suman al cierre. [Validación ampliada](../cierre/matchmaking/Validacion_Final.md).\n\nSe mantuvieron',1);p.write_text(s,encoding='utf-8')
for filename,source in [('AC03_50_solicitudes.json',mmroot+'base-50-final/run-01/AC03_50_solicitudes.json'),('recuperacion_48h.json',mmroot+'base-functional-final/run-01/recuperacion_48h.json')]:
    dest=out/'evidencias'/filename
    if dest.exists():shutil.copy2(dest,out/'evidencias/revision/entrega_anterior'/('anterior_revision_'+filename))
    assert (out/source).is_file(),source;shutil.copy2(out/source,dest)
oldenv=load('evidencias/Entorno.json');save('evidencias/Entorno.json',{'current_closure':'2026-11-06 Lima','node':'20.19.0','npm':'10.8.2','jdk':'21.0.9','firestore':'1.22.0','firebase_cli':'14.22.0','gradle':'9.1.0','SDK':'36 / build-tools36.0.0','ui_environment':'cierre/ui/Android_Entorno.json','load_isolation':'cierre/matchmaking/Secuencia_Cargas_Final.json','external_cloud_calls':False,'OpenAI_billable_calls':False,'historical_inventory':oldenv})
cases=load('Casos_ejecutados.json')
doc='# Catálogo detallado de casos ejecutados\n\n323casos únicos de base; no suma repeticiones ni resultados propuestos. Cada fila remite a fuente y evidencia auténtica; los estados fallidos se conservan. Los parámetros/particiones literales están en los tests y, para Renzo/matchmaking, en los JSON de diseño/snapshots.\n\n| Caso | Estímulo/escenario | Resultado base | Fuente | Evidencia |\n|---|---|---|---|---|\n'
for c in cases:
    clean=lambda s:str(s).replace('|','&#124;').replace('\n','<br>')
    doc+='| '+' | '.join(map(clean,[c['id'],c['name'],c['result'],'[código](<'+c['test_source']+'>)','[registro](<'+c['evidence']+'>)'+(' línea'+str(c['evidence_line']) if c['evidence_line'] else '')]))+' |\n'
(out/'Casos_Detallados.md').write_text(doc,encoding='utf-8')
(out/'herramientas/LEEME.md').write_text('''# Herramientas del cierre final de Inkr8

El procedimiento vigente es README_Ejecucion.md. El validador actual es cierre/validate_final.py. Copiar herramientas/cierre a work/cierre dentro del layout documentado (outputs/ como hermana de work/); allí están los runners de Android, SDK y Firestore, la secuencia de cargas y los generadores del cierre. Los árboles de código/patches se usan como se indica en reproducción.

Los scripts build_delivery.py, build_cfg.py y los de revision/ conservan preparación de fases anteriores. No sustituir el modelo final ni ejecutar los empaquetadores antiguos para regenerar el cierre. Los documentos incluyen revisión editorial además de generación; el validador comprueba contenido/evidencia y parches sin ejecutar otra vez ni aprobar los tests rojos.

La preparación y revisión se entregan bajo responsabilidad del grupo, con apoyo IA declarado. Las herramientas y sus resultados no prueban participación individual.
''',encoding='utf-8')
# Typography in authored Markdown only. Never alter raw logs, source, JSON or a hash.
files=[*out.glob('*.md'),*out.glob('paquetes/*.md'),*out.glob('revision/*.md'),*out.glob('cierre/**/*.md'),out/'evidencias/Cobertura.md']
protect=re.compile(r'(```[\s\S]*?```|`[^`\n]*`|\]\(<[^>]*>\)|\]\([^\n)]*\)|https?://\S+|\b[0-9a-fA-F]{40,64}\b|\b(?:UT|CB|CN|ADAPT|REV|MM|CLI|UI|INT|CIERRE|EXT|AC|RNF)[-_][A-Z0-9_.-]+\b|\b(?:D18|E2:E3|V8|R8|E2E|SHA256|r\d+|p\d+)\b|\b[A-Z][a-z]+\d+[A-Z][A-Za-z]*\b|\b[\w/-]+\.(?:md|json|csv|py|cjs|kt|ts|log|zip|xml|png|patch)\b)')
for p in files:
    s=p.read_text(encoding='utf-8-sig');parts=protect.split(s)
    for i in range(0,len(parts),2):
        x=parts[i]
        x=re.sub(r'\bHU(?=\d)','HU ',x)
        x=re.sub(r'([A-Za-zÁÉÍÓÚÑáéíóúñ])(?=\d)',r'\1 ',x)
        x=re.sub(r'(\d)(?=[A-Za-zÁÉÍÓÚÑáéíóúñ])',r'\1 ',x)
        x=re.sub(r',(?=\S)',', ',x);x=re.sub(r';(?=\S)','; ',x);x=re.sub(r':(?=[A-Za-z0-9])',': ',x)
        x=x.replace('##10.','## 10.').replace('Filas5.','Filas 5.').replace('deHU','de HU').replace('al menos4por','al menos 4 por').replace('No se atribuyen','No se atribuyen')
        parts[i]=x
    p.write_text(''.join(parts),encoding='utf-8')
print('Current support reports and evidence aliases updated; authored prose polished.')
