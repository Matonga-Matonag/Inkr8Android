import hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs/cierre/ui'/sys.argv[1];out.mkdir(exist_ok=True)
adb=str(root/'work/tools/android-sdk/platform-tools/adb.exe');start=time.time();rows=[]
while time.time()-start<300:
    files=subprocess.run([adb,'-s','emulator-5556','exec-out','run-as','com.inkr8','ls','-1','files/capitulo10-evidencias'],capture_output=True).stdout.decode(errors='replace').splitlines()
    for name in files:
        if not re.fullmatch(r'(UI|INT)-[A-Za-z0-9-]+\.(png|txt)',name):continue
        r=subprocess.run([adb,'-s','emulator-5556','exec-out','run-as','com.inkr8','cat','files/capitulo10-evidencias/'+name],capture_output=True);data=r.stdout
        if r.returncode or name.endswith('.png') and (not data.startswith(b'\x89PNG') or not data.endswith(b'IEND\xaeB`\x82')):continue
        dest=out/'capturas'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
    result=out/'resultado.json'
    if result.exists() and result.stat().st_mtime>start:break
    time.sleep(.5)
for file in sorted((out/'capturas').glob('*')):rows.append({'file':file.relative_to(root/'outputs').as_posix(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(out/'Capturas_manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print('Captured files',len(rows))
