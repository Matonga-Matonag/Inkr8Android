import hashlib,json,pathlib,shutil,subprocess,zipfile,uuid
root=pathlib.Path(__file__).resolve().parents[2];out=root/'outputs';saved=root/'work/cierre/insumo';saved.mkdir(parents=True,exist_ok=True)
for name in ['Casos_ejecutados.json','Matriz_Pruebas_y_Trazabilidad.json','Criterios_y_limites.json','Filas_5_6.json','Defectos.json','Resumen_resultados.json','paquetes/Seis_fichas.json','revision/Criterios_Demostrados.json','revision/Auditoria_Rubrica.json']:
    dest=saved/name
    if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(out/name,dest)
readmes={
'backend':'''# Inkr8 — pruebas del capítulo 10

Revisión y entrega del grupo con asistencia de IA declarada. La participación y reproducción individual requieren registro propio.

Node 20.19.0, npm 10.8.2, JDK21 y Firestore emulator1.22.0. Solo demo-inkr8/loopback.

`npm --prefix functions run test:coverage` ejecuta116 casos. `test:integration:coverage` ejecuta100 funcionales, incluidos Home observable y guardas de matchmaking. La concurrencia de50 está separada: `test:concurrency:coverage`; Run-Firestore.ps1 da una instancia nueva a cada suite y conserva ambos resultados.

`test:conformance:ac02` ejecuta6 casos, incluidos2 que demuestran la ausencia de recuperación automática429/503; esos fallos se conservan. La caracterización no aprueba el requisito.

En la copia con la propuesta de producto: `test:matching:policy` y `test:concurrency:odd` comprueban el desempate y51operaciones. Repetir también el perfil original50 con todas sus aserciones. Los parches de producto están separados de este parche de pruebas.

Los SDK OpenAI/evaluadores externos se sustituyen expresamente. No se certifica IA real ni ELO por caracterización. Ver README_Ejecucion.md del expediente para comandos, estados A/B/C y dependencias.
''',
'frontend':'''# Inkr8 — pruebas del capítulo 10

Revisión y entrega del grupo con asistencia de IA declarada. La participación y reproducción individual no se presume.

JDK21, Gradle9.1.0, AndroidSDK36. Ejecutar `:app:testDebugUnitTest --rerun :domain:test --rerun --continue`; son96casos y la base conserva3fallos de contrato de mensaje. La corrección mínima de producto se entrega aparte. Los diez casos ClienteNegativeFlowTest sustituyen tres comparaciones de constantes por fallos/datos inducidos y ViewModels/mapper reales.

`:app:assembleDebug :app:assembleDebugAndroidTest` prepara instrumentadas. Capitulo10VisualTest prueba6casos con Compose real y repositorios controlados; Capitulo10LocalFirestoreTest prueba2casos con SDK Android real y reglas productivas en emulador demo-inkr8 (10.0.2.2:8080), con inicio de perfil/sesión controlado. No se usa Google/OpenAI real.

La aplicación sin google-services.json muestra la pantalla de configuración existente. Los tests de componentes no sustituyen el inicio de sesión real ni una integración cloud. Ver README_Ejecucion.md del expediente para instalación local, capturas auténticas y parches separados.
'''}
metadata=[]
def run(args,cwd):return subprocess.check_output(args,cwd=cwd)
for repo_name in ['backend','frontend']:
    repo=root/'work'/repo_name;(repo/'README_CAPITULO_10.md').write_text(readmes[repo_name],encoding='utf-8')
    subprocess.run(['git','add','-N','.'],cwd=repo,check=True,capture_output=True)
    head=run(['git','rev-parse','HEAD'],repo).decode().strip();branch=run(['git','branch','--show-current'],repo).decode().strip();assert branch=='pruebas/capitulo-10'
    business=['functions/src'] if repo_name=='backend' else ['app/src/main','domain/src/main']
    assert not run(['git','diff','HEAD','--',*business],repo),'Main business source must remain intact'
    patch=run(['git','diff','--binary','--full-index','HEAD'],repo);p=out/'codigo'/(repo_name+'.patch');p.write_bytes(patch)
    changed=run(['git','diff','--name-only','HEAD'],repo).decode().splitlines()
    temp=root/'work/cierre/exportacion'/uuid.uuid4().hex[:8]/repo_name;temp.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out/'codigo'/(repo_name+'_base.zip')) as z:
        assert z.testzip() is None
        for item in z.infolist():assert (temp/item.filename).resolve().is_relative_to(temp.resolve())
        z.extractall(temp)
    result=subprocess.run(['git','apply','--check',str(p)],cwd=temp,capture_output=True,text=True);assert result.returncode==0,result.stderr
    subprocess.run(['git','apply',str(p)],cwd=temp,check=True,capture_output=True)
    shutil.copytree(temp,out/'codigo'/repo_name,dirs_exist_ok=True)
    normal=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
    assert all(normal(repo/file)==normal(out/'codigo'/repo_name/file) for file in changed)
    metadata.append({'repo':repo_name,'base':head,'branch':branch,'changed':changed,'patch_sha256':hashlib.sha256(patch).hexdigest(),'published':False,'business_source_modified':False,'initial_state':'Base original conservada en ZIP; continuación de la revisión técnica','final_status':run(['git','status','--short'],repo).decode(),'applied_to_base_copy_verified':True})
(out/'codigo/Bases_y_parches.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
proposals=[]
for name,folder,scopes in [('backend','propuesta_backend',['functions/src']),('cliente','propuesta_frontend',['app/src/main','domain/src/main'])]:
    repo=root/'work'/folder;branch=run(['git','branch','--show-current'],repo).decode().strip();assert branch=='pruebas/capitulo-10'
    patch=run(['git','diff','--binary','--full-index','HEAD','--',*scopes],repo);changes=run(['git','diff','--name-only','HEAD','--',*scopes],repo).decode().splitlines()
    expected=['functions/src/data/repository/matchmaker.ts'] if name=='backend' else ['app/src/main/java/com/inkr8/presentation/viewmodel/GameViewModel.kt','app/src/main/java/com/inkr8/presentation/viewmodel/SessionViewModel.kt']
    assert changes==expected,(name,changes)
    dest=out/'propuesta_producto'/name;dest.mkdir(parents=True,exist_ok=True);p=dest/('contencion_empates.patch' if name=='backend' else 'mensajes_cliente.patch');p.write_bytes(patch)
    for file in changes:
        target=dest/'fuentes'/file;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/file,target)
    proposal={'repo':name,'base':run(['git','rev-parse','HEAD'],repo).decode().strip(),'branch':branch,'source_changed':changes,'patch':p.relative_to(out).as_posix(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'applied_to_main':False,'published':False}
    (dest/'Metadatos.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2),encoding='utf-8');proposals.append(proposal)
# Keep the established proposal link pointing at the current backend patch.
shutil.copy2(out/'propuesta_producto/backend/contencion_empates.patch',out/'propuesta_producto/contencion_empates.patch')
shutil.copy2(out/'propuesta_producto/backend/fuentes/functions/src/data/repository/matchmaker.ts',out/'propuesta_producto/matchmaker.ts')
shutil.copy2(out/'propuesta_producto/cliente/mensajes_cliente.patch',out/'cierre/cliente/propuesta-cliente.patch')
shutil.copy2(out/'codigo/frontend.patch',out/'cierre/cliente/cliente-pruebas.patch')
(out/'propuesta_producto/Propuestas.json').write_text(json.dumps(proposals,ensure_ascii=False,indent=2),encoding='utf-8')
archive=out/'Entrega_Inkr8_Capitulo_10_Revision_Tecnica.zip'
(out/'cierre/Entrada_Revision.json').write_text(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'19 HU prioritarias + HU 2.2; continúan las bases probadas','original_archive_preserved':True,'branches':[m['branch'] for m in metadata],'review_responsibility':'Grupo, con asistencia IA académica; no se inventan revisiones individuales'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Exported test patches and two isolated product proposals; primary business source intact.')
