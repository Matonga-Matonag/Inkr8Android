import argparse,datetime,hashlib,json,os,pathlib,re,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--project',choices=['base','proposal'],default='base');p.add_argument('--suite',choices=['visual','sdk'],default='visual');a=p.parse_args()
repo=root/'work'/('frontend' if a.project=='base' else 'propuesta_frontend');out=root/'outputs/cierre/ui'/(a.project+'-'+a.suite);out.mkdir(parents=True,exist_ok=True)
sdk=root/'work/tools/android-sdk';adb=str(sdk/'platform-tools/adb.exe');serial='emulator-5556'
assert 'device' in subprocess.check_output([adb,'-s',serial,'get-state'],text=True)
env=os.environ.copy();env.update(JAVA_HOME=str(root/'work/tools/jdk-21.0.9+10'),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),ANDROID_SERIAL=serial,CI='true')
env['PATH']=env['JAVA_HOME']+'/bin'+os.pathsep+env['PATH']
name='Capitulo10VisualTest' if a.suite=='visual' else 'Capitulo10LocalFirestoreTest'
cmd=[str(repo/'gradlew.bat'),':app:connectedDebugAndroidTest','-Pandroid.testInstrumentationRunnerArguments.class=com.inkr8.presentation.'+name,'--no-daemon','--max-workers=2','--console=plain']
if a.suite=='sdk':cmd.append('-Pandroid.testInstrumentationRunnerArguments.localFirestore=true')
meta={'project':a.project,'suite':a.suite,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(repo),'serial':serial,'dependency_scope':'Controlled repositories with real Compose/ViewModels' if a.suite=='visual' else 'Real Android Firestore SDK + local emulator/production rules; initialization/session controlled; no external cloud','source_sha256':{str(f.relative_to(repo)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((repo/'app/src/androidTest').rglob('*.kt'))}}
start=time.monotonic()
prefix='UI-' if a.suite=='visual' else 'INT-'
def collect():
    files=subprocess.run([adb,'-s',serial,'exec-out','run-as','com.inkr8','ls','-1','files/capitulo10-evidencias'],stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout.decode(errors='replace').splitlines()
    for filename in files:
        if not filename.startswith(prefix) or not re.fullmatch(r'[A-Z0-9a-z-]+\.(png|txt)',filename):continue
        fetched=subprocess.run([adb,'-s',serial,'exec-out','run-as','com.inkr8','cat','files/capitulo10-evidencias/'+filename],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if fetched.returncode:continue
        data=fetched.stdout
        if filename.endswith('.png') and (not data.startswith(b'\x89PNG\r\n\x1a\n') or not data.endswith(b'IEND\xaeB`\x82')):continue
        dest=out/'capturas'/filename;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
with (out/'run.log').open('w',encoding='utf-8') as log:
    log.write(json.dumps(meta)+'\n');log.flush();result=subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    # AGP may uninstall the target and erase its private files at teardown.
    # Copy authentic screenshots while instrumentation is still running.
    while result.poll() is None:
        collect();time.sleep(.5)
    collect()
meta.update(exit_code=result.returncode,duration_seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
cases=[]
for file in (repo/'app/build/outputs/androidTest-results/connected/debug').rglob('TEST*.xml'):
    if name not in file.read_text(encoding='utf-8',errors='replace'):continue
    dest=out/'xml'/file.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(file,dest)
    for c in ET.parse(file).getroot().iter('testcase'):
        if name not in c.attrib.get('classname',''):continue
        cases.append({'name':c.attrib['name'],'class':c.attrib.get('classname'),'result':'failed' if c.find('failure') is not None or c.find('error') is not None else 'skipped' if c.find('skipped') is not None else 'passed','seconds':c.attrib.get('time'),'evidence':dest.relative_to(root/'outputs').as_posix()})
meta['cases']=cases;meta['counts']={k:sum(c['result']==k for c in cases) for k in ['passed','failed','skipped']}
for dest in sorted((out/'capturas').glob('*')):
    data=dest.read_bytes()
    meta.setdefault('captures',[]).append({'file':dest.relative_to(root/'outputs').as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(out/'resultado.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:meta[k] for k in ['project','suite','exit_code','counts','duration_seconds']}));sys.exit(result.returncode)
