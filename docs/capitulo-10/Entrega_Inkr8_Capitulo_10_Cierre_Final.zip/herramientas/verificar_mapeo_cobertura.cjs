const fs=require('node:fs'),path=require('node:path'),{SourceMap}=require('node:module'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),dir=process.env.CAP10_V8_DIR||path.join(root,'outputs/evidencias/node20-v8'),repo=path.join(root,'work/backend/functions');
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.json')), rows=[];
for(const filename of files){
  const coverage=JSON.parse(fs.readFileSync(path.join(dir,filename),'utf8'));
  for(const item of coverage.result.filter(x=>x.url.includes('/work/backend/functions/lib/'))){
    const file=require('node:url').fileURLToPath(item.url),js=fs.readFileSync(file,'utf8'),mapFile=file+'.map';if(!fs.existsSync(mapFile))continue;
    const data=JSON.parse(fs.readFileSync(mapFile,'utf8')),map=new SourceMap(data);
    const cache=coverage['source-map-cache']?.[item.url];
    for(const fn of item.functions.filter(f=>f.functionName && ['meritReward','validateWriting','ratingChange','league','mapUser','execute','evaluate'].includes(f.functionName))){
      const offset=fn.ranges[0].startOffset,prefix=js.slice(0,offset),line=prefix.split('\n').length-1,column=prefix.length-prefix.lastIndexOf('\n')-1,entry=map.findEntry(line,column);
      const source=path.resolve(path.dirname(mapFile),data.sourceRoot||'',data.sources[0]);
      rows.push({raw:path.relative(path.join(root,'outputs'),path.join(dir,filename)),function:fn.functionName,compiled:path.relative(repo,file),compiled_line:line+1,source:path.relative(repo,source),source_line:entry.originalLine+1,
        source_sha256:crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),source_map_in_v8_cache:!!cache,
        invocations:fn.ranges[0].count,zero_count_ranges:fn.ranges.filter(r=>r.count===0),note:'Los rangos V8 son bloques de JS compilado. No son el CFG manual ni un porcentaje de caminos.'});
    }
  }
}
fs.writeFileSync(path.join(root,'outputs/evidencias/verificacion_mapeo_cobertura.json'),JSON.stringify(rows,null,2));
console.log(rows.filter(x=>x.function==='meritReward'||x.function==='mapUser'));
