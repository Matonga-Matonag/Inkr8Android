import argparse, datetime, json, os, pathlib, subprocess, sys, time, shutil
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
p = argparse.ArgumentParser()
p.add_argument('label'); p.add_argument('--cwd', default='work/backend')
p.add_argument('--evidence-subdir',default='')
p.add_argument('--node20', action='store_true'); p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args(); root = pathlib.Path(__file__).resolve().parent.parent
out = root/'outputs'/'evidencias'/a.evidence_subdir; out.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
if a.node20:
    env['PATH'] = str(root/'work/tools/node-v20.19.0-win-x64') + os.pathsep + env['PATH']
env['JAVA_HOME'] = r'C:\Users\marco\.jdks\temurin-25.0.4.1'
if (root/'work/tools/java21_path.txt').exists():
    env['JAVA_HOME']=(root/'work/tools/java21_path.txt').read_text(encoding='utf-8').strip()
env['PATH'] = env['JAVA_HOME'] + r'\bin' + os.pathsep + env['PATH']
env['CAP10_EVIDENCE_DIR']=str(out)
if (root/'work/tools/android-sdk/platforms/android-36/android.jar').exists():
    env['ANDROID_HOME']=str(root/'work/tools/android-sdk')
    env['ANDROID_SDK_ROOT']=env['ANDROID_HOME']
env['CI'] = 'true'; env['NO_COLOR'] = '1'; env['GIT_TERMINAL_PROMPT'] = '0'
cmd = a.command[1:] if a.command and a.command[0] == '--' else a.command
if cmd and ('/' in cmd[0] or '\\' in cmd[0]) and not pathlib.Path(cmd[0]).is_absolute():
    cmd[0] = str((root/a.cwd/cmd[0]).resolve())
elif cmd:
    cmd[0] = shutil.which(cmd[0],path=env['PATH']) or cmd[0]
meta = {'label':a.label, 'cwd':str((root/a.cwd).resolve()),'command':cmd,
        'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'node20_path':str(root/'work/tools/node-v20.19.0-win-x64') if a.node20 else None,
        'JAVA_HOME':env['JAVA_HOME']}
meta['firestore_emulator_override']=env.get('FIRESTORE_EMULATOR_BINARY_PATH')
meta['node_version_at_explicit_path']=subprocess.check_output([shutil.which('node',path=env['PATH']),'--version'],env=env).decode().strip()
start = time.perf_counter()
with (out/(a.label+'.log')).open('w', encoding='utf-8') as f:
    f.write(json.dumps(meta,ensure_ascii=False)+'\n'); f.flush()
    process = subprocess.Popen(cmd,cwd=meta['cwd'],env=env,stdout=f,stderr=subprocess.STDOUT,shell=False)
    code = process.wait()
meta.update(exit_code=code,duration_seconds=time.perf_counter()-start,
            end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/(a.label+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
if (root/a.cwd/'firestore-debug.log').exists() and 'emulators:exec' in cmd:
    shutil.copy2(root/a.cwd/'firestore-debug.log',out/(a.label+'-emulator.log'))
print(json.dumps(meta,ensure_ascii=False)); print((out/(a.label+'.log')).read_text(encoding='utf-8')[-1800:])
sys.exit(code)
