# Inkr8 — propuestas mínimas separadas

Las fuentes de negocio de la base no se modificaron. No se publicó ni integró ninguno de estos parches. Aplicar después del parche de pruebas, en otra copia del SHA base.

| Propuesta | Parche | Justificación y validación |
|---|---|---|
| Backend,1 archivo | [contencion_empates.patch](backend/contencion_empates.patch) | [Validación ampliada](../cierre/matchmaking/Validacion_Final.md):100 funcionales,116 unidad,3×50y51, política y guardas. |
| Cliente,2 archivos | [mensajes_cliente.patch](cliente/mensajes_cliente.patch) | [Reporte](../cierre/cliente/Reporte_Cliente.md):96 JVM,6 UI y2 SDK local aprobados. |

Recomendación técnica favorable en el alcance probado. Incorporación y política de desempate: EXT-09. ELO,429/503 y mensajes contradictorios no se corrigen unilateralmente con estos parches. [Metadatos y hashes](Propuestas.json).
