# Cobertura medida del cierre

Node 20 mide JS compilado con sourcemaps hacia TS. Se muestran archivos de producción; el total del runner que incluye tests se excluye como porcentaje de producto. La cobertura del caso 50 se conserva aunque falle. Los 67 casos principales y 42 caminos son conteos distintos de cobertura de líneas/ramas.

| Copia/suite | Archivo | Líneas% | Ramas% | Funciones% |
|---|---|---|---|---|
| base-unidad | src/data/dto/userDto.ts | 66.67 | 100.0 | 100.0 |
| base-unidad | src/data/source/openAiWritingEvaluator.ts | 100.0 | 100.0 | 100.0 |
| base-unidad | src/domain/model/models.ts | 42.86 | 100.0 | 100.0 |
| base-unidad | src/domain/policy/evaluationPolicy.ts | 82.86 | 100.0 | 100.0 |
| base-unidad | src/domain/policy/gamePolicy.ts | 84.0 | 100.0 | 100.0 |
| base-unidad | src/domain/policy/matchingPolicy.ts | 53.33 | 100.0 | 66.67 |
| base-unidad | src/domain/policy/seasonPolicy.ts | 75.0 | 100.0 | 100.0 |
| base-unidad | src/domain/policy/userPolicy.ts | 87.5 | 100.0 | 100.0 |
| base-unidad | src/domain/usecase/contentUseCases.ts | 75.0 | 88.24 | 81.82 |
| base-unidad | src/domain/usecase/gameUseCases.ts | 81.13 | 86.96 | 50.0 |
| base-unidad | src/domain/usecase/progressUseCases.ts | 95.24 | 80.0 | 90.0 |
| base-unidad | src/domain/usecase/resetLeagues.ts | 83.33 | 100.0 | 100.0 |
| base-funcional | src/data/dto/userDto.ts | 66.67 | 62.5 | 100.0 |
| base-funcional | src/data/mapper/gameMapper.ts | 57.14 | 100.0 | 100.0 |
| base-funcional | src/data/repository/firebaseContentRepository.ts | 97.62 | 82.22 | 100.0 |
| base-funcional | src/data/repository/firebaseGameRepository.ts | 99.01 | 92.73 | 100.0 |
| base-funcional | src/data/repository/firebaseMatchRepository.ts | 91.43 | 100.0 | 100.0 |
| base-funcional | src/data/repository/firebaseProgressRepository.ts | 78.26 | 88.89 | 100.0 |
| base-funcional | src/data/repository/firebaseSeasonRepository.ts | 98.41 | 66.67 | 100.0 |
| base-funcional | src/data/repository/firebaseUserRepository.ts | 98.0 | 90.91 | 100.0 |
| base-funcional | src/data/repository/matchBaseline.ts | 91.18 | 91.3 | 100.0 |
| base-funcional | src/data/repository/matchmaker.ts | 94.0 | 100.0 | 100.0 |
| base-funcional | src/data/repository/matchRecovery.ts | 91.3 | 100.0 | 100.0 |
| base-funcional | src/data/repository/seasonWrites.ts | 76.19 | 100.0 | 100.0 |
| base-funcional | src/domain/model/models.ts | 42.86 | 100.0 | 100.0 |
| base-funcional | src/domain/policy/evaluationPolicy.ts | 68.57 | 50.0 | 100.0 |
| base-funcional | src/domain/policy/gamePolicy.ts | 80.0 | 91.89 | 100.0 |
| base-funcional | src/domain/policy/matchingPolicy.ts | 66.67 | 85.71 | 100.0 |
| base-funcional | src/domain/policy/seasonPolicy.ts | 75.0 | 100.0 | 100.0 |
| base-funcional | src/domain/policy/submissionIdentity.ts | 81.82 | 66.67 | 100.0 |
| base-funcional | src/domain/policy/userPolicy.ts | 87.5 | 100.0 | 100.0 |
| base-funcional | src/domain/usecase/contentUseCases.ts | 98.08 | 90.48 | 100.0 |
| base-funcional | src/domain/usecase/gameUseCases.ts | 90.57 | 84.62 | 100.0 |
| base-funcional | src/domain/usecase/progressUseCases.ts | 95.24 | 100.0 | 100.0 |
| base-funcional | src/presentation/handlers/callables.ts | 77.78 | 72.73 | 100.0 |
| base-funcional | src/presentation/handlers/contentHandlers.ts | 85.71 | 52.63 | 100.0 |
| base-funcional | src/presentation/handlers/gameHandlers.ts | 56.0 | 60.0 | 80.0 |
| base-carga 50 | src/data/dto/userDto.ts | 66.67 | 33.33 | 100.0 |
| base-carga 50 | src/data/mapper/gameMapper.ts | 57.14 | 66.67 | 100.0 |
| base-carga 50 | src/data/repository/firebaseContentRepository.ts | 97.62 | 50.0 | 0.0 |
| base-carga 50 | src/data/repository/firebaseGameRepository.ts | 65.35 | 47.62 | 69.23 |
| base-carga 50 | src/data/repository/firebaseMatchRepository.ts | 91.43 | 100.0 | 100.0 |
| base-carga 50 | src/data/repository/firebaseUserRepository.ts | 64.0 | 77.78 | 66.67 |
| base-carga 50 | src/data/repository/matchBaseline.ts | 76.47 | 41.67 | 66.67 |
| base-carga 50 | src/data/repository/matchmaker.ts | 94.0 | 85.0 | 100.0 |
| base-carga 50 | src/data/repository/matchRecovery.ts | 47.83 | 100.0 | 75.0 |
| base-carga 50 | src/data/repository/seasonWrites.ts | 52.38 | 75.0 | 100.0 |
| base-carga 50 | src/domain/model/models.ts | 42.86 | 50.0 | 0.0 |
| base-carga 50 | src/domain/policy/evaluationPolicy.ts | 11.43 | 100.0 | 0.0 |
| base-carga 50 | src/domain/policy/gamePolicy.ts | 68.0 | 50.0 | 100.0 |
| base-carga 50 | src/domain/policy/matchingPolicy.ts | 40.0 | 100.0 | 33.33 |
| base-carga 50 | src/domain/policy/seasonPolicy.ts | 66.67 | 80.0 | 100.0 |
| base-carga 50 | src/domain/policy/userPolicy.ts | 12.5 | 100.0 | 0.0 |
| base-carga 50 | src/domain/usecase/gameUseCases.ts | 41.51 | 20.0 | 0.0 |
| propuesta-unidad | src/data/dto/userDto.ts | 66.67 | 100.0 | 100.0 |
| propuesta-unidad | src/data/source/openAiWritingEvaluator.ts | 100.0 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/model/models.ts | 42.86 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/policy/evaluationPolicy.ts | 82.86 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/policy/gamePolicy.ts | 84.0 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/policy/matchingPolicy.ts | 53.33 | 100.0 | 66.67 |
| propuesta-unidad | src/domain/policy/seasonPolicy.ts | 75.0 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/policy/userPolicy.ts | 87.5 | 100.0 | 100.0 |
| propuesta-unidad | src/domain/usecase/contentUseCases.ts | 75.0 | 88.24 | 81.82 |
| propuesta-unidad | src/domain/usecase/gameUseCases.ts | 81.13 | 86.96 | 50.0 |
| propuesta-unidad | src/domain/usecase/progressUseCases.ts | 95.24 | 80.0 | 90.0 |
| propuesta-unidad | src/domain/usecase/resetLeagues.ts | 83.33 | 100.0 | 100.0 |
| propuesta-funcional | src/data/dto/userDto.ts | 66.67 | 62.5 | 100.0 |
| propuesta-funcional | src/data/mapper/gameMapper.ts | 57.14 | 100.0 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseContentRepository.ts | 97.62 | 82.22 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseGameRepository.ts | 99.01 | 92.73 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseMatchRepository.ts | 91.43 | 100.0 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseProgressRepository.ts | 78.26 | 88.89 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseSeasonRepository.ts | 98.41 | 66.67 | 100.0 |
| propuesta-funcional | src/data/repository/firebaseUserRepository.ts | 98.0 | 90.91 | 100.0 |
| propuesta-funcional | src/data/repository/matchBaseline.ts | 91.18 | 91.3 | 100.0 |
| propuesta-funcional | src/data/repository/matchmaker.ts | 94.55 | 100.0 | 100.0 |
| propuesta-funcional | src/data/repository/matchRecovery.ts | 91.3 | 100.0 | 100.0 |
| propuesta-funcional | src/data/repository/seasonWrites.ts | 76.19 | 100.0 | 100.0 |
| propuesta-funcional | src/domain/model/models.ts | 42.86 | 100.0 | 100.0 |
| propuesta-funcional | src/domain/policy/evaluationPolicy.ts | 68.57 | 50.0 | 100.0 |
| propuesta-funcional | src/domain/policy/gamePolicy.ts | 80.0 | 91.89 | 100.0 |
| propuesta-funcional | src/domain/policy/matchingPolicy.ts | 66.67 | 85.71 | 100.0 |
| propuesta-funcional | src/domain/policy/seasonPolicy.ts | 75.0 | 100.0 | 100.0 |
| propuesta-funcional | src/domain/policy/submissionIdentity.ts | 81.82 | 66.67 | 100.0 |
| propuesta-funcional | src/domain/policy/userPolicy.ts | 87.5 | 100.0 | 100.0 |
| propuesta-funcional | src/domain/usecase/contentUseCases.ts | 98.08 | 90.48 | 100.0 |
| propuesta-funcional | src/domain/usecase/gameUseCases.ts | 90.57 | 84.62 | 100.0 |
| propuesta-funcional | src/domain/usecase/progressUseCases.ts | 95.24 | 100.0 | 100.0 |
| propuesta-funcional | src/presentation/handlers/callables.ts | 77.78 | 72.73 | 100.0 |
| propuesta-funcional | src/presentation/handlers/contentHandlers.ts | 85.71 | 52.63 | 100.0 |
| propuesta-funcional | src/presentation/handlers/gameHandlers.ts | 56.0 | 60.0 | 80.0 |

## Android JVM

JaCoCo conserva bytecode generado y pantallas sin tests; no se excluyen para elevar cifras. Esta medición es JVM, no cobertura de las instrumentadas UI. Los tests se forzaron con --rerun; los informes se generaron después, sin convertir exit 1 en aprobación.

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/domain | módulo completo | 16/73 (21.92%) | 20/32 (62.5%) | 11/150 (7.33%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/domain | com/inkr 8/domain/policy/GamePolicy | 10/10 (100.0%) | 20/20 (100.0%) | 3/3 (100.0%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/app | módulo completo | 237/896 (26.45%) | 141/524 (26.91%) | 115/413 (27.85%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/app | com/inkr 8/presentation/viewmodel/GameViewModel | 63/69 (91.3%) | 35/54 (64.81%) | 23/27 (85.19%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/app | com/inkr 8/presentation/viewmodel/SessionViewModel | 14/15 (93.33%) | 2/2 (100.0%) | 6/7 (85.71%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| base/app | com/inkr 8/data/mapper/DomainMappersKt | 17/27 (62.96%) | 50/84 (59.52%) | 2/8 (25.0%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/domain | módulo completo | 16/73 (21.92%) | 20/32 (62.5%) | 11/150 (7.33%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/domain | com/inkr 8/domain/policy/GamePolicy | 10/10 (100.0%) | 20/20 (100.0%) | 3/3 (100.0%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/app | módulo completo | 243/903 (26.91%) | 145/530 (27.36%) | 116/414 (28.02%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/app | com/inkr 8/presentation/viewmodel/GameViewModel | 63/69 (91.3%) | 35/54 (64.81%) | 23/27 (85.19%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/app | com/inkr 8/presentation/viewmodel/SessionViewModel | 14/15 (93.33%) | 2/2 (100.0%) | 6/7 (85.71%) |

| Copia/módulo | Alcance | Líneas | Ramas | Métodos |
|---|---|---|---|---|
| proposal/app | com/inkr 8/data/mapper/DomainMappersKt | 17/27 (62.96%) | 50/84 (59.52%) | 2/8 (25.0%) |

Fuentes procesables: [Node JSON](Cobertura_archivos.json), [CSV](Cobertura_archivos.csv), [JaCoCo JSON](Cobertura_Android.json). Los XML auténticos están bajo cierre/cliente/*-all-coverage-jacoco; el código de salida de pruebas y reporte se registra por separado.
