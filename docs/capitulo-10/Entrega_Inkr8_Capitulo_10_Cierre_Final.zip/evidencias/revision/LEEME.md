# Índice de evidencia de revisión

La base final se cuenta solo desde [unidad](../final-node20-unit.log), [funcional](../final-firestore-functional.log) y [carga](../final-firestore-concurrency.log), más Android previamente ejecutado. Total único 257: 256 aprobados y uno fallido. Las fechas/órdenes exactas están en los JSON compañeros de cada log.

La propuesta final se cuenta por separado: [p05 funcional](p05-propuesta-functional/run-01.log), [p06 unidad](p06/p06-propuesta-unit.log) y [p07 carga](p07-propuesta-final-load/run-01.log): 168/168, sin omitidos. p04 son tres repeticiones anteriores del mismo cambio mínimo; no crean más casos únicos.

r01..r06 contrastan entorno, transacciones mínimas y hotspots. r07/r08 son 20 ejecuciones aisladas de 48 h en dos versiones del emulador; r09 añade cinco recuperaciones después de carga. Estas 25 ejecuciones aprobadas preceden al ajuste de espera y no demuestran que ese ajuste elimine la causa histórica.

p01, p02 y p03 contienen ensayos intermedios de propuesta. El cambio experimental de seasonWrites fue restaurado y no forma parte del parche final. entrega_anterior preserva resultados reemplazados por los cierres actuales; no se suman al total nuevo. [Investigación y límites](../../revision/Investigacion_Firestore.md).
