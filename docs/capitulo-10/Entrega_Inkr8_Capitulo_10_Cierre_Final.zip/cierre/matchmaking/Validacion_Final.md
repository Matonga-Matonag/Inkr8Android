# Validación final de la propuesta de matchmaking

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

**Recomendación: incorporar el parche mínimo tras aceptar explícitamente el nuevo desempate y revisar el diff.** En el alcance local ensayado reduce la contención del recorrido original y conserva todas las guardas. No se amplió ni paginó la consulta, ni se cambió ELO o la política de reintentos. La base permanece intacta.

| Propuesta aislada | Resultado | Evidencia |
|---|---|---|
| Backend: unidad/adaptador | 116/116 | [log](<../../evidencias/cierre/backend/propuesta-unit-final.log>) |
| Backend: funcional ampliada | 100/100, incluidos 20 de guardas/ventana | [log](<evidencias/propuesta-functional-final/run-01.log>) |
| Backend: desempate propuesto | 1/1 | [log](<evidencias/propuesta-politica-final/run-01.log>) |
| Backend: original 50, tres instancias nuevas | 3×50/50, 25 parejas, pico 50, cero violaciones | [secuencia](<Secuencia_Cargas_Final.json>) |
| Backend: grupo impar 51 | 51/51 llamadas; 50 MATCHED, 25 parejas, 1 pendiente, pico 51 | [JSON](<evidencias/propuesta-51-final/run-01/MM-LOAD-51.json>) |
| Cliente: JVM | 96/96 | [log](<../cliente/proposal-all-coverage.log>) |
| Cliente: UI local | 6/6 | [instrumentación](<../ui/proposal-visual/instrumentation.log>) |
| Cliente: SDK local y pantalla | 2/2 | [instrumentación](<../ui/proposal-sdk/instrumentation.log>) |

## Ventana y guardas

Los 20 casos funcionales pasan tanto en base como en propuesta. Incluyen grupos concurrentes de 3 y 5, vecino incompatible con fallback, mismo autor, delta 31 rechazado/30 admitido, perfil cerrado/ausente, Ranked/Práctica, writingMode, evaluación presente, estados, temporada propia/rival y worker con temporada capturada antigua. Se conserva prioridad entre timestamps distintos; MM-POLICY-01 caracteriza la selección nueva dentro del timestamp mínimo empatado.

MM-FUNC-17 comprueba exactamente 100 documentos con rival elegible al final. MM-FUNC-18 comprueba 101 documentos con el rival elegible fuera de la consulta: no es encontrado. MM-FUNC-19 demuestra que la propia partida fuera de 100 puede encontrar rival dentro por fallback. MM-FUNC-20 demuestra 102 documentos con propia y rival elegible fuera: ambos permanecen pendientes. **Los mismos cuatro resultados se reproducen en la base original.** Es una limitación heredada de `limit(100)`, no un defecto introducido por el desempate. No se promete ausencia de inanición ni resolución de toda cola heterogénea; el fallback 48 h no equivale a paginación.

La propuesta no requirió otra modificación de negocio tras estos ensayos. Los snapshots pueden cambiar, los grupos impares/incompatibles usan fallback y la validación no prueba capacidad cloud. El perfil 51 comprueba realmente 51 llamadas activas y termina con una pendiente legítima. Los tres perfiles 50 conservaron cuerpo y aserciones originales, sin serializar, rebajar concurrencia ni aprobar solo las parejas resueltas.

Fuentes: [base 20 guardas](evidencias/base-functional-final/run-01.log), [propuesta 20 guardas](evidencias/propuesta-functional-final/run-01.log), [secuencia aislada](Secuencia_Cargas_Final.json), [separación sin cambiar cuerpo 51](Separacion_impar.json), [parche](../../propuesta_producto/backend/contencion_empates.patch). Los logs funcionales incluyen 100 casos totales, no 100 casos nuevos de matchmaking.
