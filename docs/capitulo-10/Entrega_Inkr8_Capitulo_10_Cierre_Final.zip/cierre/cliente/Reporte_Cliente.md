# Cierre de negativos del cliente

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

Se sustituyeron tres comparaciones de constantes por 10 casos con fallos de dependencia o datos inválidos. La base reejecutada tiene 96 JVM: 93 aprueban y 3 fallan; la propuesta mínima tiene 96/96. Las pruebas usan ViewModels, casos de uso y mapper reales. Los repositorios controlados inducen el estímulo, y se comprueban estado, mensaje y ausencia de nuevo start/submit/retry, logout o actualización de perfil.

| HU | Base y causa | Corrección separada y alcance |
|---|---|---|
| 3.6 | CLI_HU36_C01 y UI_HU36_C01 reproducen mensaje de progreso ante fallo de observeUser. INT_HU36_C02 lo confirma con PERMISSION_DENIED real del SDK local. | SessionViewModel separa fallo de inicialización (mensaje de progreso conservado) del fallo de observación de perfil (Server failure). No reemplaza todos los errores de sesión. |
| 3.8 | CLI_HU38_C01/C04 y UI_HU38_C01/C03 reproducen mensaje crudo al observar una Ranked EVALUATED o PENDING tras envío. | GameViewModel traduce ese error al literal de resultado. C05 conserva error de red de DRAFT; cancelaciones y envío no se cambian. El límite PENDING/EVALUATED se justifica por el texto enviado/espera de resultado y queda explícito para revisión. |
| 3.9 | CLI_HU39_C01/C02 y UI_HU39_C01/C02 aprueban. Un ratingChange no numérico atraviesa mapper y VM como null; UI muestra Server failure; reconexión restaura−6 sin otro envío. | No requiere corrección de producto. No inventa cero ni decide ELO. |

La variante HU 3.8 MATCHED con resultado inválido también muestra el aviso en la base, pero no sustituye al error de I/O del observador: son rutas distintas. Los literales esperados son del requisito y no una constante comparada consigo misma.

Evidencias: [JVM base](base-all-coverage.log), [JVM propuesta](proposal-all-coverage.log), [pruebas](../../codigo/frontend.patch), [corrección mínima](../../propuesta_producto/cliente/mensajes_cliente.patch), [UI y SDK con capturas](../ui/Indice_Capturas.md). Los resultados de la propuesta no aprueban los casos fallidos de la base.
