"""Run the two new suites on an exclusively owned local emulator.

Run from the workspace root. No product source, package script or prior test is
changed. The caller must coordinate ownership of the emulator port first.
"""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import re
import socket
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--backend', required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--node', default='work/tools/node-v20.19.0-win-x64/node.exe')
parser.add_argument('--java', default='work/tools/jdk-21.0.9+10/bin/java.exe')
parser.add_argument('--jar', default='work/revision/cloud-firestore-emulator-v1.22.0.jar')
parser.add_argument('--port', type=int, default=8080)
parser.add_argument('--conformance-only', action='store_true')
args = parser.parse_args()
if not re.fullmatch(r'[A-Za-z0-9_-]+', args.label):
    parser.error('label must be a plain filename segment')
root = pathlib.Path.cwd()
backend, node, java, jar = [pathlib.Path(p).resolve() for p in [args.backend, args.node, args.java, args.jar]]
for file in [node, java, jar, backend / 'functions/package.json']:
    if not file.is_file():
        parser.error(f'Missing required file: {file}')
cn = root / 'outputs/cierre/caja_negra' / args.label
ac02 = root / 'outputs/cierre/decisiones' / args.label
cn.mkdir(parents=True, exist_ok=True)
ac02.mkdir(parents=True, exist_ok=True)
with socket.socket() as probe:
    if probe.connect_ex(('127.0.0.1', args.port)) == 0:
        raise RuntimeError('Emulator port is busy; do not attach to or stop another experiment')
env = os.environ.copy()
env.update(PATH=str(node.parent) + os.pathsep + env.get('PATH', ''),
           FIRESTORE_EMULATOR_HOST=f'127.0.0.1:{args.port}', GCLOUD_PROJECT='demo-inkr8', CI='true', NO_COLOR='1')
env.pop('CIERRE_EXIGIR_AC02', None)
env['CIERRE_CN_RENZO_EVIDENCE_DIR'] = str(cn)
env['CIERRE_AC02_EVIDENCE_DIR'] = str(ac02)
if args.conformance_only:
    env['CIERRE_EXIGIR_AC02'] = '1'
meta = {
    'label': args.label, 'backend': str(backend), 'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'jar_sha256': hashlib.sha256(jar.read_bytes()).hexdigest(), 'conformance_only': args.conformance_only,
    'branch': subprocess.check_output(['git', '-C', str(backend), 'branch', '--show-current'], text=True).strip(),
    'head': subprocess.check_output(['git', '-C', str(backend), 'rev-parse', 'HEAD'], text=True).strip(),
    'test_files': {}, 'results': [],
}
for name in ['cierre.cn-renzo.test.cjs', 'cierre.ac02.test.cjs']:
    file = backend / 'functions/integration' / name
    meta['test_files'][name] = hashlib.sha256(file.read_bytes()).hexdigest()
build = [str(node), str(node.parent / 'node_modules/npm/bin/npm-cli.js'), '--prefix', 'functions', 'run', 'build']
with (cn / 'build.log').open('w', encoding='utf-8') as log:
    result = subprocess.run(build, cwd=backend, env=env, stdout=log, stderr=subprocess.STDOUT)
meta['build_exit_code'] = result.returncode
if result.returncode:
    (cn / 'experiment.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    sys.exit(result.returncode)
server_command = [str(java), '-Duser.language=en', '-jar', str(jar), '--host', '127.0.0.1', '--port', str(args.port),
                  '--project_id', 'demo-inkr8', '--single_project_mode', '--rules', str(backend / 'firestore.rules')]
meta['server_command'] = server_command
creationflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
with (cn / 'emulator.log').open('w', encoding='utf-8') as server_log:
    server = subprocess.Popen(server_command, cwd=backend, env=env, stdout=server_log, stderr=subprocess.STDOUT, creationflags=creationflags)
    try:
        deadline = time.monotonic() + 60
        ready = False
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError('Owned emulator exited during startup; see emulator.log')
            with socket.socket() as probe:
                if probe.connect_ex(('127.0.0.1', args.port)) == 0:
                    ready = True
                    break
            time.sleep(.1)
        if not ready:
            raise RuntimeError('Owned emulator did not become ready within 60 seconds')
        cases = [] if args.conformance_only else [('cn_renzo', cn, 'cierre.cn-renzo.test.cjs')]
        cases.append(('ac02', ac02, 'cierre.ac02.test.cjs'))
        for suite, directory, name in cases:
            command = [str(node), '--test', '--test-reporter=tap', '--test-concurrency=1', '--experimental-test-coverage']
            if args.conformance_only:
                command.append('--test-name-pattern=CONFORMIDAD')
            command.append('functions/integration/' + name)
            started = time.monotonic()
            with (directory / 'run.log').open('w', encoding='utf-8') as log:
                log.write(json.dumps({'command': command, 'cwd': str(backend), 'FIRESTORE_EMULATOR_HOST': env['FIRESTORE_EMULATOR_HOST'], 'CIERRE_EXIGIR_AC02': env.get('CIERRE_EXIGIR_AC02')}) + '\n')
                log.flush()
                completed = subprocess.run(command, cwd=backend, env=env, stdout=log, stderr=subprocess.STDOUT)
            text = (directory / 'run.log').read_text(encoding='utf-8')
            counts = {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|skipped) (\d+)\s*$', text, re.M)}
            row = {'suite': suite, 'exit_code': completed.returncode, 'duration_seconds': time.monotonic() - started, 'log': str((directory / 'run.log').relative_to(root)), **counts}
            meta['results'].append(row)
            print(json.dumps(row), flush=True)
    finally:
        server.terminate()
        try:
            server.wait(timeout=8)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait()
        meta['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        for directory in [cn, ac02]:
            (directory / 'experiment.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')
sys.exit(max(row['exit_code'] for row in meta['results']))
