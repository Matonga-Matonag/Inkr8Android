# CN de Renzo: Home y metadatos con operación real

El grupo es responsable de la revisión y entrega, con asistencia IA académica. Esta validación técnica no atribuye revisiones, aportes ni reproducciones individuales que no estén registrados.

La candidata principal pasa a **`GetDailyHome.execute → FirebaseContentRepository.dailyWord → Firestore`**. Los casos no llaman a `hasMetadata`; ese helper queda como evidencia auxiliar de la entrega anterior. Se usan el caso de uso, repositorio y Firestore emulado reales. Se controla el reloj y se prepara el catálogo; no hay un doble del repositorio.

## Frontera y mínimo de campos

| Entrada desde `words/fixture-word` | Salida observable en Home | Particiones |
|---|---|---|
| `word` | `word.text` | `ink` / `quill`; vacío / espacios / ausente |
| `definition` | `word.definition` | Dos definiciones no vacías; vacío / espacios / ausente |
| `phonetic` | `word.phonetic` | Dos cadenas fonéticas no vacías; vacío / espacios / ausente |
| `partOfSpeech` | `word.partOfSpeech` | `noun` / `mass noun`; vacío / espacios / ausente |
| `rarity` | `word.rarity` | `common` / `rare`; vacío / espacios / ausente |

Son cinco campos distintos **del catálogo persistido**. El callable `getHome` no recibe campos de payload; `GetDailyHome.execute()` no tiene argumentos y `dailyWord(day)` recibe directamente uno. Por ello, esta candidata mejora la observación funcional y elimina la dependencia del helper privado, pero **no certifica por sí sola que el docente acepte el mínimo de entradas de la rúbrica**. `sentence`, `isActive`, `day`, salidas y contexto no se suman artificialmente para llegar a cinco.

El límite defendible es cadena vacía después de `trim` frente a cadena no vacía. La implementación no define longitudes máximas ni valida la exactitud lingüística de fonética, categoría o rareza; los casos no inventan esas reglas. Las alternativas no vacías prueban preservación y uso de cada campo, no calidad semántica del catálogo.

## Casos y oráculos

Se prepararon **25 casos nuevos** en `functions/integration/cierre.cn-renzo.test.cjs`, todos con operación pública y efectos persistidos:

- C01: cinco metadatos completos; Home y caché exactos, fuente intacta.
- C02–C06: un campo correcto cambia cada vez; se conserva en Home y caché sin alterar los demás.
- C07–C21: vacío, espacios y ausencia de cada campo; error preciso, caché no creado y catálogo intacto.
- C22: caché válido funciona sin catálogo.
- C23: caché incompleto se repara con la palabra activa del mismo texto.
- C24: texto del día sin fuente activa falla y conserva el caché previo; no cambia silenciosamente la palabra del día.
- C25: una palabra inactiva no se selecciona ni crea caché.

Los oráculos son literales de salida, error y ausencia de escrituras indebidas. Si `word` está vacío/ausente, la carga del catálogo lo filtra y produce «No hay palabras activas disponibles.». Si falta otro metadato, produce «La palabra del momento no tiene su información completa.». No se exige el mismo mensaje para dos rutas distintas.

El [diseño JSON](Diseno_Casos_CN_Renzo.json) conserva los datos y la pregunta docente. **A: 25/25 aprobados en la base y en la propuesta, además de la suite funcional final 100/100.** Se midió cobertura por archivo; ver [cobertura](../../evidencias/Cobertura.md). La aceptación docente sigue en EXT-01.

## Reproducción

Desde la raíz del backend, con Node 20, Java 21, dependencias instaladas y el puerto 8080 libre:

```powershell
npm --prefix functions run build
firebase emulators:exec --project demo-inkr8 --only firestore "node --test --test-concurrency=1 --experimental-test-coverage functions/integration/cierre.cn-renzo.test.cjs"
```

Para guardar observaciones estructuradas además del log, fijar `CIERRE_CN_RENZO_EVIDENCE_DIR` al directorio de evidencia antes de ejecutar. El nuevo archivo está incluido expresamente en test:integration y sus25casos forman parte de los100funcionales finales. El código de producto de la base no cambió.

## Decisión exacta para Wong

«Para la funcionalidad Home, ¿acepta como caja negra los cinco campos de entrada del catálogo Firestore —`word`, `definition`, `phonetic`, `partOfSpeech` y `rarity`— cuando se varía cada uno y se observa el resultado/error y la caché mediante `GetDailyHome.execute` y `dailyWord` reales, sin llamar helpers privados? `getHome` no tiene payload y `dailyWord` recibe solo `day`: ¿son admisibles esos datos persistidos o exige cinco parámetros/campos de una solicitud o formulario? Si los exige, ¿permite compartir entre integrantes una operación real de cinco campos con escenarios y aportes individuales distintos?»

Una respuesta favorable debe identificar esta frontera concreta. Una respuesta negativa deja como opciones reasignar una operación real de al menos cinco campos —por ejemplo `start`, con escenarios y aportes propios si se permite compartir— o elegir otra funcionalidad existente que el grupo pueda demostrar. No se propone añadir campos al producto para satisfacer el conteo.

La ficha traza HU1.5/1.6; esta CN corresponde a HU1.5 y la unitaria GetWordExample aporta evidencia a HU1.6. Esta CN demuestra carga y conservación de contenido, integridad del caché y rechazos. No prueba pantalla, botones, reproducción de audio, autenticación real, IA ni participación individual. El criterio completo de Home conserva esas evidencias pendientes. Fuente de diseño: [rúbrica y alcance documental](../../fuentes/Auditoria_Documental_Inkr8.md) y [patrones docentes revisados](../../fuentes/Referencia_Henry_Wong_Inkr8.md).
