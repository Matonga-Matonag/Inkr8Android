# Capturas auténticas y alcance de integración

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

Se usó un AVD nuevo Inkr8_Capitulo 10, API 36 default x 86_64/WHPX, 720×1280. Las imágenes proceden de UiAutomation.takeScreenshot durante los tests, con barrera de frame PixelCopy. Se copian sin editar. Las pruebas de GameScreen son de componente real en un contenedor temático de prueba; Profile usa Inkr8Root/MainScreen real. No son imágenes generadas ni pantallas de un servicio remoto.

| Copia | Caso/captura | Archivo | SHA256 |
|---|---|---|---|
| base | UI-HU36-C01 | [PNG](base-visual/capturas/UI-HU36-C01.png) | ca69eeeae04cb9a42d970a2ad48b5bdb81af0f49c67820f0231f9eb3d18e89cf |
| base | UI-HU38-C01 | [PNG](base-visual/capturas/UI-HU38-C01.png) | b3e59c81e9253aa2e3dad7cef323a447d11b92c252657c3099be19f27f4ad28a |
| base | UI-HU38-C02 | [PNG](base-visual/capturas/UI-HU38-C02.png) | 605742b0d7724926196e9da894c7f41568183cea5a06bdada55e6deca268bd0b |
| base | UI-HU38-C03 | [PNG](base-visual/capturas/UI-HU38-C03.png) | 11306696afb2821166a1e0128df6fa5ad0b0669e24a499d35680c8ba40c5b23b |
| base | UI-HU39-C01 | [PNG](base-visual/capturas/UI-HU39-C01.png) | 3a438c125593072a2e54dc2f9879f622c00288a7a594a8782b804f3839d666e2 |
| base | UI-HU39-C02-after | [PNG](base-visual/capturas/UI-HU39-C02-after.png) | 4d684b49bc9a17249093d9ec85e53b696c41e890c9c660b21b36872152648145 |
| base | UI-HU39-C02-before | [PNG](base-visual/capturas/UI-HU39-C02-before.png) | 3a438c125593072a2e54dc2f9879f622c00288a7a594a8782b804f3839d666e2 |
| base | INT-HU36-C02 | [PNG](base-sdk/capturas/INT-HU36-C02.png) | 2569c34bf9cd571e5da44cb1094150217c792b4b684a357b8cb298203d9e6e3c |
| proposal | UI-HU36-C01 | [PNG](proposal-visual/capturas/UI-HU36-C01.png) | 1a37758038a2af06d37d18016c6f6e61ebcb6cf62cbb8d6e5467a3ab3bbd37fd |
| proposal | UI-HU38-C01 | [PNG](proposal-visual/capturas/UI-HU38-C01.png) | 9afcc43dda88824cacfef4dba4d9750a8c8bfc1e6e206e91f3f75043b653d371 |
| proposal | UI-HU38-C02 | [PNG](proposal-visual/capturas/UI-HU38-C02.png) | 7b67b6e191e589f825391a3b04d4a24cf3d143dc8e3e791b73d41d564e6d81a0 |
| proposal | UI-HU38-C03 | [PNG](proposal-visual/capturas/UI-HU38-C03.png) | 2fca0a0808ab542831b03d60992a8eb6cff0aa9ccb50ef2373553b1264906b78 |
| proposal | UI-HU39-C01 | [PNG](proposal-visual/capturas/UI-HU39-C01.png) | c2d1c92952d2ee59397f8a82130aa39c5399cf24acfc28130f630c4ada1ac36b |
| proposal | UI-HU39-C02-after | [PNG](proposal-visual/capturas/UI-HU39-C02-after.png) | e4343c555d4f3e04a2eb21a064927424521be3f64886901d8e987ac7b2f63203 |
| proposal | UI-HU39-C02-before | [PNG](proposal-visual/capturas/UI-HU39-C02-before.png) | c2d1c92952d2ee59397f8a82130aa39c5399cf24acfc28130f630c4ada1ac36b |
| proposal | INT-HU36-C02 | [PNG](proposal-sdk/capturas/INT-HU36-C02.png) | 8d1740c672fa6a33fe4d0940a1af3293047a7869adf1248421af4c43fedfc376 |

[Configuración al abrir MainActivity](configuracion/UI-CONFIG-01.png): la aplicación real indica que el servicio no está configurado. El archivo google-services.json no existe. La jerarquía uiautomator de ese diagnóstico está vacía y no se usa como oráculo del texto; se contrastaron la captura y ConfigurationScreen.

| Nivel | Implementación real | Dependencias controladas o ausentes |
|---|---|---|
| Visual 6 | Compose, ViewModels, casos de uso y mapper | Repositorios de perfil, juego, Home, progreso, temporada, sesión y drafts controlados. No red de Google/Firebase/OpenAI. |
| SDK 2 | Android Firestore SDK, FirebaseUserRepository, FirestoreDataSource, reglas productivas sin cambio y Firestore emulator demo-inkr8 | Inicio de perfil y estado de sesión son fixtures. No hay identidad Firebase autenticada: la lectura real es rechazada PERMISSION_DENIED. Functions está apuntado al loopback pero no se invoca. |
| Configuración | MainActivity/Inkr8App/ConfigurationScreen reales | Sin Firebase/OAuth configurado ni Google Play Services/cuentas en esa imagen. |
| Integración externa | No ejecutada | Configuración, proyecto/cuentas/dispositivo y autorización de facturación señalados en EXT-07/08. |

Resultados finales: base visual 3 PASS/3 FAIL y SDK 1 PASS/1 FAIL; propuesta visual 6 PASS y SDK 2 PASS. Los fallos de la base verifican los defectos, no errores de fixture. [Metadatos baseUI](base-visual/resultado-directo.json), [propuestaUI](proposal-visual/resultado-directo.json), [baseSDK](base-sdk/resultado-directo.json), [propuestaSDK](proposal-sdk/resultado-directo.json), [servidorSDK](sdk-emulator.log).
