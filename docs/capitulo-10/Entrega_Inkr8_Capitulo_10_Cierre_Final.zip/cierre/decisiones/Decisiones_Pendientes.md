# Decisiones pendientes: rating, recuperación y mensajes

El grupo revisa y entrega esta validación técnica con asistencia IA académica. La revisión humana y la reproducción de cada integrante siguen sin confirmar. Ninguna decisión de negocio nueva ni cambio de producto se aplica en estos archivos.

La [matriz JSON](Matriz_Conformidad.json) conserva requisito, comportamiento actual, impacto, recomendación y casos. Las fuentes son el informe vigente 6.3 para AC-02/AC-06, 5.3 y el [catálogo de HU y celdas ASR](../../fuentes/catalogo_hu.json). No se usa una constante aislada como prueba de un fallo funcional.

## DEC-ELO: resolver el contrato antes de cambiar el algoritmo

**Requisito:** AC-06/RNF-024 promete probabilidad esperada, fórmula oficial ELO, actualización simultánea y exactitud matemática. La referencia del informe a `evaluationPolicy.ts` no coincide con la ubicación actual del rating.

**Actual:** `gamePolicy.ts:ratingChange` calcula un ajuste lineal limitado por diferencia de rating; empate +1, derrota alrededor de −6 y victoria alrededor de +4, con topes a partir de 150/180. `Matchmaker` y `MatchBaseline` aplican además un piso de cero al rating persistido y guardan la variación efectiva. La función no calcula probabilidad esperada. Las unitarias anteriores y los nuevos datos son caracterización de esa regla.

**Impacto:** sustituir la política afecta ligas, resultados e historial y el rival simulado de 48 horas. El resultado de política para rating cero puede ser −6 mientras el delta persistido es cero; un test debe nombrar cuál observa. Los casos con diferencia 100 solo caracterizan la política aislada: no son rivales elegibles en el match real de delta ≤30.

**Decisión que falta:** aprobar la regla propia mediante cambio formal de AC-06, o aprobar la fórmula ELO concreta y sus parámetros, redondeo, empate, límites, tratamiento del baseline y resultados esperados independientes para ambos participantes. Faltan responsable, fecha y referencia aprobada.

**Recomendación:** decidir y registrar primero; entregar cualquier corrección de producto aparte y comprobar después política, persistencia de ambos usuarios, ligas, idempotencia e historial. Una fórmula elegida por el test no constituye aprobación del negocio.

Se prepararon doce entradas en [decision_rating_pendiente.json](decision_rating_pendiente.json). El [verificador](verificar_rating_decidido.cjs) compara valores literales, sin calcular el esperado llamando al producto. La [caracterización ejecutada](rating_caracterizacion.json) coincide en 12/12 y declara `conformidad_negocio_certificada: false`. Si falta aprobación o cualquier esperado, el modo de conformidad termina con código 2 y no ejecuta una falsa aprobación.

```powershell
node outputs/cierre/decisiones/verificar_rating_decidido.cjs --backend work/backend --caracterizar
# Después de una decisión real y registrada; no rellenar esperados copiando el resultado del producto:
node outputs/cierre/decisiones/verificar_rating_decidido.cjs --backend work/backend --decision ruta/decision_aprobada.json
```

En una copia entregada bajo `codigo/backend`, cambiar únicamente el argumento `--backend`. Compilar previamente con `npm --prefix <backend>/functions run build`.

## DEC-AC 02: cuota y disponibilidad no tienen recuperación automática

**Requisito:** AC-02 incluye timeout de 90 segundos **o** error de cuota/disponibilidad, conservación del envío, reintento automático por scheduler y aviso sin congelar la aplicación. La respuesta y medida del informe se redactan alrededor del timeout; hace falta ratificar el tratamiento de los tipos concretos de cuota.

**Actual:** `OpenAiWritingEvaluator` solo traduce `APIConnectionTimeoutError` a `EvaluationTimeout`. `EvaluateGame` difiere esa excepción, pero para 429/503 llama a `fail` y relanza. `fail` no agenda `nextRetryAt`, por lo que `recoverEvaluations` no recupera ese FAILED automáticamente. El reintento manual puede volver a PENDING sobre el mismo ID. Los tests que esperan ese fallo caracterizan el defecto y no acreditan AC-02.

**Impacto:** el texto puede conservarse correctamente y aun así quedar sin recuperación automática. El reintento del trigger no demuestra recuperación si una ejecución posterior lee FAILED y retorna. Tampoco un SDK simulado demuestra el timeout real de 90 segundos, la red ni disponibilidad de OpenAI.

**Decisión que falta:** distinción de `rate_limit`/`insufficient_quota`, tratamiento de 503, backoff y `Retry-After`, presupuesto de intentos, agotamiento y aviso. Mantener el envío y la economía idempotente es un invariante; los nuevos casos no eligen un intervalo nuevo.

**Recomendación:** corrección separada de producto para recuperación persistida y acotada, con clasificación acordada. No convertir todos los errores en timeout para hacer pasar una prueba.

Se preparó `functions/integration/cierre.ac02.test.cjs` con repositorios, caso de uso y Firestore reales; solo el evaluador externo es controlado. Tiene dos casos ACTUAL, dos MANUAL y dos CONFORMIDAD. Los cuatro primeros prueban conservación/estado y recuperación manual sin repetir cobro o recompensa. Los otros dos exigen recuperación automática con `CIERRE_EXIGIR_AC02=1`; se mantienen rojos si el producto no la ofrece. En la suite funcional se registran solo los cuatro casos ACTUAL/MANUAL; el comando separado test: conformance: ac 02 registra y ejecuta los seis, conservando los dos fallos.

```powershell
# Desde la raíz backend; ejecutar cuando 8080 esté libre:
npm --prefix functions run build
$env:CIERRE_EXIGIR_AC02 = "1"
firebase emulators:exec --project demo-inkr8 --only firestore "node --test --test-concurrency=1 --experimental-test-coverage functions/integration/cierre.ac02.test.cjs"
```

**B: los dos casos de conformidad fallan en base y propuesta; los cuatro ACTUAL/MANUAL pasan.** Las pruebas no prueban IA real ni autorizan por sí mismas cambios de producto.

## DEC-MENSAJES: contrato por operación y evidencia visible

| Flujo | Contrato vigente | Brecha o decisión concreta |
|---|---|---|
| HU 1.5/1.6 | Avisos canónicos de Home/ejemplo en Android | Backend puede conservar causas técnicas distintas; comprobar traducción, pantalla y reintento. Esta CN no renderiza UI. |
| HU 3.2 | `Unable to connect to the server` | El backend usa texto en español al fallar persistencia y el catch exterior vuelve a llamar `fail`. Verificar el error realmente persistido; el segundo `fail` no necesariamente lo sobrescribe. |
| HU 3.3 y 3.4 | `You don't have enough Merit to enter` y `The ranked match cannot be started. Insufficient Merit` | Una misma entrada Ranked hoy usa el segundo. El grupo debe resolver si hay contextos distintos o reconciliar ambos criterios; no acreditar los dos por una sola cadena. |
| HU 3.6 | `Server failure` al fallar lectura de rating | Tests nuevos del cliente inducen el fallo; base observada expone mensaje de progreso. Propuesta cliente aparte. |
| HU 3.8 | `The game result could not be updated` | Un error de observación tras EVALUATED exponía el mensaje de la excepción. La variante MATCHED sin match es otra ruta y no la sustituye. |
| HU 3.9 | `Server failure` si no puede obtenerse el delta | Conservar `null` ante dato inválido; no inventar cero. Un delta cero válido debe mostrarse como cero. UI_HU39_C01/C02 muestran el aviso y la recuperación en pantalla real con datos controlados. |
| HU 2.3/AC-02 | Aviso de evaluación demorada | Literales de timeout coinciden; falta temporizador real del SDK, pantalla y notificación. No extrapolarlo a 429/503. |

**Recomendación:** acordar un catálogo por operación/código e idioma y probar fallo inducido → estado → pantalla → recuperación. Donde el criterio ya fija un literal no hace falta inventar una nueva decisión para corregir la discrepancia; sí debe conservarse la conciliación de fuentes complementarias pendientes.

Los diez casos CLI_HU36_C01..C03, CLI_HU38_C01..C05 y CLI_HU39_C01..C02 se ejecutaron dentro del cierre JVM forzado. Base:96casos,93PASS/3FAIL; propuesta:96PASS. No son comparaciones de constantes. [Resultados actuales](../cliente/Reporte_Cliente.md).

Cierre actual: base 96 JVM(93 PASS/3 FAIL), propuesta 96 PASS; visual base 3 PASS/3 FAIL frente a propuesta 6 PASS; SDK local base 1 PASS/1 FAIL frente a propuesta 2 PASS. [Evidencia actual del cliente](../cliente/Reporte_Cliente.md). Para 429/503 ejecutar `npm --prefix functions run test:conformance:ac02` en una instancia nueva de emulador; el resultado actual es 6 casos, 4 PASS/2 FAIL, sin omitidos. Las decisiones externas se administran solo en [EXT-03/04/05](../../Pendientes_Externos.md).
