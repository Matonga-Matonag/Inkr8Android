const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
function value(name) { const index = args.indexOf(name); return index < 0 ? undefined : args[index + 1]; }
const backend = value('--backend');
if (!backend) { console.error('Use --backend <ruta_backend> y --caracterizar o --decision <JSON aprobado>.'); process.exit(2); }
const decisionPath = path.resolve(value('--decision') || path.join(__dirname, 'decision_rating_pendiente.json'));
const decision = JSON.parse(fs.readFileSync(decisionPath, 'utf8'));
const characterization = args.includes('--caracterizar');
const requiredIds = Array.from({length: 12}, (_, index) => `DEC-ELO-${String(index + 1).padStart(2, '0')}`);
if (!Array.isArray(decision.casos) || decision.casos.length !== requiredIds.length || new Set(decision.casos.map(row => row.id)).size !== requiredIds.length || requiredIds.some(id => !decision.casos.some(row => row.id === id)) || decision.casos.some(row => !Number.isFinite(row.mine) || !Number.isFinite(row.opponent) || !['WIN', 'LOSS', 'DRAW'].includes(row.outcome))) {
  console.error('INVALIDO: se requieren los doce IDs únicos, entradas numéricas y resultado WIN/LOSS/DRAW; no se admite un conjunto vacío o incompleto.');
  process.exit(2);
}
if (!characterization && (decision.aprobacion?.estado !== 'APROBADA' || !decision.aprobacion.responsable?.trim() || !Number.isFinite(Date.parse(decision.aprobacion.fecha)) || typeof decision.regla_aprobada !== 'string' || !decision.regla_aprobada.trim() || decision.casos.some(row => !Number.isFinite(row.esperado_aprobado)))) {
  console.error('PENDIENTE: faltan regla, responsable, fecha y esperados literales aprobados de todos los casos. No se ejecuta ni se declara conformidad ELO.');
  process.exit(2);
}
const {ratingChange} = require(path.resolve(backend, 'functions/lib/domain/policy/gamePolicy.js'));
const rows = decision.casos.map(row => {
  const obtained = ratingChange(row.mine, row.opponent, row.outcome);
  const expected = characterization ? row.caracterizacion_actual : row.esperado_aprobado;
  return {id: row.id, mine: row.mine, opponent: row.opponent, outcome: row.outcome, alcance: row.alcance, esperado: expected, obtenido: obtained, coincide: obtained === expected};
});
const report = {
  fecha_utc: new Date().toISOString(), tipo: characterization ? 'CARACTERIZACION; NO CONFORMIDAD ELO' : 'CONTRASTE CON DECISION APROBADA',
  metodo: 'ratingChange; no incluye clamp de persistencia ni atomicidad de match',
  decision: decisionPath, conformidad_negocio_certificada: false,
  coincide_con_casos_aprobados: !characterization && rows.every(row => row.coincide),
  limite: 'Un contraste de doce casos del método no certifica toda la regla ELO, persistencia ni actualización simultánea.',
  casos: rows, coincidencias: rows.filter(row => row.coincide).length, total: rows.length,
  responsabilidad: 'El grupo revisa y entrega con asistencia IA; este comando no acredita reproducción humana individual',
};
const output = value('--output');
if (output) { fs.mkdirSync(path.dirname(path.resolve(output)), {recursive: true}); fs.writeFileSync(path.resolve(output), JSON.stringify(report, null, 2) + '\n'); }
console.log(JSON.stringify(report, null, 2));
process.exitCode = rows.every(row => row.coincide) ? 0 : 1;
