# Defectos y observaciones de Inkr8

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

A=terminado/verificado; B=reproducido/documentado (histórico cuando se indica). Las decisiones externas tienen su inventario único en [Pendientes_Externos.md](Pendientes_Externos.md). Un test de caracterización aprobado no aprueba el requisito.

## TEST-01 — A

| Campo | Detalle |
|---|---|
| requirement | HU 3.3/3.4, contrato de error de capa |
| evidence | baseline-firestore.log, test 2; final-node20-firestore.log |
| reproduction | npm --prefix functions run test: integration con emulador local en base sin patch |
| expected | Código failed-precondition y mensaje inglés del contrato Ranked |
| observed | La expectativa /insuficiente/ falla ante Insufficient Merit |
| cause | Confirmada: regex en español obsoleta en integración |
| state | Corregido solo en test local, sin publicar |
| action | Revisar patch; conserva código y texto exactos, no debilita la aserción |

## TEST-02 — A

| Campo | Detalle |
|---|---|
| requirement | HU 2.1 y suite histórica de modo On-Topic |
| evidence | android-app-baseline-xml/TEST-com.inkr 8.presentation.AcceptanceCriteriaSuiteTest.xml; android-final-offline.log |
| reproduction | gradlew.bat : domain: test : app: testDebugUnitTest --offline --no-daemon --max-workers=2 en base |
| expected | Observar la misma partida devuelta por start, con cuatro palabras o modo ON_TOPIC |
| observed | FakeGameRepo.observe sustituye por Game STANDARD y palabras vacías; 2 tests fallidos de 70 |
| cause | Confirmada en fixture: observe emite objeto fijo |
| state | Corregido fixture local; 78/78 tests app posteriores |
| action | Revisar mapa de partidas del doble y resultado de ambas aserciones |

## CODE-01 — B

| Campo | Detalle |
|---|---|
| requirement | AC-02/RNF-014; HU 2.3 |
| evidence | cierre/matchmaking/evidencias/base-ac02-conformidad/run-01.log |
| reproduction | Evaluador controlado lanza status 429; ejecutar EvaluateGame, avanzar 5 min y recoverEvaluations |
| expected | Según AC-02, envío persistido para reintento ante cuota/disponibilidad |
| observed | Dos casos de conformidad fallan por ausencia de nextRetryAt; cuatro casos ACTUAL/MANUAL prueban persistencia e idempotencia. Los mismos dos fallos permanecen en propuesta de matchmaking. |
| cause | Confirmada: solo EvaluationTimeout usa defer; catch genérico usa fail |
| state | B: falta recuperación automática 429/503; EXT-04 define decisión necesaria |
| action | Acordar clasificación/backoff/presupuesto/aviso y preparar corrección de producto aparte; ejecutar casos existentes después. |

## LOAD-01 — B

| Campo | Detalle |
|---|---|
| requirement | AC-03/RNF-021, HU 3.5/3.7 |
| evidence | cierre/matchmaking/evidencias/base-50-final/run-01.log; cierre/matchmaking/Validacion_Final.md |
| reproduction | Perfil AC03-C01: 50 usuarios, rating 100, una partida evaluada única por usuario, cola compartida y 50 llamadas solapadas |
| expected | Cero dobles/inconsistentes y delta ≤30 para perfil 50. El test añade objetivo conservador de completar y resolver las 50 sin errores |
| observed | Base final 26/50 llamadas, 26 MATCHED, 13 parejas, pico 50, cero violaciones observadas en resueltas. Propuesta 3×50/50 y 51/51, sin mezclar resultados. |
| cause | Contención confirmada en el emulador: control mínimo sin Inkr8 shared-counter falló 11/50; independientes, parejas y shared-season aprobaron 50/50. Traza real concentra lecturas en m 10. El recorrido de candidatos amplifica contención; no se atribuye causa exclusiva al emulador ni se extrapola a cloud. |
| state | B: abierto en base; propuesta mínima verificada y separada |
| action | Recomendación favorable a incorporar tras aceptar desempate; ventana 100 preexistente y cloud no certificados. |

## DOC-CODE-01 — B

| Campo | Detalle |
|---|---|
| requirement | AC-06/RNF-024 y HU 3.7 |
| evidence | Informe 6.3 y gamePolicy.ts: 20; UT-VIC-01-C01..C09 |
| reproduction | Inspeccionar ratingChange y ejecutar casos de caracterización |
| expected | El informe promete fórmula ELO con probabilidad esperada |
| observed | Ajuste lineal, empate +1, topes propios; caracterización se reproduce |
| cause | Algoritmo confirmado por lectura/ejecución; intención de negocio no confirmada |
| state | Decisión de negocio pendiente, no corregida |
| action | Equipo/docente deben decidir regla y documento vigentes; no implementar ELO por iniciativa del agente |

## CODE-OBS-02 — A (revisión de observación)

| Campo | Detalle |
|---|---|
| requirement | Diagnóstico HU 3.2/2.3 ante fallo de persistencia |
| evidence | UT-PED-01-C09 y gameUseCases.ts catch anidados |
| reproduction | games.complete lanza DB offline en harness de EvaluateGame |
| expected | Una transición de error con causa preservada; propuesta técnica, no requisito explícito nuevo |
| observed | Se llama fail dos veces; la segunda recibe mensaje genérico |
| cause | Confirmada por doble: dos catch encadenados invocan fail |
| state | Observación por lectura y doble llamada al fake; no se demostró doble premio persistido ni se eleva a defecto funcional. |
| action | Se conserva como límite de evidencia; no condiciona la validación técnica completada. |

## DOC-01 — B

| Campo | Detalle |
|---|---|
| requirement | HU 1.1 |
| evidence | contraste_fuentes_primarias.json, ASR E2:E3; catalogo_hu.json |
| reproduction | Comparar D2 con E2:E3 en ASR |
| expected | Criterios de registro con Google |
| observed | Criterios de oración de ejemplo copiados de HU 1.6 |
| cause | Copia de contenido confirmada; autor/intención no inferidos |
| state | Reconciliación propuesta, no documento editado |
| action | Validar propuesta S2 + ACCEPTANCE_REPORT y actualizar requisitos por su responsable |

## DOC-02 — B

| Campo | Detalle |
|---|---|
| requirement | HU 3.3 versus HU 3.4 |
| evidence | Informe 5.3, ASR E 38: E 39; GameViewModel.start; baseline de aceptación hu 3_4_scenario 2 |
| reproduction | Contrastar You don’t have enough Merit to enter frente a The ranked match cannot be started. Insufficient Merit |
| expected | Contrato UX coherente aprobado |
| observed | Backend y ViewModel siguen mensaje de HU 3.4; HU 3.3 pide otro texto |
| cause | Diferencia documental/capas confirmada; decisión de UX pendiente |
| state | Observación; no se etiqueta fallo E2E de UI |
| action | Conciliar por capa/caso de uso con responsable de requisitos; no borrar uno de los criterios |

## TRANS-01 — B

| Campo | Detalle |
|---|---|
| requirement | HU 3.5 resolución a 48 h |
| evidence | evidencias/revision/entrega_anterior/final-node20-firestore.log; cierre/matchmaking/evidencias/base-functional-final/run-01.log |
| reproduction | R8 fallback waits exactly 48 hours… con match/recover concurrentes sobre mismo ID |
| expected | Resolver una sola vez con promedio del jugador |
| observed | No reaparece en el cierre funcional 100/100; se conserva antecedente de transacción inválida/cerrada y 25 diagnósticos anteriores. No se afirma eliminación universal ni corrección de producto. |
| cause | Origen observado: servidor/SDK transaccional. Causa exacta del error 3 no reproducida ni demostrada. Problema de fixture confirmado: Promise.all rechazaba sin esperar las otras operaciones y permitía limpieza prematura; se cambió a allSettled con exigencia de 0 errores. La carga se aisló en otra instancia. |
| state | B histórico conservado; ajuste de espera/aislamiento de pruebas A verificado; causa exacta abierta |
| action | Si reaparece, conservar las tres trazas y servidor/SDK; no reintentar ciegamente todo INVALID_ARGUMENT. |

## CLIENT-01 — B

| Campo | Detalle |
|---|---|
| requirement | HU 3.6 |
| evidence | cierre/cliente/Reporte_Cliente.md |
| reproduction | Comandos en README_Ejecucion.md y fuentes de casos |
| expected | Contrato de mensaje o búsqueda dentro del alcance declarado |
| observed | observeUser falla y la base muestra progreso en vez de Server failure; confirmado con I/O controlado y SDK local real. |
| cause | Confirmada por operación real y prueba; ver alcance de dependencias |
| state | Base conservada; propuesta separada verificada |
| action | Revisar parche cliente; mantiene mensaje de initializeUser y traduce solo observación. |

## CLIENT-02 — B

| Campo | Detalle |
|---|---|
| requirement | HU 3.8 |
| evidence | cierre/cliente/Reporte_Cliente.md |
| reproduction | Comandos en README_Ejecucion.md y fuentes de casos |
| expected | Contrato de mensaje o búsqueda dentro del alcance declarado |
| observed | Error de observador sobre Ranked enviada PENDING/EVALUATED deja mensaje crudo. La ruta de payload inválido es distinta. |
| cause | Confirmada por operación real y prueba; ver alcance de dependencias |
| state | Base conservada; propuesta separada verificada |
| action | Revisar parche cliente; preserva DRAFT/cancelaciones/submit. |

## MM-WINDOW-01 — B

| Campo | Detalle |
|---|---|
| requirement | HU 3.5 |
| evidence | cierre/matchmaking/Validacion_Final.md |
| reproduction | Comandos en README_Ejecucion.md y fuentes de casos |
| expected | Contrato de mensaje o búsqueda dentro del alcance declarado |
| observed | Rivales elegibles fuera de limit(100) pueden no ser consultados si cien anteriores son incompatibles. Mismo resultado en base y propuesta, casos 18/20. |
| cause | Confirmada por operación real y prueba; ver alcance de dependencias |
| state | Preexistente en ambas copias |
| action | Limitación heredada documentada; no ampliar consulta dentro de este parche ni prometer ausencia de inanición. |
