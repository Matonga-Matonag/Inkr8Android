# Capítulo 10 — pruebas de software de Inkr8

Revisión del 6 de noviembre de 2026 (Lima). El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados. Se continúa desde el ZIP de revisión técnica cuyo hash se conserva en cierre/Entrada_Revision.json. Las cuatro ramas permanecen pruebas/capitulo-10.

## 10.1 Estrategia y ejecución

Alcance: unión de 19 HU prioritarias y HU 2.2 adicional justificada. Se preservan identidades de 5.1 y referencias de 5.3/5.6 al capítulo 9. ASR E2:E3 de Google se conserva como fuente inválida y la reconciliación propuesta no se presenta aprobada. Se distinguen HU trazada, cláusula local observada y criterio integral.

Entorno: Node 20.19.0/npm 10.8.2, JDK 21.0.9, Firestore 1.22.0 fijado por SHA, demo-inkr8/loopback, Gradle 9.1.0/SDK 36 y AVD nuevo con WHPX. Los 50/51 se ejecutaron en instancias nuevas sin AVD ni builds paralelos. --test-concurrency=1 ordena archivos funcionales; no reduce las 50 operaciones del perfil. JVM se reejecutó con --rerun y cobertura posterior conserva el código de salida fallido.

| Suite base | Aprobados | Fallidos | Evidencia |
|---|---|---|---|
| Backend unidad/adaptador | 116 | 0 | [TAP](evidencias/cierre/backend/base-unit-final.log) |
| Firestore funcional | 100 | 0 | [TAP](cierre/matchmaking/evidencias/base-functional-final/run-01.log) |
| AC-02, conformidad adicional | 0 | 2 | [TAP](cierre/matchmaking/evidencias/base-ac02-conformidad/run-01.log) |
| Carga original 50 | 0 | 1 | [TAP](cierre/matchmaking/evidencias/base-50-final/run-01.log) |
| Android JVM (85 app+11 domain) | 93 | 3 | [log](cierre/cliente/base-all-coverage.log) |
| UI Compose instrumentada | 3 | 3 | [instrumentación](cierre/ui/base-visual/instrumentation.log) |
| SDK Android–Firestore local | 1 | 1 | [instrumentación](cierre/ui/base-sdk/instrumentation.log) |

323 casos únicos de base: 313 PASS y 10 FAIL, sin sumar repeticiones ni propuestas; no es porcentaje de trabajo terminado ni aceptación. Los negativos de 3.6/3.8/3.9 sustituyen constantes por fallo/dato inducido→código real→estado/mensaje/efectos. Las capturas son auténticas; UI usa repositorios controlados. SDK Android se conecta realmente a Firestore emulado con reglas productivas y error PERMISSION_DENIED; inicio/sesión siguen controlados. [Capturas y límites](cierre/ui/Indice_Capturas.md).

## 10.2 Caja blanca

Seis CFG coherentes con V(G)≥5: 11/6/5/6/7/7. Se contrasta E−N+2, decisiones y rango GF(2); 42 caminos tienen casos testigo aprobados. Predicados de biblioteca atómicos, callbacks desconectados fuera del alcance y salidas comunes documentados. No se confunden líneas/ramas con todos los caminos combinatorios ni se afirma trazado dinámico de nodos. [Grafos](caja_blanca/grafos_y_caminos.json).

## 10.3 Caja negra

Seis fronteras con 6/10/7/6/5/7 campos reales declarados. Se excluyen season sobrescrito, saldo leído como supuesto argumento y elementos de un array contados como campos distintos. Renzo ahora prueba GetDailyHome→dailyWord→Firestore con 25 casos observables, metadatos completos/variados/vacíos/espacios/ausentes, caché y efectos prohibidos. El helper privado queda auxiliar. Los cinco campos entran desde catálogo persistido; getHome recibe cero y dailyWord solo day: pregunta docente exacta y opciones comprobadas en la ficha, sin fingir cinco controles públicos. [Rúbrica](revision/Auditoria_Rubrica.md).

## 10.4 Unitarias, cobertura y criterios

Los seis métodos principales tienen 24/10/9/12/5/7 casos: 67 distinguibles, al menos 4 por método. Se mide cobertura nativa Node y JaCoCo por archivo/módulo, conservando generado y partes sin pruebas. No se inventa porcentaje por método/HU ni se usa total del runner con tests como cobertura de producto. [Cobertura](evidencias/Cobertura.md).

Las 19 HU prioritarias tienen traza; 38 criterios prioritarios y 2 adicionales se desglosan por fuente, resultado y límite.3.9 tiene su cláusula negativa local demostrada; 3.6/3.8 reproducen defectos de base y su corrección se verifica aparte. Ninguna HU se declara integralmente E2E con Google/OpenAI real ni se acredita ELO por caracterización. [Matriz](Matriz_Pruebas_y_Trazabilidad.md), [criterios](revision/Criterios_Demostrados.md).

## 10.5 Defectos, propuestas y clasificación del cierre

| Estado | Resultado |
|---|---|
| A: terminado y verificado | Pruebas/fixtures implementados y ejecutados; guardas, 20 casos de matchmaking, 25 Home, 96 JVM, 6 UI y 2 SDK; seis paquetes/CFG/cobertura y expediente actualizado. |
| B: reproducido y documentado | Base 50: 26/50 llamadas, 26 MATCHED/13 parejas, pico 50; CLIENT-01/02 mensajes; CODE-01 recuperación 429/503; discrepancia ELO; limitación 100 heredada. TRANS-01 histórico conserva causa exacta abierta aunque recuperación 48 h aprueba en cierre. |
| C: acceso o decisión externa | Solo la lista canónica EXT-01..09: docente, aportes individuales, decisiones, servicios reales e incorporación de propuestas. |

| Propuesta aislada | Resultado | Evidencia |
|---|---|---|
| Backend: unidad/adaptador | 116/116 | [log](evidencias/cierre/backend/propuesta-unit-final.log) |
| Backend: funcional ampliada | 100/100, incluidos 20 de guardas/ventana | [log](cierre/matchmaking/evidencias/propuesta-functional-final/run-01.log) |
| Backend: desempate propuesto | 1/1 | [log](cierre/matchmaking/evidencias/propuesta-politica-final/run-01.log) |
| Backend: original 50, tres instancias nuevas | 3×50/50, 25 parejas, pico 50, cero violaciones | [secuencia](cierre/matchmaking/Secuencia_Cargas_Final.json) |
| Backend: grupo impar 51 | 51/51 llamadas; 50 MATCHED, 25 parejas, 1 pendiente, pico 51 | [JSON](cierre/matchmaking/evidencias/propuesta-51-final/run-01/MM-LOAD-51.json) |
| Cliente: JVM | 96/96 | [log](cierre/cliente/proposal-all-coverage.log) |
| Cliente: UI local | 6/6 | [instrumentación](cierre/ui/proposal-visual/instrumentation.log) |
| Cliente: SDK local y pantalla | 2/2 | [instrumentación](cierre/ui/proposal-sdk/instrumentation.log) |

La recomendación concreta es incorporar el cambio mínimo de desempate tras aceptar la política y revisar el diff; 20 guardas y grupos impares/ventanas pasan en ambas copias, y propuesta 3×50/51 pasa sin debilitar aserciones. limit(100) permanece: si los cien candidatos son incompatibles, rival fuera de ventana no se consulta; esa limitación ya existe en la base. No se promete capacidad cloud ni ausencia de inanición.

La corrección cliente modifica solo SessionViewModel y GameViewModel: separa inicialización/observación y traduce error de resultado para Ranked PENDING/EVALUATED, preservando DRAFT, cancelación y envío.96 JVM+6 UI+2 SDK pasan en esa copia.429/503 siguen sin recuperación automática y ELO no se cambia. Las propuestas no se aplican a la base. [Defectos](Defectos.md), [propuestas](propuesta_producto/README.md), [pendientes únicos](Pendientes_Externos.md), [reproducción](README_Ejecucion.md).
