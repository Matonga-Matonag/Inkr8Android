# Inkr8 — cierre de pruebas y capítulo 10

El grupo es responsable de la revisión y entrega, elaboradas con asistencia de IA declarada. No se atribuyen revisiones, aportes ni reproducciones individuales que no estén registrados.

Se completó la validación ejecutable de las 19 HU prioritarias y HU 2.2 justificada. Las ramas base y copias propuestas mantienen `pruebas/capitulo-10`. No se publicó, desplegó ni editó el informe compartido. La base conserva los defectos; las correcciones de producto se entregan aparte.

| Suite base | Aprobados | Fallidos | Evidencia |
|---|---|---|---|
| Backend unidad/adaptador | 116 | 0 | [TAP](evidencias/cierre/backend/base-unit-final.log) |
| Firestore funcional | 100 | 0 | [TAP](cierre/matchmaking/evidencias/base-functional-final/run-01.log) |
| AC-02, conformidad adicional | 0 | 2 | [TAP](cierre/matchmaking/evidencias/base-ac02-conformidad/run-01.log) |
| Carga original 50 | 0 | 1 | [TAP](cierre/matchmaking/evidencias/base-50-final/run-01.log) |
| Android JVM (85 app+11 domain) | 93 | 3 | [log](cierre/cliente/base-all-coverage.log) |
| UI Compose instrumentada | 3 | 3 | [instrumentación](cierre/ui/base-visual/instrumentation.log) |
| SDK Android–Firestore local | 1 | 1 | [instrumentación](cierre/ui/base-sdk/instrumentation.log) |

El catálogo contiene 323 casos únicos de base: 313 aprobados y 10 fallidos. Los cuatro casos AC-02 ACTUAL/MANUAL se cuentan una sola vez aunque se ejecutaron también en conformidad. Repeticiones y propuestas no se suman. Estos conteos no representan porcentaje de trabajo terminado ni aceptación de HU.

| Propuesta aislada | Resultado | Evidencia |
|---|---|---|
| Backend: unidad/adaptador | 116/116 | [log](evidencias/cierre/backend/propuesta-unit-final.log) |
| Backend: funcional ampliada | 100/100, incluidos 20 de guardas/ventana | [log](cierre/matchmaking/evidencias/propuesta-functional-final/run-01.log) |
| Backend: desempate propuesto | 1/1 | [log](cierre/matchmaking/evidencias/propuesta-politica-final/run-01.log) |
| Backend: original 50, tres instancias nuevas | 3×50/50, 25 parejas, pico 50, cero violaciones | [secuencia](cierre/matchmaking/Secuencia_Cargas_Final.json) |
| Backend: grupo impar 51 | 51/51 llamadas; 50 MATCHED, 25 parejas, 1 pendiente, pico 51 | [JSON](cierre/matchmaking/evidencias/propuesta-51-final/run-01/MM-LOAD-51.json) |
| Cliente: JVM | 96/96 | [log](cierre/cliente/proposal-all-coverage.log) |
| Cliente: UI local | 6/6 | [instrumentación](cierre/ui/proposal-visual/instrumentation.log) |
| Cliente: SDK local y pantalla | 2/2 | [instrumentación](cierre/ui/proposal-sdk/instrumentation.log) |

Los dos casos de conformidad 429/503 también fallan en la propuesta de matchmaking; esa propuesta no cambia la recuperación de IA.

| Clasificación | Cierre |
|---|---|
| A · Terminado y verificado | Negativos reales de cliente; propuestas aisladas verificadas; guardas, impares y ventana; Home observable 25/25; seis CFG, 42 caminos, 67 unitarias principales y cobertura; capturas auténticas; SDK local; documentación y parches comprobados. |
| B · Defecto reproducido y documentado | Carga base: 26/50 llamadas completas, 26 MATCHED/13 parejas. Dos defectos de mensajes reproducidos en 3 JVM, 3 UI y 1 SDK. Recuperación 429/503 sin programación automática. Límite 100 heredado. Discrepancia ELO y fallo histórico 48 h conservados con su alcance. |
| C · Acceso/decisión externa | Inventario único en Pendientes_Externos.md: docente, participación, ELO, reintentos, mensajes, fuente Google, integración externa, IA facturable e incorporación de parches. |

Documentos: [capítulo 10](Capitulo_10_Borrador.md), [matriz](Matriz_Pruebas_y_Trazabilidad.md), [seis fichas](paquetes/Seis_fichas.json), [criterios desglosados](revision/Criterios_Demostrados.md), [capturas y dependencias](cierre/ui/Indice_Capturas.md), [rúbrica](revision/Auditoria_Rubrica.md), [reproducción](README_Ejecucion.md), [pendientes externos](Pendientes_Externos.md), [defectos](Defectos.md).
