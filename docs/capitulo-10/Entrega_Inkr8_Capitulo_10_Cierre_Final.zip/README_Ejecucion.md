# Reproducción del cierre técnico de Inkr8

Backend base: `993c6b0641a4a60603d87e251c90f51783460007`. Cliente base: `d6e8a432b5ad678cbe5db72d7ed1cbd7987f542c`. Mantener rama `pruebas/capitulo-10`. No se necesitan credenciales reales para las pruebas locales documentadas.

Hay dos formas de preparar código: usar los árboles `codigo/backend` y `codigo/frontend`, que ya contienen pruebas, o extraer los ZIP `*_base.zip` y aplicar el patch correspondiente. No aplicar dos veces el parche. En otra copia, aplicar después el parche mínimo de producto que se quiera revisar.

```powershell
git apply --check C:/entrega/codigo/backend.patch
git apply C:/entrega/codigo/backend.patch
# En la copia del cliente: codigo/frontend.patch
```

Preparar Node 20.19.0/npm 10.8.2, JDK 21.0.9 y FirebaseCLI 14.22.0. Ajustar rutas locales:

```powershell
$env:JAVA_HOME = 'C:/herramientas/jdk-21.0.9+10'
$env:PATH = 'C:/herramientas/node-v20.19.0-win-x64;' + $env:JAVA_HOME + '/bin;' + $env:PATH
$env:FIRESTORE_EMULATOR_BINARY_PATH = 'C:/herramientas/cloud-firestore-emulator-v1.22.0.jar'
$env:CAP10_EVIDENCE_DIR = 'C:/evidencias-nuevas'
node --version
java -version
```

JAR 1.22.0: [descarga oficial](https://storage.googleapis.com/firebase-preview-drop/emulator/cloud-firestore-emulator-v1.22.0.jar), SHA256 `9b6498b7f62714d67f48f59b3818883cd682dbcd46b9f59511de81c97bb5166c`. El override se conserva en metadatos. Usar exclusivamente proyecto `demo-inkr8` y loopback; no apuntar a producción.

## Backend base y propuesta

Desde la raíz backend:

```powershell
npm --prefix functions ci
npm --prefix functions run test:coverage
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:integration:coverage"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:conformance:ac02"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:coverage"
```

Resultados base esperados: 116/116 unidad, 100/100 funcional; conformidad AC-02: 6 casos, 4 PASS/2 FAIL; carga 50: 1 FAIL. Los cuatro ACTUAL/MANUAL ya están en la funcional y no se cuentan de nuevo. Cada comando usa una instancia nueva. No omitir la carga ni sustituirla por llamadas secuenciales. `Run-Firestore.ps1` coordina funcional y 50 y devuelve 1 si alguna falla.

En la copia separada:

```powershell
git apply --check C:/entrega/propuesta_producto/backend/contencion_empates.patch
git apply C:/entrega/propuesta_producto/backend/contencion_empates.patch
# Reejecutar unidad, funcional y carga originales de arriba.
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:matching:policy"
firebase emulators:exec --project demo-inkr8 --only firestore "npm --prefix functions run test:concurrency:odd"
```

Para repetir el perfil 50 ejecutar su comando tres veces, cada vez con una instancia nueva y carpeta de evidencia distinta. Mantener 50 operaciones, completadas 50, MATCHED 50, 25 parejas, pico 50 y cero violaciones. En 51: 51 completadas, 50 MATCHED, 25 parejas, 1 pendiente, pico 51. No ejecutar builds/AVD en paralelo a esas cargas. AC-02 conserva sus dos fallos incluso con el parche de matchmaking.

## Cliente JVM, UI y SDK local

JDK 21, Gradlewrapper 9.1.0, SDK 36/BuildTools 36.0.0. Configurar ANDROID_HOME/ANDROID_SDK_ROOT. Desde la raíz del cliente:

```powershell
.\gradlew.bat :app:testDebugUnitTest --rerun :domain:test --rerun --continue --no-daemon --max-workers=2
# Conservar exit1 de la base antes de generar informes, sin reejecutar los tests:
.\gradlew.bat :app:jacocoDebugUnitTestReport :domain:jacocoTestReport -x :app:testDebugUnitTest -x :domain:test --no-daemon --max-workers=2
.\gradlew.bat :app:assembleDebug :app:assembleDebugAndroidTest --no-daemon --max-workers=2
```

Base JVM: 96 casos, 93 PASS/3 FAIL. En otra copia aplicar `propuesta_producto/cliente/mensajes_cliente.patch` después del parche de pruebas; repetir: 96/96. Las dependencias Gradle están fijadas por el proyecto; si no hay caché se necesita acceso a sus repositorios de descarga.

Instrumentadas: AVD nuevo API 36 default x 86_64, WHPX, 720×1280, serial usado emulator-5556. Herramientas oficiales: platform-tools 37.0.1, emulator 37.2.13 y system-image android-36/default/x 86_64 r02. No usar un AVD con datos personales. Instalar los APK de debug y androidTest construidos:

```powershell
adb -s emulator-5556 install -r -t app/build/outputs/apk/debug/app-debug.apk
adb -s emulator-5556 install -r -t app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
adb -s emulator-5556 shell am instrument -w -r -e class com.inkr8.presentation.Capitulo10VisualTest com.inkr8.test/androidx.test.runner.AndroidJUnitRunner
```

Base UI: 6 casos, 3 PASS/3 FAIL; propuesta 6/6. Interpretar los códigos/status JUnit, no solo el exitcode de adb: AndroidJUnitRunner puede imprimir FAILURES con adb exit 0. Las capturas se guardan en files/capitulo 10-evidencias del target; copiar byte por byte antes de desinstalar. `ls -1` evita interpretar una salida multicolumna como un nombre. Los repositorios visuales son controlados y la pantalla/VM/mapper son reales.

Para los dos casos SDK iniciar una instancia local de Firestore con reglas productivas sin cambio, proyecto demo-inkr8, host 127.0.0.1, puerto 8080. Conectar desde el AVD por 10.0.2.2:8080; no requiere Firebase cloud ni Google real:

```powershell
adb -s emulator-5556 shell am instrument -w -r -e class com.inkr8.presentation.Capitulo10LocalFirestoreTest -e localFirestore true com.inkr8.test/androidx.test.runner.AndroidJUnitRunner
```

Base: 1 PASS/1 FAIL; propuesta 2/2. El servidor debe devolver PERMISSION_DENIED por lectura sin identidad Firebase, no un error de red. Inicio/sesión del perfil son fixtures; observeUser atraviesa SDK/repositorio/reglas reales. Functions no se invoca. Estos tests no prueban login Google ni funciones desplegadas.

## Herramientas y decisiones preparadas

Se incluyen bajo herramientas/cierre los runners y generadores usados. Para reproducir su layout sin modificar rutas: crear una carpeta con outputs/ y work/; colocar repos en work/backend, work/frontend y copias propuestas en work/propuesta_backend, work/propuesta_frontend; copiar herramientas/cierre a work/cierre y runtimes a work/tools. Los comandos directos anteriores no necesitan ese layout auxiliar. Metadatos registran órdenes exactas, hashes de fuente/JAR/APK, fechas UTC y resultados.

ELO: `node outputs/cierre/decisiones/verificar_rating_decidido.cjs --backend work/backend --decision ruta/decision_aprobada.json` requiere decisión y esperados literales aprobados; sin ellos termina 2 y no simula conformidad. Para caracterizar se usa --caracterizar, que nunca aprueba ELO.

No hay permiso para llamadas facturables OpenAI. Configuración/cuentas Google/Firebase y decisiones pendientes: [inventario único](Pendientes_Externos.md). [Capturas y dependencias](cierre/ui/Indice_Capturas.md), [código/parches](codigo/Bases_y_parches.json), [propuestas](propuesta_producto/Propuestas.json).
