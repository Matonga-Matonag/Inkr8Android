# CB-REN-01 Renzo — dailyWord

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/data/repository/firebaseContentRepository.ts:12`.

Flujo conectado exterior de dailyWord; el callback transaccional empieza en su propia entrada y se excluye del conteo. Tampoco se suman words.find, words() ni hasMetadata. Sus efectos se ejercitan en Firestore, pero no elevan V(G) de este grafo.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=14, E=19, componentes=1; V(G)=E−N+2=7.** El contraste `1+Σ(grado_salida−1)` da 7. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
012    async dailyWord(day: number): Promise<Word> {
013      const ref = this.db.doc(`dailyWords/${day}`), saved = await ref.get(); // N01
014      if (saved.exists && this.hasMetadata(saved.data() as Word)) return saved.data() as Word; // N02, N03, N04
015      const words = await this.words();
016      if (!words.length) throw new DomainError("failed-precondition", "No hay palabras activas disponibles."); // N05, N06
017      const word = saved.exists ? words.find((item) => item.text === saved.get("text")) : words[((day % words.length) + words.length) % words.length]; // N07, N08, N09
018      if (!word || !this.hasMetadata(word)) throw new DomainError("failed-precondition", "La palabra del momento no tiene su información completa."); // N10, N11, N12
019      return this.db.runTransaction(async (tx) => { // N13
020        const current = await tx.get(ref);
021        if (current.exists && this.hasMetadata(current.data() as Word)) return current.data() as Word;
022        tx.set(ref, word); return word;
023      });
024    }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | leer saved dailyWords/day |
| N02 | saved.exists? |
| N03 | hasMetadata(saved)? |
| N04 | return saved |
| N05 | !words.length? |
| N06 | throw No hay palabras activas |
| N07 | saved.exists? (selección) |
| N08 | words.find(text == saved.text) |
| N09 | selección módulo del día |
| N10 | !word? |
| N11 | !hasMetadata(word)? |
| N12 | throw información incompleta |
| N13 | return db.runTransaction(callback) |
| N14 | Salida común |

```mermaid
flowchart TD
  N01["leer saved dailyWords/day"]
  N02["saved.exists?"]
  N03["hasMetadata(saved)?"]
  N04["return saved"]
  N05["!words.length?"]
  N06["throw No hay palabras activas"]
  N07["saved.exists? (selección)"]
  N08["words.find(text == saved.text)"]
  N09["selección módulo del día"]
  N10["!word?"]
  N11["!hasMetadata(word)?"]
  N12["throw información incompleta"]
  N13["return db.runTransaction(callback)"]
  N14["Salida común"]
  N01 --> N02
  N02 -->|T| N03
  N02 -->|F| N05
  N03 -->|T| N04
  N03 -->|F| N05
  N04 --> N14
  N05 -->|T| N06
  N05 -->|F| N07
  N06 --> N14
  N07 -->|T| N08
  N07 -->|F| N09
  N08 --> N10
  N09 --> N10
  N10 -->|T| N12
  N10 -->|F| N11
  N11 -->|T| N12
  N11 -->|F| N13
  N12 --> N14
  N13 --> N14
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N02 → N03 → N04 → N14 | CB-REN-01-C01 | 1 |
| P2 | N01 → N02 → N05 → N06 → N14 | CB-REN-01-C02 | 2 |
| P3 | N01 → N02 → N03 → N05 → N06 → N14 | CB-REN-01-C03 | 3 |
| P4 | N01 → N02 → N05 → N07 → N09 → N10 → N11 → N13 → N14 | CB-REN-01-C04 | 4 |
| P5 | N01 → N02 → N03 → N05 → N07 → N08 → N10 → N11 → N13 → N14 | CB-REN-01-C05 | 5 |
| P6 | N01 → N02 → N03 → N05 → N07 → N08 → N10 → N12 → N14 | CB-REN-01-C06 | 6 |
| P7 | N01 → N02 → N05 → N07 → N09 → N10 → N11 → N12 → N14 | CB-REN-01-C07 | 7 |

Los 7 vectores de incidencia de aristas tienen rango 7 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [funcional final](../cierre/matchmaking/evidencias/base-functional-final/run-01.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
