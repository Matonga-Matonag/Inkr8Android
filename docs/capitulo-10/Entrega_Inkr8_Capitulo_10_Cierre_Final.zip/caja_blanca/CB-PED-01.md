# CB-PED-01 Pedro — validateWriting

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/domain/policy/gamePolicy.ts:9`.

Función TypeScript validateWriting. Se incluye el ternario del mensaje de error: es código distinto del ternario del máximo. wordCount se considera llamada atómica. HU 2.2 adicional justificada por validación y envío; no se atribuye esta complejidad a Kotlin.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=13, E=17, componentes=1; V(G)=E−N+2=6.** El contraste `1+Σ(grado_salida−1)` da 6. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
009  export function validateWriting(text: string, mode: WritingMode): void {
010    const count = wordCount(text); // N01
011    if (text.length > 10000 || count < 50 || count > (mode === "STANDARD" ? 150 : 200)) { // N02, N03, N04, N05, N06, N07
012      throw new DomainError("invalid-argument", `Escribe entre 50 y ${mode === "STANDARD" ? 150 : 200} palabras.`); // N09, N10, N11, N12
013    } // N08
014  }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | wordCount(text) |
| N02 | text.length > 10000? |
| N03 | count < 50? |
| N04 | mode === STANDARD? (máximo) |
| N05 | max = 150 |
| N06 | max = 200 |
| N07 | count > max? |
| N08 | return void |
| N09 | mode === STANDARD? (mensaje) |
| N10 | mensaje 50..150 |
| N11 | mensaje 50..200 |
| N12 | throw invalid-argument |
| N13 | Salida común |

```mermaid
flowchart TD
  N01["wordCount(text)"]
  N02["text.length > 10000?"]
  N03["count &lt; 50?"]
  N04["mode === STANDARD? (máximo)"]
  N05["max = 150"]
  N06["max = 200"]
  N07["count > max?"]
  N08["return void"]
  N09["mode === STANDARD? (mensaje)"]
  N10["mensaje 50..150"]
  N11["mensaje 50..200"]
  N12["throw invalid-argument"]
  N13["Salida común"]
  N01 --> N02
  N02 -->|T| N09
  N02 -->|F| N03
  N03 -->|T| N09
  N03 -->|F| N04
  N04 -->|T| N05
  N04 -->|F| N06
  N05 --> N07
  N06 --> N07
  N07 -->|T| N09
  N07 -->|F| N08
  N09 -->|T| N10
  N09 -->|F| N11
  N10 --> N12
  N11 --> N12
  N12 --> N13
  N08 --> N13
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N02 → N03 → N04 → N05 → N07 → N08 → N13 | CB-PED-01-C01 | 1 |
| P2 | N01 → N02 → N03 → N04 → N06 → N07 → N08 → N13 | CB-PED-01-C02 | 2 |
| P3 | N01 → N02 → N09 → N10 → N12 → N13 | CB-PED-01-C03 | 3 |
| P4 | N01 → N02 → N09 → N11 → N12 → N13 | CB-PED-01-C04 | 4 |
| P5 | N01 → N02 → N03 → N09 → N10 → N12 → N13 | CB-PED-01-C05 | 5 |
| P6 | N01 → N02 → N03 → N04 → N05 → N07 → N09 → N10 → N12 → N13 | CB-PED-01-C06 | 6 |

Los 6 vectores de incidencia de aristas tienen rango 6 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [unidad final](../evidencias/cierre/backend/base-unit-final.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
