# CB-MAT-01 Matías — mapUser

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/data/dto/userDto.ts:3`.

Flujo de la función indicada; llamadas auxiliares atómicas; excepciones implícitas de bibliotecas fuera del CFG.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=20, E=25, componentes=1; V(G)=E−N+2=7.** El contraste `1+Σ(grado_salida−1)` da 7. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
003  export function mapUser(id: string, dto: UserDto): User { // N01
004    return {id, name: dto.name || "Writer", email: dto.email ?? null, merit: dto.merit ?? 0, // N03, N04, N05, N06, N07, N08, N09, N10, N11
005      rating: dto.rating ?? 0, seasonIndex: dto.seasonIndex ?? Number.MIN_SAFE_INTEGER, username: dto.username ?? null}; // N12, N13, N14, N15, N16, N17, N18, N19, N20
006  }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | Entrada id,dto |
| N02 | Salida User |
| N03 | name: valor definido y truthy? |
| N04 | usar dto.name |
| N05 | default name |
| N06 | email: valor definido? (??) |
| N07 | usar dto.email |
| N08 | default email |
| N09 | merit: valor definido? (??) |
| N10 | usar dto.merit |
| N11 | default merit |
| N12 | rating: valor definido? (??) |
| N13 | usar dto.rating |
| N14 | default rating |
| N15 | seasonIndex: valor definido? (??) |
| N16 | usar dto.seasonIndex |
| N17 | default seasonIndex |
| N18 | username: valor definido? (??) |
| N19 | usar dto.username |
| N20 | default username |

```mermaid
flowchart TD
  N01["Entrada id,dto"]
  N02["Salida User"]
  N03["name: valor definido y truthy?"]
  N04["usar dto.name"]
  N05["default name"]
  N06["email: valor definido? (??)"]
  N07["usar dto.email"]
  N08["default email"]
  N09["merit: valor definido? (??)"]
  N10["usar dto.merit"]
  N11["default merit"]
  N12["rating: valor definido? (??)"]
  N13["usar dto.rating"]
  N14["default rating"]
  N15["seasonIndex: valor definido? (??)"]
  N16["usar dto.seasonIndex"]
  N17["default seasonIndex"]
  N18["username: valor definido? (??)"]
  N19["usar dto.username"]
  N20["default username"]
  N01 --> N03
  N03 -->|T| N04
  N03 -->|F| N05
  N04 --> N06
  N05 --> N06
  N06 -->|T| N07
  N06 -->|F| N08
  N07 --> N09
  N08 --> N09
  N09 -->|T| N10
  N09 -->|F| N11
  N10 --> N12
  N11 --> N12
  N12 -->|T| N13
  N12 -->|F| N14
  N13 --> N15
  N14 --> N15
  N15 -->|T| N16
  N15 -->|F| N17
  N16 --> N18
  N17 --> N18
  N18 -->|T| N19
  N18 -->|F| N20
  N19 --> N02
  N20 --> N02
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N03 → N04 → N06 → N07 → N09 → N10 → N12 → N13 → N15 → N16 → N18 → N19 → N02 | UT-MAT-01-C01 | 1 |
| P2 | N01 → N03 → N05 → N06 → N07 → N09 → N10 → N12 → N13 → N15 → N16 → N18 → N19 → N02 | UT-MAT-01-C02 | 2 |
| P3 | N01 → N03 → N04 → N06 → N08 → N09 → N10 → N12 → N13 → N15 → N16 → N18 → N19 → N02 | UT-MAT-01-C03 | 3 |
| P4 | N01 → N03 → N04 → N06 → N07 → N09 → N11 → N12 → N13 → N15 → N16 → N18 → N19 → N02 | UT-MAT-01-C04 | 4 |
| P5 | N01 → N03 → N04 → N06 → N07 → N09 → N10 → N12 → N14 → N15 → N16 → N18 → N19 → N02 | UT-MAT-01-C05 | 5 |
| P6 | N01 → N03 → N04 → N06 → N07 → N09 → N10 → N12 → N13 → N15 → N17 → N18 → N19 → N02 | UT-MAT-01-C06 | 6 |
| P7 | N01 → N03 → N04 → N06 → N07 → N09 → N10 → N12 → N13 → N15 → N16 → N18 → N20 → N02 | UT-MAT-01-C07 | 7 |

Los 7 vectores de incidencia de aristas tienen rango 7 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [unidad final](../evidencias/cierre/backend/base-unit-final.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
