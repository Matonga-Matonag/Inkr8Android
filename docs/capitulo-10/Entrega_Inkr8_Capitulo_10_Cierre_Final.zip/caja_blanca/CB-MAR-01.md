# CB-MAR-01 Marco — meritReward

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/domain/policy/gamePolicy.ts:15`.

Flujo de la función indicada; llamadas auxiliares atómicas; excepciones implícitas de bibliotecas fuera del CFG.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=23, E=32, componentes=1; V(G)=E−N+2=11.** El contraste `1+Σ(grado_salida−1)` da 11. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
015  export function meritReward(score: number, count: number, ranked: boolean): number { // N01
016    if (!Number.isFinite(score) || score < 0 || score > 100) throw new DomainError("invalid-argument", "Puntuación inválida."); // N02, N03, N04, N05
017    const base = score >= 95 ? 500 : score >= 90 ? 400 : score >= 80 ? 300 : score >= 70 ? 200 : score >= 60 ? 125 : score >= 40 ? 60 : 25; // N06, N07, N08, N09, N10, N11, N12, N13, N14, N15, N16, N17, N18
018    return Math.floor((base + Math.min(Math.floor(count / 10), 40)) * (ranked ? 1.5 : 1)); // N19, N20, N21, N22
019  }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | Entrada score,count,ranked |
| N02 | !Number.isFinite(score)? |
| N03 | score < 0? |
| N04 | score > 100? |
| N05 | throw invalid-argument |
| N06 | score >= 95? |
| N07 | base = 500 |
| N08 | score >= 90? |
| N09 | base = 400 |
| N10 | score >= 80? |
| N11 | base = 300 |
| N12 | score >= 70? |
| N13 | base = 200 |
| N14 | score >= 60? |
| N15 | base = 125 |
| N16 | score >= 40? |
| N17 | base = 60 |
| N18 | base = 25 |
| N19 | ranked? |
| N20 | factor = 1.5 |
| N21 | factor = 1 |
| N22 | floor((base + min(floor(count/10),40))*factor) |
| N23 | Salida común |

```mermaid
flowchart TD
  N01["Entrada score,count,ranked"]
  N02["!Number.isFinite(score)?"]
  N03["score &lt; 0?"]
  N04["score > 100?"]
  N05["throw invalid-argument"]
  N06["score >= 95?"]
  N07["base = 500"]
  N08["score >= 90?"]
  N09["base = 400"]
  N10["score >= 80?"]
  N11["base = 300"]
  N12["score >= 70?"]
  N13["base = 200"]
  N14["score >= 60?"]
  N15["base = 125"]
  N16["score >= 40?"]
  N17["base = 60"]
  N18["base = 25"]
  N19["ranked?"]
  N20["factor = 1.5"]
  N21["factor = 1"]
  N22["floor((base + min(floor(count/10),40))*factor)"]
  N23["Salida común"]
  N01 --> N02
  N02 -->|T| N05
  N02 -->|F| N03
  N03 -->|T| N05
  N03 -->|F| N04
  N04 -->|T| N05
  N04 -->|F| N06
  N06 -->|T| N07
  N06 -->|F| N08
  N08 -->|T| N09
  N08 -->|F| N10
  N10 -->|T| N11
  N10 -->|F| N12
  N12 -->|T| N13
  N12 -->|F| N14
  N14 -->|T| N15
  N14 -->|F| N16
  N16 -->|T| N17
  N16 -->|F| N18
  N07 --> N19
  N09 --> N19
  N11 --> N19
  N13 --> N19
  N15 --> N19
  N17 --> N19
  N18 --> N19
  N19 -->|T| N20
  N19 -->|F| N21
  N20 --> N22
  N21 --> N22
  N22 --> N23
  N05 --> N23
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N12 → N14 → N16 → N18 → N19 → N21 → N22 → N23 | UT-MAR-01-C01 | 1 |
| P2 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N12 → N14 → N16 → N17 → N19 → N21 → N22 → N23 | UT-MAR-01-C02 | 2 |
| P3 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N12 → N14 → N15 → N19 → N21 → N22 → N23 | UT-MAR-01-C03 | 3 |
| P4 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N12 → N13 → N19 → N21 → N22 → N23 | UT-MAR-01-C04 | 4 |
| P5 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N11 → N19 → N21 → N22 → N23 | UT-MAR-01-C05 | 5 |
| P6 | N01 → N02 → N03 → N04 → N06 → N08 → N09 → N19 → N21 → N22 → N23 | UT-MAR-01-C06 | 6 |
| P7 | N01 → N02 → N03 → N04 → N06 → N07 → N19 → N21 → N22 → N23 | UT-MAR-01-C07 | 7 |
| P8 | N01 → N02 → N03 → N04 → N06 → N08 → N10 → N12 → N14 → N16 → N18 → N19 → N20 → N22 → N23 | UT-MAR-01-C08 | 8 |
| P9 | N01 → N02 → N05 → N23 | UT-MAR-01-C09 | 9 |
| P10 | N01 → N02 → N03 → N05 → N23 | UT-MAR-01-C10 | 10 |
| P11 | N01 → N02 → N03 → N04 → N05 → N23 | UT-MAR-01-C11 | 11 |

Los 11 vectores de incidencia de aristas tienen rango 11 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [unidad final](../evidencias/cierre/backend/base-unit-final.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
