# CB-JEA-01 Jean Carlo — league

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/domain/policy/gamePolicy.ts:5`.

Rotación de candidato: league del backend da soporte al rating mostrado. El cliente tiene una función homóloga, pero este CFG pertenece únicamente al commit TypeScript indicado.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=13, E=17, componentes=1; V(G)=E−N+2=6.** El contraste `1+Σ(grado_salida−1)` da 6. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
005  export function league(rating: number): number { // N01
006    return rating < 30 ? 1 : rating < 60 ? 2 : rating < 90 ? 3 : rating < 120 ? 4 : rating < 150 ? 5 : 6; // N03, N04, N05, N06, N07, N08, N09, N10, N11, N12, N13
007  }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | Entrada rating |
| N02 | Salida común |
| N03 | rating < 30? |
| N04 | return 1 |
| N05 | rating < 60? |
| N06 | return 2 |
| N07 | rating < 90? |
| N08 | return 3 |
| N09 | rating < 120? |
| N10 | return 4 |
| N11 | rating < 150? |
| N12 | return 5 |
| N13 | return 6 |

```mermaid
flowchart TD
  N01["Entrada rating"]
  N02["Salida común"]
  N03["rating &lt; 30?"]
  N04["return 1"]
  N05["rating &lt; 60?"]
  N06["return 2"]
  N07["rating &lt; 90?"]
  N08["return 3"]
  N09["rating &lt; 120?"]
  N10["return 4"]
  N11["rating &lt; 150?"]
  N12["return 5"]
  N13["return 6"]
  N01 --> N03
  N03 -->|T| N04
  N04 --> N02
  N03 -->|F| N05
  N05 -->|T| N06
  N06 --> N02
  N05 -->|F| N07
  N07 -->|T| N08
  N08 --> N02
  N07 -->|F| N09
  N09 -->|T| N10
  N10 --> N02
  N09 -->|F| N11
  N11 -->|T| N12
  N12 --> N02
  N11 -->|F| N13
  N13 --> N02
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N03 → N04 → N02 | UT-JEA-01-C01 | 1 |
| P2 | N01 → N03 → N05 → N06 → N02 | UT-JEA-01-C02 | 2 |
| P3 | N01 → N03 → N05 → N07 → N08 → N02 | UT-JEA-01-C03 | 3 |
| P4 | N01 → N03 → N05 → N07 → N09 → N10 → N02 | UT-JEA-01-C04 | 4 |
| P5 | N01 → N03 → N05 → N07 → N09 → N11 → N12 → N02 | UT-JEA-01-C05 | 5 |
| P6 | N01 → N03 → N05 → N07 → N09 → N11 → N13 → N02 | UT-JEA-01-C06 | 6 |

Los 6 vectores de incidencia de aristas tienen rango 6 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [unidad final](../evidencias/cierre/backend/base-unit-final.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
