# CB-VIC-01 Víctor — ratingChange

Base `993c6b0641a4a60603d87e251c90f51783460007`, sin cambios de producto. Fuente `functions/src/domain/policy/gamePolicy.ts:20`.

Caracterización de la regla actual de rating; no conformidad con ELO oficial AC-06. Math.min/max no añaden decisiones propias.

Convención: `if`, ternarios y cada cortocircuito `||`, `&&`, `??` se descomponen cuando están en este alcance. `Math.min/max`, expresiones regulares y predicados de bibliotecas son llamadas atómicas. Retornos y throws convergen en la salida común numerada. No se suman callbacks desconectados. No hay `switch` en los métodos seleccionados. Excepciones implícitas de IO/SDK quedan fuera de este CFG de flujo normal.

**N=12, E=15, componentes=1; V(G)=E−N+2=5.** El contraste `1+Σ(grado_salida−1)` da 5. Todos los nodos de decisión son binarios. No se presenta un conteo de regiones porque no se certificó una incrustación planar.

## Fuente numerada

Los comentarios Nxx se añaden solo a esta copia documental. La salida común es un nodo virtual. Varios nodos pueden estar en la misma línea.

```typescript
020  export function ratingChange(mine: number, opponent: number, outcome: "WIN" | "LOSS" | "DRAW"): number {
021    const adjustment = Math.max(-5, Math.min(5, (opponent - mine) * 0.05)); // N01
022    if (outcome === "DRAW") return 1; // N02, N03
023    if (outcome === "LOSS") return Math.min(-1, Math.round(-6 + adjustment)); // N04, N05
024    return Math.max(1, Math.min(Math.round(4 + adjustment), mine >= 180 ? 2 : mine >= 150 ? 3 : Infinity)); // N06, N07, N08, N09, N10, N11
025  }
```

## Nodos y grafo

| Nodo | Código / operación representada |
|---|---|
| N01 | adjustment = clamp((opponent-mine)*0.05) |
| N02 | outcome === DRAW? |
| N03 | return 1 |
| N04 | outcome === LOSS? |
| N05 | return min(-1,round(-6+adjustment)) |
| N06 | mine >= 180? |
| N07 | cap = 2 |
| N08 | mine >= 150? |
| N09 | cap = 3 |
| N10 | cap = Infinity |
| N11 | return max(1,min(round(4+adjustment),cap)) |
| N12 | Salida común |

```mermaid
flowchart TD
  N01["adjustment = clamp((opponent-mine)*0.05)"]
  N02["outcome === DRAW?"]
  N03["return 1"]
  N04["outcome === LOSS?"]
  N05["return min(-1,round(-6+adjustment))"]
  N06["mine >= 180?"]
  N07["cap = 2"]
  N08["mine >= 150?"]
  N09["cap = 3"]
  N10["cap = Infinity"]
  N11["return max(1,min(round(4+adjustment),cap))"]
  N12["Salida común"]
  N01 --> N02
  N02 -->|T| N03
  N02 -->|F| N04
  N03 --> N12
  N04 -->|T| N05
  N04 -->|F| N06
  N05 --> N12
  N06 -->|T| N07
  N06 -->|F| N08
  N08 -->|T| N09
  N08 -->|F| N10
  N07 --> N11
  N09 --> N11
  N10 --> N11
  N11 --> N12
```

T/F indica el resultado de la condición de origen. El JSON conserva cada arista en el mismo orden usado para la comprobación de independencia.

## Base factible y ejecución

| Camino | Nodos | Caso ejecutado | Rango acumulado GF(2) |
|---|---|---|---|
| P1 | N01 → N02 → N03 → N12 | UT-VIC-01-C01 | 1 |
| P2 | N01 → N02 → N04 → N05 → N12 | UT-VIC-01-C02 | 2 |
| P3 | N01 → N02 → N04 → N06 → N08 → N10 → N11 → N12 | UT-VIC-01-C03 | 3 |
| P4 | N01 → N02 → N04 → N06 → N08 → N09 → N11 → N12 | UT-VIC-01-C04 | 4 |
| P5 | N01 → N02 → N04 → N06 → N07 → N11 → N12 | UT-VIC-01-C05 | 5 |

Los 5 vectores de incidencia de aristas tienen rango 5 en GF(2). Cada fila aumenta el rango en uno: la independencia se contrasta sobre el grafo completo y no solo por enumerar entradas. Los casos factibles son aprobados en [unidad final](../evidencias/cierre/backend/base-unit-final.log). Los datos y aserciones están en los archivos de test copiados en `codigo/backend/`. La correspondencia dinámica entre entrada y camino se deduce del control de flujo con esas entradas; no se instrumentó un trazador de nodos. La cobertura del runner se informa por separado y no se llama cobertura de caminos.
